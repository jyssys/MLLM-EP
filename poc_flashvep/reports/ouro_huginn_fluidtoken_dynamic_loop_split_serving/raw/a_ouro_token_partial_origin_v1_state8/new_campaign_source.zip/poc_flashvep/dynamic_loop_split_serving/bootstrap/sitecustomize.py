"""Install parent hooks with redirected globals before worker imports."""
import os
if os.environ.get('FLUIDTOKEN_LOOP_WORKER') == '1':
    try:
        import runpy
        from poc_flashvep.dynamic_loop_split_serving.common import configure, PARENT_SOURCE
        configure()
        runpy.run_path(str(PARENT_SOURCE / 'bootstrap/sitecustomize.py'))
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(70)
