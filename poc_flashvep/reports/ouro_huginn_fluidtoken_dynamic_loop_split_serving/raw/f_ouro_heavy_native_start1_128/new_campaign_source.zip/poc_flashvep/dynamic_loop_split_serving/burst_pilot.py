"""Qualify a shared submission optimization before any performance use."""
from .common import *
from .static_campaign import configuration
from .initial_qualification import qualify


def main():
    initialize()
    target = ROOT / 'state/burst_pilot.json'
    ledger = dict(status='IN_PROGRESS', models={},
        scope='New optional execution epoch. No baseline or SLO change. N8 exactness only. No performance expansion before separate N32 qualification.')
    for model in ('huginn', 'ouro'):
        row = ledger['models'][model] = {}
        reference = None
        for label in ('atomic_native', 'loop_partial', 'token_partial'):
            cfg = configuration(model, label, {}, 8, f'm_{model}_{label}_burst_state8', True,
                                seed=2026110401)
            cfg.update(contiguous_prompt_loop_burst=True,
                phase='NATIVE_MULTI_LOOP_SUBMISSION_N8_EXACTNESS_NOT_LATENCY')
            save(cfg)
            result = qualify(cfg['name'], reference)
            row[label] = result
            write(target, ledger)
            if label == 'atomic_native' and not result['passed']:
                break
            if result['passed']:
                reference = reference or cfg['name']
    ledger['status'] = 'BURST_PILOT_FINISHED_REVIEW_REQUIRED'
    write(target, ledger)


if __name__ == '__main__':
    main()
