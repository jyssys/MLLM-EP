import unittest
from .metrics import individual_slo_attainment


class IndividualSLOTests(unittest.TestCase):
    def test_missing_requests_remain_in_each_offered_denominator(self):
        rows = [dict(ttft_ms=10, tpot_ms=30), dict(ttft_ms=40, tpot_ms=5)]
        result = individual_slo_attainment(rows, 4, dict(TTFT_ms=20, TPOT_ms=20))
        self.assertEqual(result['TTFT_SLO_pass_count'], 1)
        self.assertEqual(result['TPOT_SLO_pass_count'], 1)
        self.assertEqual(result['TTFT_SLO_attainment'], .25)
        self.assertEqual(result['TPOT_SLO_attainment'], .25)
        self.assertEqual(result['SLO_attainment_denominator'], 4)

    def test_equal_deadlines_pass_and_invalid_populations_fail(self):
        row = dict(ttft_ms=20, tpot_ms=20)
        self.assertEqual(individual_slo_attainment([row], 1,
            dict(TTFT_ms=20, TPOT_ms=20))['TTFT_SLO_attainment'], 1)
        with self.assertRaises(ValueError):
            individual_slo_attainment([row], 0, dict(TTFT_ms=20, TPOT_ms=20))


if __name__ == '__main__':
    unittest.main()
