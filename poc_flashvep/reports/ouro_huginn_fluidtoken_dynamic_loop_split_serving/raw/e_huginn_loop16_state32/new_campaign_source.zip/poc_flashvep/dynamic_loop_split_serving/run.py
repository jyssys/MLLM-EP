"""Reuse the existing exclusive resource guard and bounded worker cleanup."""
import argparse
import fcntl
import zipfile
from .common import *


def execute(name):
    initialize()
    assert name.replace('_', '').isalnum(), 'A run name must be a simple immutable namespace'
    # Controllers can request the same predeclared cell. A shared namespace
    # lock prevents a second controller from treating a live run as abandoned.
    with (ROOT / 'state' / (name + '.namespace.lock')).open('a+') as namespace:
        fcntl.flock(namespace, fcntl.LOCK_EX)
        folder = ROOT / 'raw' / name
        if folder.exists() and not (folder / 'dispatcher_result.json').exists():
            # Older controllers predate the namespace lock. Their GPU work and
            # finalization still hold the existing quiet lane. Wait for it.
            with (ROOT / 'state/quiet_lane.lock').open('a+') as lane:
                fcntl.flock(lane, fcntl.LOCK_EX)
                if not (folder / 'dispatcher_result.json').exists():
                    raise RuntimeError('Unfinished namespace requires evidence review: ' + name)
        return _execute_locked(name)


def _execute_locked(name):
    initialize()
    from ..looped_pd_autonomous_headroom import run as native
    original = native.environment
    def environment(gpus):
        env = original(gpus)
        folder = ROOT / 'raw' / name
        parent_paths = sorted(list(PARENT_SOURCE.rglob('*.py')) + list(PARENT_SOURCE.rglob('*.cc')))
        with zipfile.ZipFile(folder / 'parent_campaign_source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in parent_paths:
                archive.write(path, str(path.relative_to(REPO)))
        write(folder / 'parent_campaign_source_hashes.json',
              {str(path): digest(path) for path in parent_paths})
        return env
    native.environment = environment
    try:
        from ..fluidtoken_loop_split import run as inherited
        return inherited.execute(name)
    finally:
        native.environment = original


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    args = parser.parse_args()
    raise SystemExit(0 if execute(args.name) else 1)
