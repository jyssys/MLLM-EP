"""Install parent hooks with redirected globals before worker imports."""
import os
if os.environ.get('FLUIDTOKEN_LOOP_WORKER') == '1':
    try:
        import runpy
        from poc_flashvep.dynamic_loop_split_serving.common import configure, PARENT_SOURCE
        configure()
        runpy.run_path(str(PARENT_SOURCE / 'bootstrap/sitecustomize.py'))
        from poc_flashvep.looped_pd_atomic_prefill.common import config
        from poc_flashvep.dynamic_loop_split_serving.warmup_boundary import install as warmup_boundary
        warmup_boundary(config())
        from poc_flashvep.dynamic_loop_split_serving.service_timing import install as service_timing
        service_timing(config())
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(70)
