"""Plot accepted measurements. Do not manufacture missing device evidence."""
import csv
from .common import *


def main():
    initialize()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 9, 'svg.fonttype': 'none'})
    target = ROOT / 'figures'
    target.mkdir(exist_ok=True)
    manifest = []
    rows = []
    qualification = {}
    for name in ('primary_screen', 'static_campaign', 'dynamic_campaign'):
        path = ROOT / 'state' / (name + '.json')
        if not path.exists():
            continue
        ledger = json.loads(path.read_text())
        candidates = list(ledger.get('results', []))
        candidates += [row for model in ledger.get('models', {}).values()
                       for row in model.get('serving', [])]
        for row in candidates:
            if row.get('name'):
                qualification[row['name']] = row.get('passed', False)
    for path in (ROOT / 'raw').glob('*/serving_metrics.json'):
        cfg = json.loads((ROOT / 'configs' / (path.parent.name + '.json')).read_text())
        if cfg.get('state_probe') or cfg.get('verify_transfer') or cfg.get('calibration_serial'):
            continue
        if cfg.get('kernel_activity_seconds'):
            continue
        row = json.loads(path.read_text())
        row['output_work_lifetime_gate'] = qualification.get(path.parent.name, False)
        row.update(axis=cfg.get('axis'), dynamic=cfg.get('dynamic', False),
                   cut=cfg.get('cut'), prefix=cfg.get('prefix_tokens'), load=cfg.get('load'),
                   source=str(path.relative_to(ROOT)), source_SHA256=digest(path))
        rows.append(row)
    columns = sorted({key for row in rows for key, value in row.items()
                      if not isinstance(value, (dict, list))})
    if rows:
        with (ROOT / 'serving_results.csv').open('w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=columns, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(rows)

    def save(fig, name, selected, scope):
        name = name.lower()
        fig.tight_layout()
        files = []
        for extension in ('png', 'svg'):
            path = target / (name + '.' + extension)
            fig.savefig(path, dpi=180, bbox_inches='tight')
            files.append(str(path.relative_to(ROOT)))
        plt.close(fig)
        manifest.append(dict(name=name, status='MEASURED', files=files, scope=scope,
            sources={row['source']: row['source_SHA256'] for row in selected}))

    for model in ('ouro', 'huginn'):
        measured = [row for row in rows if row['model'] == model and row['output_work_lifetime_gate']]
        if not measured:
            for figure in ('motivation', 'TTFT_decomposition', 'static_splits', 'dynamic_methods',
                           'matched_work', 'SLO_goodput_and_tails'):
                manifest.append(dict(name=f'{model}_{figure}', status='NOT_MEASURED'))
            continue
        for load in ('low', 'medium', 'heavy'):
            selected = [row for row in measured if row['load'] == load]
            if not selected:
                continue
            labels = [row['arm'] + (' k' + str(row['prefix']) if row['axis'] == 'token'
                      else ' R' + str(row['cut'])) for row in selected]
            fig, axes = plt.subplots(1, 3, figsize=(max(10, len(selected) * .8), 4.2))
            for ax, field, title in zip(axes,
                    ('TTFT_p95_ms', 'queue_ms_p95', 'service_TTFT_ms_p95'),
                    ('Request TTFT p95', 'Queue / admission p95', 'Service TTFT p95')):
                ax.bar(range(len(selected)), [row[field] / 1000 for row in selected], color='#3977a9')
                ax.set_xticks(range(len(selected)), labels, rotation=75, ha='right')
                ax.set(title=title, ylabel='Seconds')
                ax.grid(axis='y', alpha=.2)
            fig.suptitle(f'{model.title()} | {load} | N128 finite serving | quantiles are not additive', y=1.03)
            save(fig, f'{model}_{load}_TTFT_decomposition', selected,
                 'Per-request decomposition precedes quantiles. Queue and service p95 values are separate panels, not a stacked TTFT p95.')

        fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
        for arm in sorted({row['arm'] for row in measured}):
            group = [row for row in measured if row['arm'] == arm]
            boundaries = sorted({(row['cut'], row['prefix']) for row in group}, key=str)
            for cut, prefix in boundaries:
                values = sorted((row for row in group if row['cut'] == cut and row['prefix'] == prefix),
                                key=lambda row: row['nominal_QPS'])
                label = arm if any(row['dynamic'] for row in values) else arm + (
                    ' k' + str(prefix) if prefix is not None else ' R' + str(cut))
                for ax, field in zip(axes, ('joint_SLO_goodput', 'TPOT_p95_ms', 'ITL_p99_ms')):
                    ax.plot([row['nominal_QPS'] for row in values], [row[field] for row in values],
                            marker='o', ms=3, label=label)
        axes[0].set(ylabel='Joint-SLO requests/s', title='Finite measured SLO-goodput')
        axes[1].set(ylabel='Milliseconds', title='Request-average TPOT p95')
        axes[2].set(ylabel='Milliseconds', title='Token ITL p99')
        slo = measured[0]['frozen_SLO']
        axes[1].axhline(.9 * slo['TPOT_ms'], color='black', ls='--', label='Frozen 90% TPOT margin')
        axes[2].axhline(slo['ITL_ms'], color='black', ls='--', label='Frozen ITL p99 limit')
        for ax in axes:
            ax.set_xlabel('Nominal offered requests/s')
            ax.grid(alpha=.2)
        axes[-1].legend(fontsize=6, loc='upper left', bbox_to_anchor=(1.02, 1))
        save(fig, model + '_SLO_goodput_and_tails', measured,
             'Actual finite cohorts. Nominal QPS is the x-axis. Realized arrival QPS is retained in the CSV. No stable-capacity or physical-saturation claim.')

        selected = [row for row in measured if row['load'] == 'heavy' and row['arm'] != 'PD_G1']
        if selected:
            fig, axes = plt.subplots(1, 3, figsize=(12, 4))
            for axis, color in (('token', '#c86b35'), ('loop', '#3977a9')):
                group = [row for row in selected if row['axis'] == axis and not row['dynamic']]
                labels = [str(row['prefix'] if axis == 'token' else row['cut']) for row in group]
                for ax, field in zip(axes, ('service_TTFT_ms_p95', 'P_prompt_device_enclosure_ms_p95',
                                           'D_continuation_to_first_token_ms_p95')):
                    values = [(label, row[field]) for label, row in zip(labels, group) if row[field] is not None]
                    if values:
                        ax.plot([axis + ':' + label for label, _ in values], [v for _, v in values],
                                marker='o', color=color, label=axis)
            for ax, title in zip(axes, ('Service TTFT p95', 'P device enclosure p95', 'D continuation-to-first-output p95')):
                ax.set(title=title, ylabel='Milliseconds')
                ax.tick_params(axis='x', rotation=70)
                ax.grid(alpha=.2)
            save(fig, model + '_static_split_granularity', selected,
                 'Separate Token and Loop boundary labels. Device enclosures include launch gaps and interleaved requests. They are not exclusive kernel time.')
        activity = ROOT / 'activity_figure_manifest.json'
        recorded = json.loads(activity.read_text()).get('figures', []) if activity.exists() else []
        actual = [row for row in recorded if row.get('model') == model]
        manifest.append(dict(name=model + '_motivation',
            status='SEE_MATCHED_CAPTURE_MANIFEST' if actual else 'NOT_MEASURED',
            captures=actual,
            scope='New same-run kernel timelines require a qualified matched capture. Earlier motivation evidence remains in its original namespace.'))
        manifest.append(dict(name=model + '_matched_work_advantage', status='NOT_MEASURED',
            scope='Equal rows are not equal Attention work. No Loop-specific advantage is inferred from structural accounting.'))
    write(ROOT / 'figure_manifest.json', dict(figures=manifest,
        scope='Measured request latency and SLO-goodput only. Missing GPU and novelty evidence remains explicit.'))


if __name__ == '__main__':
    from ..looped_pd_autonomous_headroom.analysis_lane import quiet_analysis
    initialize()
    with quiet_analysis('serving_figures'):
        main()
