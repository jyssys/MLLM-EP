"""Derive per-request queue and service latency before computing quantiles."""
from .common import *


def decompose(arrival, first_token, start):
    if not arrival <= start['time'] <= first_token:
        raise ValueError('Invalid actual-execution timestamp order')
    return dict(queue_ms=1000 * (start['time'] - arrival),
        service_TTFT_ms=1000 * (first_token - start['time']),
        TTFT_ms=1000 * (first_token - arrival),
        start_clock_uncertainty_ms=1000 * (start['upper'] - start['lower']) / 2)


def summarize(name):
    from ..fluidtoken_loop_split.static_screen import metrics as host_metrics
    from ..looped_pd_headroom_recovery.gates import percentile
    folder = ROOT / 'raw' / name
    cfg = json.loads((ROOT / 'configs' / (name + '.json')).read_text())
    rows = [json.loads(line) for line in (folder / 'requests.jsonl').read_text().splitlines()]
    rows = [row for row in rows if not row.get('warmup')]
    expected = set(range(cfg['seed'], cfg['seed'] + cfg['count']))
    assert {row['seed'] for row in rows} == expected, 'Include all offered requests or report the run as incomplete'
    devices = {'prefill': {}, 'decode': {}}
    for path in folder.glob('service_device_times_*.json'):
        value = json.loads(path.read_text())
        target = devices[value['role']]
        for row in value['requests']:
            if row['seed'] in expected:
                assert row['seed'] not in target, 'Duplicate device state for one role and seed'
                target[row['seed']] = row
    if set(devices['prefill']) != expected:
        raise ValueError('Actual first Prefill execution is not measured for every request')
    phases = {row['request_id']: row for row in json.loads((folder / 'closed_stats.json').read_text())['metrics']}
    records = []
    for row in rows:
        seed = row['seed']
        rid = f"r{row['run']}_q{row['sample_id']}"
        first = next(event['time'] for event in row['token_events'] if event['first'])
        p = devices['prefill'][seed]
        values = decompose(row['arrival'], first, p['first_model_stream_entry'])
        # Native coordinator timestamps are relative to its request creation.
        # They are observed host boundaries, not kernel or DMA durations.
        phase = phases[rid]
        timings = phase['timings']
        observed_handoff = None
        if 'prefill_compute_completed' in timings and 'd_received' in timings:
            observed_handoff = 1000 * (timings['d_received'] - timings['prefill_compute_completed'])
        d = devices['decode'].get(seed)
        record = dict(request_id=rid, seed=seed, sample_id=row['sample_id'], arrival=row['arrival'],
            first_token=first, actual_P_model_stream_entry=p['first_model_stream_entry'],
            **values, P_prompt_device_enclosure_ms=p['prompt_device_enclosure_ms'],
            observed_handoff_ms=observed_handoff,
            D_prompt_device_enclosure_ms=d['prompt_device_enclosure_ms'] if d else None,
            D_continuation_to_first_token_ms=1000 * (first - d['first_model_stream_entry']['time']) if d else None)
        records.append(record)
    result = host_metrics(name)
    result.update(name=name, model=cfg['model'], arm=cfg['arm'],
        nominal_QPS=cfg['arrival_rate'], arrival_seed=cfg['arrival_seed'],
        realized_arrival_QPS=(len(rows) - 1) / (max(r['arrival'] for r in rows) - min(r['arrival'] for r in rows)),
        service_start_evidence='Native model-stream entry CUDA event after input preparation',
        service_start_limit='Not a CUPTI first-kernel timestamp. Clock uncertainty is retained per request.',
        timing_scope='Device enclosures include launch gaps and possibly other requests. They are not exclusive GPU kernel times.',
        profiler_overhead='NOT_MEASURED' if not cfg.get('service_timing_overhead_qualified') else cfg['service_timing_overhead_qualified'])
    for field in ('queue_ms', 'service_TTFT_ms', 'P_prompt_device_enclosure_ms',
                  'observed_handoff_ms', 'D_prompt_device_enclosure_ms', 'D_continuation_to_first_token_ms'):
        values = [row[field] for row in records if row[field] is not None]
        for q in (.5, .95, .99):
            result[f'{field}_p{int(q * 100)}'] = percentile(values, q) if values else None
    result['maximum_clock_uncertainty_ms'] = max(row['start_clock_uncertainty_ms'] for row in records)
    write(folder / 'service_latency_requests.json', records)
    write(folder / 'serving_metrics.json', result)
    return result
