import unittest
from .work_accounting import recurrent_geometry


class GeometryTests(unittest.TestCase):
    def test_equal_rows_are_not_equal_attention(self):
        loop = recurrent_geometry(4096, 4, 'loop', 3, 4096)
        token = recurrent_geometry(4096, 4, 'token', 4, 3072)
        self.assertEqual(loop['assigned_D_recurrent_token_rows'], token['assigned_D_recurrent_token_rows'])
        field = 'assigned_D_causal_attention_pairs_per_physical_attention_layer'
        self.assertGreater(token[field], loop[field])

    def test_full_and_local_endpoints(self):
        for axis, cut, prefix in (('loop', 4, 4096), ('token', 4, 4096)):
            value = recurrent_geometry(4096, 4, axis, cut, prefix)
            self.assertEqual(value['assigned_D_recurrent_token_rows'], 0)
        for axis, cut, prefix in (('loop', 0, 4096), ('token', 4, 0)):
            value = recurrent_geometry(4096, 4, axis, cut, prefix)
            self.assertEqual(value['assigned_D_recurrent_token_rows'], value['full_recurrent_token_rows'])


if __name__ == '__main__':
    unittest.main()
