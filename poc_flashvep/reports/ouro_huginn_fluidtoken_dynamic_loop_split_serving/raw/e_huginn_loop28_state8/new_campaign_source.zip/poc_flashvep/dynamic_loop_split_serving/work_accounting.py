"""Separate accepted work, completed work, and structural attention counts."""
from .common import *


def recurrent_geometry(length, depth, axis, cut, prefix):
    if not (length > 0 and depth > 0 and 0 <= cut <= depth and 0 <= prefix <= length):
        raise ValueError('Invalid recurrent geometry')
    pairs = length * (length + 1) // 2
    if axis == 'loop':
        rows = length * (depth - cut)
        transferred_pairs = pairs * (depth - cut)
    elif axis == 'token':
        rows = (length - prefix) * depth
        transferred_pairs = (pairs - prefix * (prefix + 1) // 2) * depth
    else:
        raise ValueError('Unknown split axis')
    return dict(assigned_D_recurrent_token_rows=rows,
        assigned_D_causal_attention_pairs_per_physical_attention_layer=transferred_pairs,
        full_recurrent_token_rows=length * depth,
        full_causal_attention_pairs_per_physical_attention_layer=pairs * depth,
        scope='Structural dense-causal pair counts. These are not measured FLOPs, GPU time, or speedup. Prelude and Coda are excluded.')


def summarize(name):
    folder = ROOT / 'raw' / name
    cfg = json.loads((ROOT / 'configs' / (name + '.json')).read_text())
    expected = set(range(cfg['seed'], cfg['seed'] + cfg['count']))
    completed = {json.loads(line)['seed'] for line in (folder / 'requests.jsonl').read_text().splitlines()
                 if not json.loads(line).get('warmup')}
    accepted = {}
    for path in folder.glob('accepted_partitions_*.jsonl'):
        for line in path.read_text().splitlines():
            row = json.loads(line)
            if row['seed'] not in expected:
                continue
            assert row['seed'] not in accepted, 'Count one actual accepted boundary per request'
            accepted[row['seed']] = row
    payloads = [json.loads(line) for path in folder.glob('migration_*.jsonl')
                for line in path.read_text().splitlines() if json.loads(line)['seed'] in expected]
    rows = []
    for seed, row in accepted.items():
        geometry = recurrent_geometry(row['prompt_tokens'], row['full_depth'], row['axis'],
                                      row['accepted_cut'], row['accepted_prefix_tokens'])
        assert geometry['assigned_D_recurrent_token_rows'] == row['assigned_D_recurrent_token_rows']
        rows.append(dict(seed=seed, completed=seed in completed, partial=row['partial'],
                         cut=row['accepted_cut'], prefix=row['accepted_prefix_tokens'], **geometry))
    done = [row for row in rows if row['completed']]
    result = dict(name=name, offered=cfg['count'], completed=len(completed & expected),
        accepted_boundaries=len(accepted),
        completed_offloaded_serving_requests=sum(row['partial'] for row in done),
        assigned_D_recurrent_token_rows_on_completed_requests=sum(row['assigned_D_recurrent_token_rows'] for row in done),
        assigned_D_attention_pairs_on_completed_requests=sum(
            row['assigned_D_causal_attention_pairs_per_physical_attention_layer'] for row in done),
        measured_snapshot_KV_bytes=sum(row['KV_bytes'] for row in payloads),
        measured_snapshot_hidden_bytes=sum(row['hidden_bytes'] for row in payloads),
        measured_snapshot_fragments=sum(row['fragments'] for row in payloads),
        measured_snapshot_descriptors=sum(row['descriptors'] for row in payloads),
        requests=rows,
        scope='Completion is paired with actual accepted boundaries. Full-depth execution still requires the separate work gate. Native-streaming payloads are not zero when snapshot records are absent.',
        FLOPs='NOT_MEASURED', kernel_invocations='NOT_MEASURED')
    write(folder / 'split_work_and_payload.json', result)
    return result
