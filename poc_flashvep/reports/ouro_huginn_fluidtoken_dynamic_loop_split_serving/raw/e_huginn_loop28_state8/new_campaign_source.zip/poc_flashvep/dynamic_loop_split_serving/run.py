"""Reuse the existing exclusive resource guard and bounded worker cleanup."""
import argparse
import zipfile
from .common import *


def execute(name):
    initialize()
    from ..looped_pd_autonomous_headroom import run as native
    original = native.environment
    def environment(gpus):
        env = original(gpus)
        folder = ROOT / 'raw' / name
        with zipfile.ZipFile(folder / 'parent_campaign_source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(PARENT_SOURCE.rglob('*.py')):
                archive.write(path, str(path.relative_to(REPO)))
        write(folder / 'parent_campaign_source_hashes.json',
              {str(path): digest(path) for path in sorted(PARENT_SOURCE.rglob('*.py'))})
        return env
    native.environment = environment
    try:
        from ..fluidtoken_loop_split import run as inherited
        return inherited.execute(name)
    finally:
        native.environment = original


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    args = parser.parse_args()
    raise SystemExit(0 if execute(args.name) else 1)
