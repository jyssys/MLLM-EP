import unittest
from .metrics import decompose


class MetricTests(unittest.TestCase):
    def test_request_identity(self):
        result = decompose(10., 12., dict(time=11.5, lower=11.499, upper=11.501))
        self.assertEqual(result['queue_ms'], 1500.)
        self.assertEqual(result['service_TTFT_ms'], 500.)
        self.assertEqual(result['TTFT_ms'], 2000.)
        self.assertAlmostEqual(result['start_clock_uncertainty_ms'], 1.)

    def test_invalid_order_is_not_clipped(self):
        for time in (9., 13.):
            with self.assertRaisesRegex(ValueError, 'timestamp order'):
                decompose(10., 12., dict(time=time, lower=time, upper=time))


if __name__ == '__main__':
    unittest.main()
