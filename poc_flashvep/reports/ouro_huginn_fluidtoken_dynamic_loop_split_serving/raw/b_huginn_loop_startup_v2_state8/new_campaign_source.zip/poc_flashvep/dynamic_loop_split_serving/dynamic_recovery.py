"""Retain the calibrated policy and isolate startup and branch diagnostics."""
import time
from .common import ROOT, prior

EXTRA_SIGNATURE = ('observe_service_timing', 'startup_relative_token_boundary')


def signature():
    from ..fluidtoken_loop_split import dynamic_adapter
    dynamic_adapter.SIGNATURE = tuple(dict.fromkeys(dynamic_adapter.SIGNATURE + EXTRA_SIGNATURE))
    return dynamic_adapter.SIGNATURE


def prepare(cfg):
    if not cfg.get('dynamic'):
        return
    signature()
    from ..adaptive_loop_token_pd_2gpu import policy
    inherited = policy.install

    def initialized(engine, contract):
        inherited(engine, contract)
        # This sender already retains native transport and lifecycle observers.
        engine._serving_base_sender = engine._send

    policy.install = initialized


def finalize(cfg):
    if not cfg.get('dynamic'):
        return
    from ..adaptive_loop_token_pd_2gpu import policy
    from ..fluidtoken_loop_split.dynamic_adapter import load_table
    table, costs, full = load_table(cfg)
    inherited = policy.install
    marker = ROOT / 'raw' / cfg['name'] / 'measurement_begin.json'
    diagnostic = cfg.get('qualification_force_partial_key')
    reject = cfg.get('qualification_reject_frontier', False)
    if diagnostic is not None or reject:
        assert cfg['phase'] == 'EXACT_DYNAMIC_BRANCH_DIAGNOSTIC'
        assert cfg.get('state_probe') and cfg.get('verify_transfer')
        assert cfg.get('calibration_serial'), 'Forced branch tests must retain isolated request execution'
        assert diagnostic in {row.key for row in costs if row.key != full.key}

    def initialized(engine, contract):
        inherited(engine, contract)
        send, receive = engine._send, engine._message

        def boundary(w, key):
            engine._arc_cuts[w.request.request_id] = key if cfg['axis'] == 'loop' else cfg['depth']
            engine._ltp_prefixes[w.request.request_id] = (len(w.request.prompt_token_ids)
                if cfg['axis'] == 'loop' else key)

        def sending(destination, kind, **fields):
            w = engine.transfers.get(fields.get('tid'))
            if kind == 'reserve' and w is not None:
                if not marker.exists():
                    rid = w.request.request_id
                    assert rid.startswith(('r-1_q', 'recovery_warm_')), 'Unexpected unmeasured dynamic request'
                    boundary(w, cfg['depth'] if cfg['axis'] == 'loop' else len(w.request.prompt_token_ids))
                    return engine._serving_base_sender(destination, kind, **fields)
                if diagnostic is not None:
                    boundary(w, diagnostic)
                    prior.append(ROOT / 'raw' / cfg['name'] / 'online_decisions.jsonl', dict(
                        event='FORCED_EXACT_BRANCH_DIAGNOSTIC', request_id=w.request.request_id,
                        key=diagnostic, online=False, time=time.monotonic(),
                        scope='Correctness-only serial branch exercise. Not online-policy performance.'))
                    return engine._serving_base_sender(destination, kind, **fields)
            return send(destination, kind, **fields)

        def received(peer, message):
            if reject and message['kind'] == 'frontier_ready':
                w = engine.transfers.get(message.get('tid') or message.get('request_id'))
                assert w is not None
                boundary(w, full.key)
                prior.append(ROOT / 'raw' / cfg['name'] / 'online_decisions.jsonl', dict(
                    event='FORCED_EXACT_FRONTIER_REJECTION', request_id=w.request.request_id,
                    online=False, time=time.monotonic(),
                    scope='Correctness-only full-PD fallback. The source must finish the exact remaining work.'))
                engine._send(w.p, 'frontier_decision', tid=w.tid, accept=False,
                             reason='EXACT_BRANCH_DIAGNOSTIC_REJECTION')
                return
            return receive(peer, message)

        engine._send, engine._message = sending, received

    policy.install = initialized
