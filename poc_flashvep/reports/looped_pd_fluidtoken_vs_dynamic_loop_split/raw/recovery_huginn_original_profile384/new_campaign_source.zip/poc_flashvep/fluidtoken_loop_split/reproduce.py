"""Finish the original clean/profile differential before changing variables."""
import time
from .common import *
from .run import execute


def main():
    initialize()
    clean = 'recovery_huginn_original_clean384'
    result = ROOT / 'raw' / clean / 'dispatcher_result.json'
    while not result.exists():
        if prior.time.time() >= LONG_START_CUTOFF:
            return
        time.sleep(10)
    assert json.loads(result.read_text())['complete'], 'Clean reproduction failed'
    name = 'recovery_huginn_original_profile384'
    complete = execute(name)
    write(ROOT / 'state/reproduction_result.json', dict(clean=clean, profile=name,
        profile_complete=complete, time=time.time(),
        status='REVIEW_PROGRESS_AND_PARITY' if complete else 'RED_REPRODUCER'))


if __name__ == '__main__':
    main()
