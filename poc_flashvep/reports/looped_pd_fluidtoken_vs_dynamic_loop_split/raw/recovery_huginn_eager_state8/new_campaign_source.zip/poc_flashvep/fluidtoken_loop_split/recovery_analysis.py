"""Audit one shared interval without importing another run's GPU evidence."""
import argparse
from .common import *


def analyze(name):
    configure()
    from ..looped_pd_autonomous_headroom.analysis_lane import quiet_analysis
    from ..looped_pd_autonomous_headroom.aligned_gates import one
    from ..looped_pd_autonomous_headroom.ready_queue_audit import audit
    from ..looped_pd_headroom_recovery import gates
    cfg = json.loads((ROOT / 'configs' / (name + '.json')).read_text())
    # Preserve the previous matched reference as external, hashed evidence.
    reference_name = 'capacity_short_huginn_L2048_v2'
    reference_path = PREVIOUS / 'raw' / reference_name / 'cohorts.jsonl'
    source = json.loads((PREVIOUS / 'configs' / (reference_name + '.json')).read_text())
    for key in ('model', 'model_revision', 'length', 'depth', 'chunk',
                'P_prefill_graph_rows', 'token_budget'):
        assert source.get(key) == cfg.get(key), ('Unmatched service reference', key)
    cohorts = [json.loads(line) for line in reference_path.read_text().splitlines()]
    reference = max(row['job']['batch'] / row['prefill_host_service_s']
                    for row in cohorts if row.get('status') == 'COMPLETE')
    inherited = gates.actual_P_reference
    gates.actual_P_reference = lambda config: reference
    try:
        with quiet_analysis(name + '_joint_audit'):
            result = one(cfg)
            queue = audit(cfg, result)
    finally:
        gates.actual_P_reference = inherited
    probes = [json.loads(line) for line in
              (ROOT / 'raw' / name / 'D_probe_requests.jsonl').read_text().splitlines()]
    central = [row for row in probes if result['observation_start'] <= row['time']
               <= row['finish'] <= result['observation_end']]
    output = dict(gates=result, queue=queue, central_completed_probes=len(central),
                  reference=dict(path=str(reference_path), SHA256=digest(reference_path),
                                 requests_per_second=reference,
                                 scope='Prior finite matched service reference. Not a new independent capacity measurement.'),
                  status='SCREEN_ONLY_CORRECTNESS_AND_REPETITIONS_PENDING')
    write(ROOT / 'raw' / name / 'recovery_joint_screen.json', output)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    print(json.dumps(analyze(parser.parse_args().name)))
