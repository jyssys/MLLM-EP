"""Redirect inherited hooks before any worker imports campaign globals."""
import os
if os.environ.get('FLUIDTOKEN_LOOP_WORKER') == '1':
    try:
        from poc_flashvep.fluidtoken_loop_split.common import configure
        configure()
        if os.environ.get('FLUIDTOKEN_DEBUGGER_OWNER_PID'):
            import ctypes
            owner = int(os.environ['FLUIDTOKEN_DEBUGGER_OWNER_PID'])
            # Authorize this runner and its diagnostic children, not all processes.
            result = ctypes.CDLL(None, use_errno=True).prctl(0x59616d61, owner, 0, 0, 0)
            if result:
                raise OSError(ctypes.get_errno(), 'Cannot authorize the owned diagnostic runner')
        import runpy
        runpy.run_path('/home/esjung/MLLM-EP-github/poc_flashvep/looped_pd_autonomous_headroom/bootstrap/sitecustomize.py')
        from poc_flashvep.looped_pd_atomic_prefill.common import config
        from poc_flashvep.fluidtoken_loop_split.split_adapter import install
        install(config())
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(70)
