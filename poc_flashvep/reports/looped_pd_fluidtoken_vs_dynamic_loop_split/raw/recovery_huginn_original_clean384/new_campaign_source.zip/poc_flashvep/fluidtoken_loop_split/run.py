"""Reuse the qualified runner and its bounded owned-process cleanup."""
import argparse
import os
import zipfile
from .common import *


def execute(name, keep_quiet=True):
    initialize()
    from ..looped_pd_autonomous_headroom import run as inherited
    inherited.ROOT = ROOT
    inherited.GPU_DEADLINE = GPU_DEADLINE
    original = inherited.environment
    def environment(gpus):
        env = original(gpus)
        env['FLUIDTOKEN_LOOP_WORKER'] = '1'
        env['PYTHONPATH'] = str(SOURCE / 'bootstrap') + os.pathsep + env['PYTHONPATH']
        folder = ROOT / 'raw' / name
        with zipfile.ZipFile(folder / 'new_campaign_source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in SOURCE.rglob('*.py'):
                archive.write(path, str(path.relative_to(REPO)))
        write(folder / 'new_campaign_source_hashes.json',
              {str(path): digest(path) for path in SOURCE.rglob('*.py')})
        return env
    inherited.environment = environment
    try:
        return inherited.execute(name, keep_quiet)
    finally:
        inherited.environment = original


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    parser.add_argument('--restore', action='store_true')
    args = parser.parse_args()
    raise SystemExit(0 if execute(args.name, not args.restore) else 1)
