"""Redirect inherited hooks before any worker imports campaign globals."""
import os
if os.environ.get('FLUIDTOKEN_LOOP_WORKER') == '1':
    try:
        from poc_flashvep.fluidtoken_loop_split.common import configure
        configure()
        import runpy
        runpy.run_path('/home/esjung/MLLM-EP-github/poc_flashvep/looped_pd_autonomous_headroom/bootstrap/sitecustomize.py')
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(70)
