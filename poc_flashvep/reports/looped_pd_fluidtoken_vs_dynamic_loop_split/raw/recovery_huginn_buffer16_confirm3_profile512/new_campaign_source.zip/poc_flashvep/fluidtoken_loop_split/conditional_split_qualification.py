"""Keep method GPU work behind the independently confirmed Huginn gate."""
import time
from .common import *


def main():
    initialize()
    path = ROOT / 'state/admitted_buffer_recovery.json'
    terminal = {'THREE_START_RECOVERY_PASSED', 'CONFIRMATION_FAILED', 'SCREEN_FAILED',
                'PROFILE_FAILED', 'NO_PROBE_BASELINE_FAILED', 'BLOCKED_COLLECTOR_RECOVERY'}
    while time.time() < LONG_START_CUTOFF:
        if path.exists():
            state = json.loads(path.read_text())
            if state['status'] in terminal:
                break
        time.sleep(5)
    else:
        write(ROOT / 'state/conditional_split_qualification.json', dict(status='NOT_RUN_TIME_BUDGET'))
        return
    if state['status'] != 'THREE_START_RECOVERY_PASSED':
        write(ROOT / 'state/conditional_split_qualification.json', dict(
            status='BLOCKED_BY_HUGINN_GATE', recovery_status=state['status']))
        return
    from .static_qualification import main as qualify
    results = {}
    for model in ('huginn', 'ouro'):
        qualify(model, True)
        results[model] = json.loads((ROOT / 'state' / f'static_qualification_{model}.json').read_text())
        write(ROOT / 'state/conditional_split_qualification.json', dict(status='IN_PROGRESS', results=results))
    write(ROOT / 'state/conditional_split_qualification.json', dict(status='QUALIFICATION_FINISHED', results=results))


if __name__ == '__main__':
    main()
