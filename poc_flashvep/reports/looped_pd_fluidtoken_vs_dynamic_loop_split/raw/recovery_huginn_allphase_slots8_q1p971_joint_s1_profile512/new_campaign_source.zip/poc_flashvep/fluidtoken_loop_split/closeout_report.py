"""Generate a final evidence summary from terminal ledgers, not expectations."""
import time
from .common import *
from .final_inventory import read


def table(header, rows):
    return ['| ' + ' | '.join(header) + ' |', '|' + '|'.join(['---'] * len(header)) + '|'] + [
        '| ' + ' | '.join(str(value) for value in row) + ' |' for row in rows]


def main():
    configure()
    from .final_inventory import main as inventory
    inventory()
    from .conditional_split_qualification import recovery_ready
    gate = read(ROOT / 'state/huginn_final_recovery_gate.json', {})
    ready = recovery_ready(gate)
    methods = read(ROOT / 'state/static_screen.json', {})
    qualification = read(ROOT / 'state/conditional_split_qualification.json', {})
    census = read(ROOT / 'complete_configuration_inventory.json')['configurations']
    elapsed = (time.time() - START) / 3600
    complete = sum(row['status'].startswith('COMPLETE') for row in census)
    failed = sum(row['status'] == 'FAILED_OR_INTERRUPTED' for row in census)
    missing = len(census) - complete - failed
    report = ['# Huginn recovery and FluidToken-style versus Loop Split', '',
        f'Report snapshot: {time.strftime("%Y-%m-%d %H:%M:%S %Z")}. Elapsed wall time: {elapsed:.3f} hours.',
        'The 11-hour budget includes diagnosis, GPU work, reports, publication, and resource restoration.', '',
        '## Decision', '',
        f'Huginn recovery: **{"OPERATIONAL_RECOVERY_READY" if ready else "NOT_CONFIRMED"}**.',
        'The operational test uses kernel union and a finite service reference. It does not measure physical peak-FLOP saturation.',
        'Ouro readiness from the previous campaign remains historical evidence. It is not a new Token/Loop comparison.',
        'No Loop-specific advantage follows from D-local probe completion alone.', '',
        'Completion does not imply correctness, SLO compliance, or accepted profiling.',
        f'The configuration inventory contains {complete} completed jobs, {failed} failed/interrupted jobs, and {missing} uncompleted configurations.',
        'These counts include diagnostics and microbenchmarks. They are not counts of comparable serving configurations.', '',
        '## Evidence classes and fixed contract', '',
        '- MEASURED: actual GPU execution or host request observations, with their scopes stated.',
        '- TRACE_ANALYSIS: analysis of retained measured events and timestamps.',
        '- STRUCTURAL_ACCOUNTING: byte, row, or boundary accounting. This is not measured speedup.',
        '- NOT_MEASURED or BLOCKED: no accepted result exists.',
        '- Both models retain original BF16 weights and fixed Ouro R4 or Huginn R32.',
        '- No approximation, early exit, weight update, or recurrent-work omission is permitted.',
        '- P kernel union must reach 80%. Finite service proximity must reach 85%.',
        '- Matched whole-run wall perturbation must remain at most 5%.',
        '- Positive device-qualified P-ready growth and D credit remain independent requirements.',
        '- Huginn L2048 uses TPOT p95 at most 167.914355 ms and ITL p99 at most 192.821254 ms.',
        '- Whole-run Decode SLO and common-interval Decode SLO must both pass.',
        '- Three independent starts are required. A bounded-window pass does not replace this requirement.', '',
        '## Huginn recovery', '',
        'The primary recovery workload contains 2048 input tokens and 16 controlled output tokens.',
        'The retained pool contains 128 ShareGPT/LongBench controlled prefixes. N512 explicitly reuses them cyclically.',
        'Ignore-EOS generation is not natural response-length measurement.',
        'Most controls use nominal 1.971 requests/s. The inventory records every changed rate and finite arrival realization.',
        'P uses two slots. D slot and graph variants remain separate configurations.',
        'Independent D-local probes use 16 input tokens and full R32 computation. They are not P-to-D continuations.', '',
        '### Accepted repetitions', '']
    accepted_rows = []
    if ready:
        for trial in gate['results']:
            same = trial['same_run']
            g = same['screen']['gates']
            accepted_rows.append([trial['profile'], f"{100*g['P_actual_kernel_busy_central']:.3f}",
                f"{100*g['P_fraction_reference']:.3f}", f"{same['device_qualified_queue']['half_growth']:.6f}",
                f"{g['D_request_TPOT_p95_ms']:.3f}", f"{g['D_token_ITL_p99_central_ms']:.3f}",
                g['D_min_coordinator_free_blocks'], same['screen']['central_completed_probes']])
    report += table(['Run', 'P union %', 'Service proximity %', 'P queue growth', 'D TPOT p95 ms', 'D ITL p99 ms', 'D free blocks', 'Local probes in interval'],
                    accepted_rows or [['NOT_CONFIRMED'] + ['NOT_MEASURED'] * 7])
    report += ['', 'Every accepted row uses one execution and one common observation window.',
        f"Accepted D kernel evidence: {gate.get('D_kernel_activity', 'See each accepted capture manifest. No missing D trace is inferred.') if ready else 'NOT_MEASURED_IN_ACCEPTED_RUNS'}.",
        'A P-only trace cannot supply a D kernel timeline. Exact probes, D credit, and D SLO remain same-run measurements.',
        'The complete inventory retains failed runs and all rejected profiling evidence.', '',
        '### Root-cause evidence', '']
    report += table(['Finding', 'Evidence', 'Limit'], [
        ['NIXL/CUPTI progress stall', 'Repeated native stacks reach NIXL/UCX CUDA IPC and CUPTI/driver locks.', 'ROOT_CAUSE_INCONCLUSIVE: the lock owner and complete cycle are not proved.'],
        ['Measurement-path recovery', 'Early CUPTI initialization and 16 preallocated buffers provide completed activity-only captures.', 'This does not prove that the vendor-level stall is fixed.'],
        ['Foreground evidence I/O', 'Measured append calls reach 299.750 ms in the coordinator, 286.899 ms in P, and 271.819 ms in D.', 'The exact filesystem or kernel-lock cause remains unresolved.'],
        ['Asynchronous evidence routing', 'Custom campaign append aliases now use the existing durable writer.', 'Whole-run tail improvements do not guarantee the common-interval gates.'],
        ['Decode geometry', 'Four-row and eight-row controls retain separate output/state checks and latency results.', 'Do not compare different geometry as a Token-versus-Loop benefit.'],
        ['Probe admission and pacing', 'The retained controllers test all Decode phases and, conditionally, observed-output pacing.', 'Only terminal qualified results can authorize method expansion.']])
    report += ['', 'Long foreground evidence calls can delay serving. Their occurrence is measured, not inferred from utilization.',
        'Temporal overlap with a latency spike does not prove that this mechanism explains every spike.',
        'The global wall-time profiling check also does not prove that local Decode tails are unaffected.',
        'Several completed dual-device captures fail the same-window Decode or credit gate. Those captures remain rejected.', '',
        '## Method correctness and serving comparison', '',
        f"Qualification ledger status: `{qualification.get('status', 'NOT_RUN')}`.",
        'The five static controls separate Atomic scheduling, staged scheduling, and snapshot transport.',
        'Token boundaries are independent of the execution chunk budget. Token Split is not restricted to C256.',
        'All method arms use separate Prefill/Decode phases. Shared-core co-batching is not a claimed contribution.',
        'Heavy state checks are not clean latency measurements.', '']
    method_rows = []
    for model in ('ouro', 'huginn'):
        for label in ('atomic_native', 'staged_native', 'staged_snapshot_full', 'token_partial', 'loop_partial'):
            values = [r for r in methods.get('results', []) if r.get('model') == model and label in r.get('name', '')]
            value = values[-1] if values else {}
            m = value.get('metrics', {})
            status = ('MEASURED_N32_SCREEN' if value.get('correct') else 'FAILED_OR_UNQUALIFIED') if value else ('NOT_RUN' if ready else 'BLOCKED_BY_HUGINN_GATE')
            method_rows.append([model, label, status] + [f'{m[key]:.3f}' if key in m else 'NOT_MEASURED'
                for key in ('TTFT_p95_ms', 'TPOT_p95_ms', 'ITL_p99_ms', 'E2E_p95_ms', 'requests_per_second', 'joint_SLO_goodput')])
        for label in ('token_dynamic', 'loop_dynamic'):
            method_rows.append([model, label, 'SEE_DYNAMIC_LEDGER_IF_PRESENT'] + ['NOT_MEASURED'] * 6)
    report += table(['Model', 'Method/control', 'Status', 'TTFT p95 ms', 'TPOT p95 ms', 'ITL p99 ms', 'E2E p95 ms', 'Completed req/s', 'Joint-SLO req/s'], method_rows)
    report += ['', 'An N32 screen is exploratory. It does not establish stable serving capacity or a replicated method advantage.',
        'Dynamic policy CPU tests use synthetic costs. They are not online GPU results.',
        'A dynamic GPU experiment requires measured calibration, matching source/configuration hashes, and a separate exactness gate.',
        'The final author must reconcile any later dynamic ledger before publication.', '',
        '## Prior work and novelty', '',
        '[FluidPD](https://arxiv.org/html/2610.06917v1) uses token-prefix migration and pressure-aware suffix allocation.',
        'Our runtime differs from its SGLang implementation. No official code was independently identified in the inspected sources.',
        'The appropriate label is FluidToken-style reproduction, not execution of the original system.',
        'The queued-deadline selector uses known requests, measured costs, D credit, and observed latency slack.',
        'It does not implement every continuous-token or scheduling-iteration detail of FluidPD Algorithm 1.',
        'See [the prior-work audit](looped_pd_fluidtoken_vs_dynamic_loop_split/prior_work_and_reuse_audit.md) and the dynamic policy contract.',
        'A generic logical-layer split includes the same recurrent boundary.',
        'The same boundary, state, and execution cost imply EQUIVALENT_MECHANISM.',
        'A Token-versus-Loop difference cannot alone prove exclusive Loop-specific novelty.',
        'Both PD workers already hold the complete model. Shared weights do not automatically save additional model residency.', '',
        '## Work, transfer, and E2E accounting', '',
        'A completed 512-request Huginn run contains 33,554,432 background Prefill recurrent token rows.',
        'Twelve full-R32, 16-token probes add 6,144 recurrent token rows.',
        'The structural fraction is 0.018310546875%. It is not a FLOP fraction, offloaded serving fraction, or speedup.',
        'Serving-request offload counts must come from connector decisions and actual continuation submissions.',
        'D-local probe counts must never substitute for those counts.',
        'Token-row matching does not guarantee equal attention FLOPs.',
        'The host E2E v2 CSV partitions admission, P dispatch/start waiting, observed P service, completion-to-first-token, and generation.',
        'The completion-to-first-token component includes handoff, D continuation, Coda, sampling, and delivery when applicable.',
        'An activation receipt can follow the first token. It is therefore not a valid exclusive first-token partition boundary.',
        'Kernel, transfer, and host durations can overlap. Their sums are not exclusive E2E percentages.',
        'SM occupancy, achieved bandwidth, and peak-FLOP utilization remain NOT_MEASURED unless separately identified in raw counters.', '',
        '## Exactness and limitations', '',
        'The recovery controls compare full output sequences and full recurrent row counts with the retained native references.',
        'Separate heavy tests compare valid prompt KV planes and hidden-state hashes.',
        'N512 serving runs do not hash every intermediate tensor.',
        'Each new Token/Loop connector configuration requires byte identity and output/state qualification.',
        'Original-HF equivalence and downstream benchmark accuracy remain NOT_MEASURED in this campaign.',
        'Finite-cohort throughput includes queue drain. It is not an indefinitely sustainable capacity estimate.',
        'Run repetitions and percentile uncertainty must remain distinct from individual token sample counts.', '',
        '## Artifacts and reproduction', '',
        '- [Complete configuration inventory](looped_pd_fluidtoken_vs_dynamic_loop_split/complete_configuration_inventory.csv).',
        '- [Recovery attempt table](looped_pd_fluidtoken_vs_dynamic_loop_split/recovery_attempts.csv).',
        '- Per-run configurations, source hashes, raw outputs, kernel records, and failure logs remain under the campaign directory.',
        '- `commands.jsonl` records actual launches. Figure manifests identify their source execution and interval.',
        '- `state/huginn_final_recovery_gate.json` records the current authorization gate.',
        '- `state/conditional_split_qualification.json` records method state qualification.',
        '- `state/publication_receipt.json` records the published commit and remote verification after publication.', '',
        'Reproduction entry points:', '', '```bash',
        '/home/esjung/.venvs/looped-pd-abc/bin/python -m poc_flashvep.fluidtoken_loop_split.run RUN_NAME',
        '/home/esjung/.venvs/looped-pd-abc/bin/python -m poc_flashvep.fluidtoken_loop_split.final_inventory',
        '/home/esjung/.venvs/looped-pd-abc/bin/python -m poc_flashvep.fluidtoken_loop_split.plot_joint_activity RUN_NAME',
        '```', '',
        f'Publication branch: `{BRANCH}`. Parent evidence commit: `{BASE}`.',
        'The publication uses a temporary Git index. The user checkout and staged index remain unchanged.',
        'No force push is permitted. Remote SHA equality and approved burner restoration require final verification.', '']
    target = ROOT.parent / 'looped_pd_fluidtoken_vs_dynamic_loop_split_final_summary.md'
    target.write_text('\n'.join(report))
    print(str(target))


if __name__ == '__main__':
    main()
