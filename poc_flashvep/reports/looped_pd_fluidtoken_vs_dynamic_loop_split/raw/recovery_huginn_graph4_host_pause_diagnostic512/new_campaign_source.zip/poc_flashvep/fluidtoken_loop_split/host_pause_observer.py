"""Record long host calls without changing CUDA or transport execution."""
import atexit
import os
import time
from .common import ROOT, write


def install(cfg):
    if not cfg.get('observe_host_pauses'):
        return
    threshold = .02
    events = []
    finished = [False]

    def observe(owner, method, label):
        original = getattr(owner, method)
        def measured(*args, **kwargs):
            start = time.monotonic()
            try:
                return original(*args, **kwargs)
            finally:
                end = time.monotonic()
                if end - start >= threshold:
                    batch = kwargs.get('batch')
                    events.append(dict(method=label, start=start, end=end,
                        seconds=end - start, logical_rows=getattr(batch, 'num_rows', None)))
        setattr(owner, method, measured)

    def flush():
        if finished[0]:
            return
        finished[0] = True
        write(ROOT / 'raw' / cfg['name'] / f'host_pauses_{os.getpid()}.json', dict(
            pid=os.getpid(), threshold_seconds=threshold, events=events,
            scope='Host-call enclosures. Nested intervals overlap and must not be added. No GPU execution time is inferred.'))

    import torch
    from vllm_rlt.worker.model_runner import ModelRunner
    from vllm_rlt.engine.stage_engine import StageEngine
    from vllm_rlt.pd.engine import PDEngine
    from vllm_rlt.pd.transport import NixlConnector
    from vllm_rlt.pd.connector import PDStageConnector
    for owner, method, label in (
        (torch.cuda, 'mem_get_info', 'cuda_mem_get_info'),
        (ModelRunner, 'submit', 'model_submit'),
        (StageEngine, 'step', 'stage_step'),
        (NixlConnector, 'submit', 'nixl_submit'),
        (NixlConnector, 'poll', 'nixl_poll'),
        (PDStageConnector, 'progress', 'connector_progress'),
        (PDEngine, '_message', 'coordinator_message')):
        observe(owner, method, label)
    atexit.register(flush)
    for cls in (StageEngine, PDEngine):
        original = cls.close
        def close(engine, *args, _original=original, **kwargs):
            try:
                return _original(engine, *args, **kwargs)
            finally:
                flush()
        cls.close = close
