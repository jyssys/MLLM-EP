"""Reuse the qualified runner and its bounded owned-process cleanup."""
import argparse
import os
import zipfile
import threading
import time
from .common import *


def execute(name, keep_quiet=True):
    initialize()
    from ..looped_pd_autonomous_headroom import run as inherited
    inherited.ROOT = ROOT
    inherited.GPU_DEADLINE = GPU_DEADLINE
    cfg = json.loads((ROOT / 'configs' / (name + '.json')).read_text())
    original = inherited.environment
    def environment(gpus):
        env = original(gpus)
        env['FLUIDTOKEN_LOOP_WORKER'] = '1'
        if cfg.get('native_stack_diagnostic'):
            env['FLUIDTOKEN_DEBUGGER_OWNER_PID'] = str(os.getpid())
        env['PYTHONPATH'] = str(SOURCE / 'bootstrap') + os.pathsep + env['PYTHONPATH']
        folder = ROOT / 'raw' / name
        with zipfile.ZipFile(folder / 'new_campaign_source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in SOURCE.rglob('*.py'):
                archive.write(path, str(path.relative_to(REPO)))
        write(folder / 'new_campaign_source_hashes.json',
              {str(path): digest(path) for path in SOURCE.rglob('*.py')})
        return env
    inherited.environment = environment
    stop = threading.Event()
    def inspect_stall():
        folder = ROOT / 'raw' / name
        signature, changed, recorded = None, time.monotonic(), set()
        while not stop.wait(2):
            path = folder / 'requests.jsonl'
            size = path.stat().st_size if path.exists() else None
            if size != signature:
                signature, changed = size, time.monotonic()
            if size is None or time.monotonic() - changed < 30:
                continue
            for record in folder.glob('stage_owner_*.json'):
                value = json.loads(record.read_text())
                pid = value['pid']
                if pid in recorded:
                    continue
                try:
                    proc = Path('/proc', str(pid))
                    words = (proc / 'cmdline').read_bytes().decode().split('\0')
                    if (proc.stat().st_uid != os.getuid()
                            or str(value['payload']) not in words
                            or Path(value['payload']).parent != folder):
                        continue
                    recorded.add(pid)
                    result = subprocess.run([
                        '/home/esjung/.local/opt/fluidtoken-debug-tools/bin/py-spy',
                        'dump', '--native', '--pid', str(pid)],
                        capture_output=True, text=True, timeout=15)
                    write(folder / f'native_stall_stack_{pid}.json', dict(
                        returncode=result.returncode, stdout=result.stdout,
                        stderr=result.stderr, time=time.time(),
                        scope='Diagnostic attachment after 30 seconds without response progress. Not clean timing.'))
                except (OSError, subprocess.TimeoutExpired) as error:
                    write(folder / f'native_stall_stack_error_{pid}.json', dict(error=repr(error)))
    monitor = None
    if cfg.get('native_stack_diagnostic'):
        monitor = threading.Thread(target=inspect_stall, daemon=True)
        monitor.start()
    try:
        return inherited.execute(name, keep_quiet)
    finally:
        stop.set()
        if monitor:
            monitor.join(timeout=20)
        inherited.environment = original


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    parser.add_argument('--restore', action='store_true')
    args = parser.parse_args()
    raise SystemExit(0 if execute(args.name, not args.restore) else 1)
