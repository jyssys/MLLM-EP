"""Compare identical retained probe inputs against a qualified native reference."""
from .common import *


def verify(name):
    folder = ROOT / 'raw' / name
    reference = 'recovery_huginn_original_clean384_exact_probe_reference'
    ref_folder = ROOT / 'raw' / reference
    certified = json.loads((ref_folder / 'recovery_gate.json').read_text())
    assert certified['passed']
    rows = [json.loads(line) for line in (folder / 'D_probe_requests.jsonl').read_text().splitlines()]
    refs = [json.loads(line) for line in (ref_folder / 'requests.jsonl').read_text().splitlines()]
    refs = {row['seed']: row for row in refs if not row.get('warmup')}
    cfg = json.loads((ROOT / 'configs' / (name + '.json')).read_text())
    requests = [json.loads(line) for line in (folder / 'requests.jsonl').read_text().splitlines()]
    requests = [row for row in requests if not row.get('warmup')]
    failures = [row['seed'] for row in rows if row['seed'] not in refs or
                any(row[key] != refs[row['seed']][key] for key in ('input_ids', 'output_ids', 'exit_depths'))]
    before = json.loads((folder / 'before_measured.json').read_text())
    after = json.loads((folder / 'after_measured.json').read_text())
    observed = sum(row['issued_loop_rows'] - before[key]['issued_loop_rows'] for key, row in after.items())
    expected = sum((row['input_tokens'] + row['output_tokens'] - 1) * cfg['depth'] for row in requests)
    expected += sum(len(row['input_ids']) * cfg['depth'] for row in rows)
    result = dict(name=name, reference=reference,
        reference_SHA256=digest(ref_folder / 'requests.jsonl'),
        completed_probes=len(rows), expected_probes=cfg['D_probe_count'], failures=failures,
        exact=not failures and len(rows) == cfg['D_probe_count'] and len({row['seed'] for row in rows}) == len(rows),
        expected_recurrent_rows=expected, observed_recurrent_rows=observed, full_work=observed == expected,
        scope='Exact probe inputs, seeds, outputs and depth against the qualified native reference. Not migrated continuation or original-HF fidelity.')
    target = folder / 'retained_native_probe_correctness.json'
    if target.exists():
        assert json.loads(target.read_text()) == result
    else:
        write(target, result)
    return result
