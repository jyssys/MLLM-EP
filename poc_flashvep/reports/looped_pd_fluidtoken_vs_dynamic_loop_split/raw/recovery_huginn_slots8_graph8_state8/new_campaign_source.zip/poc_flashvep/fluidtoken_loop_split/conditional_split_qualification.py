"""Keep method GPU work behind the independently confirmed Huginn gate."""
import time
from .common import *


def main():
    initialize()
    # Bounded-window passes did not guarantee whole-run Decode SLO compliance.
    # Do not unlock method work with the earlier, narrower recovery artifact.
    path = ROOT / 'state/huginn_final_recovery_gate.json'
    terminal = {'RECOVERY_READY', 'BLOCKED_CORRECTNESS', 'RECOVERY_FAILED'}
    while time.time() < LONG_START_CUTOFF:
        if path.exists():
            state = json.loads(path.read_text())
            if state['status'] in terminal:
                break
        time.sleep(5)
    else:
        write(ROOT / 'state/conditional_split_qualification.json', dict(status='NOT_RUN_TIME_BUDGET'))
        return
    if state['status'] != 'RECOVERY_READY' or not all(state.get(key, False) for key in
            ('same_run_gates', 'whole_run_decode_SLO', 'independent_repeats', 'exact_state_and_output')):
        write(ROOT / 'state/conditional_split_qualification.json', dict(
            status='BLOCKED_BY_HUGINN_GATE', recovery_status=state['status']))
        return
    from .static_qualification import main as qualify
    results = {}
    for model in ('huginn', 'ouro'):
        qualify(model, True)
        results[model] = json.loads((ROOT / 'state' / f'static_qualification_{model}.json').read_text())
        write(ROOT / 'state/conditional_split_qualification.json', dict(status='IN_PROGRESS', results=results))
    write(ROOT / 'state/conditional_split_qualification.json', dict(status='QUALIFICATION_FINISHED', results=results))


if __name__ == '__main__':
    main()
