"""Require actual output, valid-cache, hidden-state, and work accounting evidence."""
import sys
from .common import *

def check(name):
    folder=ROOT/'raw'/name;status=json.loads((folder/'status.json').read_text())
    assert status['status']=='COMPLETE',status
    cohorts=[json.loads(s) for s in (folder/'cohorts.jsonl').read_text().splitlines()]
    assert cohorts and all(r.get('native_output_parity') for r in cohorts)
    assert all(r['full_depth_rows']==r['full_depth_rows_observed'] for r in cohorts)
    states={}
    for path in folder.glob('prompt_states_*.jsonl'):
        for s in path.read_text().splitlines():
            r=json.loads(s);key=(r['seed'],r['prompt_tokens'])
            value=dict(hidden=r['hidden_sha256'],planes=r['planes'])
            states.setdefault(key,[]).append(value)
    matched=0
    for key,values in states.items():
        if len(values)<2:continue
        assert all(v==values[0] for v in values),f'Prompt state mismatch: {key}'
        matched+=1
    assert matched>=sum(r['batch'] for r in cohorts),'Missing native-versus-barrier state evidence'
    result=dict(status='PASS_INTERNAL_BARRIER_CORRECTNESS',name=name,model=cohorts[0]['model'],
        compared_output_sequences=sum(r['batch'] for r in cohorts),matched_prompt_state_groups=matched,
        scope='Finite same-engine barrier gate. Not original-HF equivalence or downstream accuracy.',time=time.time())
    write(ROOT/'state'/f'{name}_gate.json',result);return result

if __name__=='__main__':
    for name in sys.argv[1:]:print(json.dumps(check(name)),flush=True)
