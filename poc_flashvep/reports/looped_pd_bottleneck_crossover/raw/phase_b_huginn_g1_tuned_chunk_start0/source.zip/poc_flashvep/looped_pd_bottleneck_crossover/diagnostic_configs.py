"""Keep preregistered short-output diagnostics separate from the primary grid."""
import argparse
import random
from .common import *
from .prepare import base
from .phase_b_configs import pd_config
from .followup_configs import save,enqueue


def tuned_g1():
    names=[]
    for model in ('ouro','huginn'):
        old=json.loads((ROOT/'configs'/f'phase_b_{model}_g1_screen_start0.json').read_text())
        c=dict(old,name=f'phase_b_{model}_g1_tuned_chunk_start0',chunk=2048,token_budget=2048,
            phase='focused_crossover',protocol_control='Native PD transport and identical arrivals. Only chunk budget changes.')
        names.append(save(c))
    enqueue(names)


def optional_capacity():
    for model in ('ouro','huginn'):
        for cell in ('g1','g2','g3','g4','g5','g6','c1','c2'):
            path=ROOT/'raw'/f'phase_b_{model}_{cell}_screen_start0'/'status.json'
            assert path.exists() and json.loads(path.read_text())['status']=='COMPLETE','Finish the full primary screen first'
    gate=json.loads((ROOT/'state/primary_phase_c_gate.json').read_text())
    assert not any(v.get('authorized') for v in gate['models'].values()),'Prioritize an eligible primary Phase C'
    names=[]
    for model,pool,slots,batches in (('ouro',22528,32,(1,8,16,24)),('huginn',26624,8,(1,2,3))):
        name=f'phase_a_{model}_short_output_diagnostic_start0'
        c=base(model,name)
        c.update(slots=slots,capacity=slots,chunk=2048,kv_blocks=pool,estimated_seconds=600,
            phase='short_output_diagnostic_capacity',
            diagnostic_scope='Preregistered 3500/32 controlled diagnostic. Does not replace the primary 128-256 output grid.',
            groups=[dict(chunk=2048,kv_blocks=pool,jobs=[dict(cell='D32',dataset='test_L3500.json',batch=b,cap=32,repeats=3) for b in batches])])
        names.append(save(c))
        c=pd_config(model,f'phase_a_{model}_short_output_prepared_pd_start0','D32',max(batches),100.)
        c.update(slots=slots,capacity=slots,chunk=2048,token_budget=2048,kv_blocks=pool,
            arrival_offsets=[0.]*c['count'],prepare_D_only=True,prepared_reference_run=name,
            phase='short_output_diagnostic_capacity',estimated_seconds=300)
        names.append(save(c))
    enqueue(names)


def optional_screen():
    from .b_capacity_plan import capacity
    names=[]
    for model,pool,slots in (('ouro',22528,32),('huginn',26624,8)):
        measured=capacity(model,'D32',2048,pool)
        path=ROOT/'raw'/f'phase_a_{model}_short_output_prepared_pd_start0'/'D_only_window.json'
        prepared=json.loads(path.read_text());assert prepared['native_output_parity']
        measured['mu_D']=min(measured['mu_D'],prepared['mu_D_finite'])
        measured['actual_prepared_PD_D']=prepared
        count=64;rate=.8*min(measured['mu_P'],measured['mu_D'])
        c=pd_config(model,f'phase_b_{model}_d32_diagnostic_start0','D32',count,rate)
        c.update(chunk=2048,token_budget=2048,slots=slots,capacity=slots,kv_blocks=pool,
            phase='focused_crossover',capacity_planning=measured,rate_factor=.8,estimated_seconds=600,
            diagnostic_scope='SECONDARY_SHORT_OUTPUT_CONTROLLED_DIAGNOSTIC_NOT_PRIMARY_GRID')
        names.append(save(c))
    enqueue(names)


def profile_expanded():
    old=json.loads((ROOT/'configs/phase_b_ouro_g3_expanded_start0.json').read_text())
    c=dict(old,name='profile_ouro_expanded_g3_v1',phase='profile',profile=True,
        profile_record_shapes=False,profile_schedule=dict(wait=200,active=400),estimated_seconds=600)
    enqueue([save(c)])


def main():
    actions=dict(tuned_g1=tuned_g1,optional_capacity=optional_capacity,optional_screen=optional_screen,profile_expanded=profile_expanded)
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=tuple(actions));actions[parser.parse_args().action]()


if __name__=='__main__':main()
