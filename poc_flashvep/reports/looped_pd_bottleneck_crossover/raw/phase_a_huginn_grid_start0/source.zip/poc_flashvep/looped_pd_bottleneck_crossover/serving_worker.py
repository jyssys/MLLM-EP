"""Qualified PD execution with reasoned admission and submission timestamps."""
import sys
import collections
from .common import *

def install():
    redirect()
    from ..adaptive_loop_token_pd_2gpu import worker as prior
    prior.install()
    from vllm_rlt.worker.executor import Executor
    from vllm_rlt.engine.stage_engine import StageEngine
    from vllm_rlt.core.scheduler import Scheduler
    from vllm_rlt.request import RequestPhase
    from vllm_rlt.pd.engine import PDEngine
    if getattr(Executor,'_bc_host_accounting',False):return
    Executor._bc_host_accounting=True
    first=set();frontiers=[];counts=collections.Counter();CPU=collections.defaultdict(float);snapshots=[]
    last_sample=[0.];schedule=Scheduler.schedule;submit=Executor.submit;close=StageEngine.close
    def schedule_host(self,*a,**kw):
        t=time.perf_counter();batch=schedule(self,*a,**kw);CPU['scheduler_s']+=time.perf_counter()-t
        counts['schedule_calls']+=1;now=time.monotonic()
        if now-last_sample[0]>.5:
            last_sample[0]=now
            phases=collections.Counter(str(r.phase) for r in self.requests.values())
            snapshots.append(dict(time=now,phases=dict(phases),queued={str(k):len(v) for k,v in self.queues.items()}))
        return batch
    def submit_host(self,batch):
        now=time.monotonic();counts['submissions']+=1;counts['rows']+=batch.num_rows
        counts[f'operation_{batch.operation.value}']+=1
        counts[f'rows_operation_{batch.operation.value}']+=batch.num_rows
        for item in batch.requests:
            r=item.request;p=batch.phase_for(item);rid=r.request_id
            if p in (RequestPhase.PREFILL,RequestPhase.PREFILLING_PRELUDE,RequestPhase.PREFILLING_RECURRENT):
                if rid not in first:
                    first.add(rid);frontiers.append(dict(event='P_FIRST_SUBMISSION',time=now,request_id=rid,
                        prompt_tokens=len(r.prompt_token_ids),seed=r.sampling_params.seed))
                if getattr(item,'completes_prompt',False):
                    frontiers.append(dict(event='P_FINAL_SUBMISSION',time=now,request_id=rid,
                        depth=getattr(item,'depth',None)))
        t=time.perf_counter();result=submit(self,batch);CPU['submit_s']+=time.perf_counter()-t
        return result
    def close_host(self):
        self.model_runner.synchronize()
        folder=ROOT/'raw'/config()['name']
        write(folder/f'host_execution_{os.getpid()}.json',dict(role=self.stage_config.role,CPU=dict(CPU),counts=dict(counts),
            frontiers=frontiers,queue_samples=snapshots,
            scope='Host CPU spans and submission timestamps. They are not CUDA kernel busy or exclusive E2E components.'))
        return close(self)
    Executor.submit=submit_host;Scheduler.schedule=schedule_host;StageEngine.close=close_host
    admit=PDEngine._admit;last_admission=[0.]
    def admit_host(self):
        now=time.monotonic()
        if now-last_admission[0]>.25:
            last_admission[0]=now;waiting=[]
            for w in self.transfers.values():
                if w.phase!='waiting':continue
                reasons=[]
                for role in ('prefill','decode'):
                    length=len(w.request.prompt_token_ids)+(w.request.sampling_params.max_tokens-1 if role=='decode' else 0)
                    peers=[p for p in self.peers.values() if p.role==role]
                    if not any(p.slots<p.client.info['transfer_slots'] for p in peers):reasons.append(role.upper()+'_NO_SLOT')
                    if not any(p.reserved_blocks+self._blocks(p,length)<=p.client.info['num_blocks']-(p.client.info['watermark_blocks'] if p.slots else 0) for p in peers):
                        reasons.append(role.upper()+'_NO_KV_CREDIT')
                waiting.append(dict(request_id=w.request.request_id,age_s=now-w.created,reasons=reasons))
            append(ROOT/'raw'/config()['name']/'admission_reasons.jsonl',dict(time=now,waiting=waiting,
                peers={n:dict(role=p.role,slots=p.slots,reserved_blocks=p.reserved_blocks,
                    total_blocks=p.client.info['num_blocks'],watermark_blocks=p.client.info['watermark_blocks']) for n,p in self.peers.items()}))
        return admit(self)
    PDEngine._admit=admit_host

if os.environ.get('BC_WORKER')=='1':install()

def main():
    install()
    from ..adaptive_loop_token_pd_2gpu import worker as prior
    prior.main()

if __name__=='__main__':main()
