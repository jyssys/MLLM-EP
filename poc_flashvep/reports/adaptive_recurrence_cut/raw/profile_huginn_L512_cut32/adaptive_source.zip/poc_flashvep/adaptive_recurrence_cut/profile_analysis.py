"""Compress profiler evidence without deleting originals. Separate sums and unions."""
import collections
import gzip
import hashlib
import json
from .common import ROOT,write
from .analyze import csv_write


def union(intervals):
    end=None;total=0.
    for left,right in sorted(intervals):
        if end is None or left>end:total+=right-left;end=right
        elif right>end:total+=right-end;end=right
    return total


def category(name):
    lower=name.lower()
    if 'flash' in lower or 'attention' in lower:return 'attention_name_match'
    if any(s in lower for s in ('gemm','xmma','cutlass','matmul')):return 'GEMM_name_match'
    if 'norm' in lower:return 'normalization_name_match'
    return 'other_or_unclassified'


def main():
    rows=[];shapes=[];archives=[]
    for folder in sorted((ROOT/'raw').glob('profile_*')):
        for path in folder.rglob('*.json'):
            if 'trace' not in path.name.lower():continue
            try:trace=json.loads(path.read_text())
            except (ValueError,UnicodeDecodeError):continue
            events=trace.get('traceEvents') if isinstance(trace,dict) else None
            if events is None:continue
            data=path.read_bytes();compressed=path.with_suffix(path.suffix+'.gz')
            if not compressed.exists():compressed.write_bytes(gzip.compress(data,mtime=0))
            archives.append(dict(file=str(path.relative_to(ROOT)),archive=str(compressed.relative_to(ROOT)),
                                 sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),compressed_bytes=compressed.stat().st_size))
            kernels=[e for e in events if e.get('cat')=='kernel' and 'dur' in e]
            copies=[e for e in events if e.get('cat') in ('gpu_memcpy','gpu_memset') and 'dur' in e]
            groups=collections.defaultdict(list)
            for event in kernels:groups[category(event['name'])].append(event)
            intervals=[(e['ts'],e['ts']+e['dur']) for e in kernels]
            busy=union(intervals)
            duration=max((b for a,b in intervals),default=0)-min((a for a,b in intervals),default=0)
            for kind,items in groups.items():
                rows.append(dict(name=folder.name,trace=str(compressed.relative_to(ROOT)),category=kind,
                                 actual_kernel_invocations=len(items),kernel_duration_sum_ms=sum(e['dur'] for e in items)/1000,
                                 category_union_ms=union([(e['ts'],e['ts']+e['dur']) for e in items])/1000,
                                 all_kernel_busy_union_ms=busy/1000,kernel_window_ms=duration/1000,
                                 all_GPU_copy_events=len(copies),all_GPU_copy_duration_sum_ms=sum(e['dur'] for e in copies)/1000,
                                 evidence='MEASURED_PROFILE',
                                 limitation='Kernel-name classification. Overlapping sums are not exclusive E2E components. Copies are not identified as KV-only.'))
            counts=collections.Counter()
            for e in events:
                if e.get('cat')=='cpu_op' and e.get('name') in ('aten::mm','aten::addmm','aten::linear'):
                    counts[(e['name'],json.dumps(e.get('args',{}).get('Input Dims','NOT_RECORDED')))]+=1
            for (operation,shape),count in counts.items():
                shapes.append(dict(name=folder.name,trace=str(compressed.relative_to(ROOT)),operation=operation,
                                   input_dims=shape,observed_CPU_invocations=count,
                                   limitation='CUDA Graph replays do not execute Python/aten dispatch again. Not total replayed GEMM count.'))
    csv_write('profiler_kernel_breakdown.csv',rows);csv_write('profiler_observed_GEMM_shapes.csv',shapes)
    write(ROOT/'configs/profiler_archives.json',archives)
    print('PROFILE_TRACES',len(archives),'KERNEL_ROWS',len(rows))


if __name__=='__main__':main()
