"""List completed, failed, and unexecuted configurations without filling gaps."""
import json
from .common import ROOT
from .analyze import csv_write


def main():
    rows=[]
    for path in sorted((ROOT/'configs').glob('*.json')):
        cfg=json.loads(path.read_text())
        if not isinstance(cfg,dict) or not {'name','model','gpus','cut'}<=set(cfg):continue
        status=ROOT/'raw'/cfg['name']/'status.json'
        state=json.loads(status.read_text()) if status.exists() else dict(status='NOT_RUN')
        for cell in cfg.get('cohorts',[cfg]):
            rows.append(dict(name=cfg['name'],cohort=cell.get('cohort_id','single'),model=cfg['model'],
                             cut=cell['cut'],gpus=','.join(map(str,cfg['gpus'])),GPU_budget=len(cfg['gpus']),
                             requests=cfg['count'],prompt_manifest=cfg['dataset'],chunk_tokens=cfg['chunk'],
                             output_caps=cell.get('request_caps',[cfg['cap']]),state_capacity_tokens=cfg['state_capacity_tokens'],
                             Native_Mixed=False,status=state['status'],error=state.get('error',''),
                             heavy_probe=bool(cfg.get('verify_transfer') or cfg.get('state_probe')),
                             state_trigger=bool(cell.get('ready_background_requests')),
                             config=str(path.relative_to(ROOT))))
    csv_write('experiment_matrix.csv',rows)
    print('CONFIGURATION_CELLS',len(rows))


if __name__=='__main__':main()
