"""Reconcile transport payload accounting with actual NIXL byte counters."""
import json
from .common import ROOT,write
from .gate import read
from .analyze import csv_write,quantile


def main():
    output=[]
    for folder in sorted((ROOT/'raw').glob('map_*')):
        if not (folder/'status.json').exists() or json.loads((folder/'status.json').read_text())['status']!='COMPLETE':continue
        cfg=json.loads((folder/'arc_contract.json').read_text())
        records=[r for p in folder.glob('migration_*.jsonl') for r in read(p)]
        for path in folder.glob('cohort_*_stats.json'):
            values=json.loads(path.read_text());contract=values['contract'];cohort=contract['cohort_id']
            window=json.loads((folder/f'window_{cohort}.json').read_text())
            payloads=[r for r in records if window['start']<=r['time']<=window['end']]
            actual=sum(values['after'][k]['transport_bytes_sent']-values['before'][k]['transport_bytes_sent'] for k in values['before'])
            accounted=sum(r['KV_bytes']+r['hidden_bytes'] for r in payloads)
            output.append(dict(name=folder.name,model=cfg['model'],cohort=cohort,cut=contract['cut'],
                               actual_NIXL_bytes_sent=actual,KV_payload_bytes=sum(r['KV_bytes'] for r in payloads),
                               hidden_payload_bytes=sum(r['hidden_bytes'] for r in payloads),
                               payload_reconciled=actual==accounted,source_exports=len(payloads),
                               fragments=sum(r['fragments'] for r in payloads),descriptors=sum(r['descriptors'] for r in payloads),
                               control_metadata_bytes='NOT_MEASURED',
                               evidence='MEASURED_NIXL_COUNTERS_AND_TRANSPORT_ACCOUNTING',
                               transfer_time='Host observation only. Pure DMA latency NOT_MEASURED.'))
    csv_write('migration_payloads.csv',output)
    write(ROOT/'state/migration_validation.json',dict(rows=len(output),reconciled=sum(r['payload_reconciled'] for r in output)))
    print('PAYLOADS',sum(r['payload_reconciled'] for r in output),'/',len(output))


if __name__=='__main__':main()
