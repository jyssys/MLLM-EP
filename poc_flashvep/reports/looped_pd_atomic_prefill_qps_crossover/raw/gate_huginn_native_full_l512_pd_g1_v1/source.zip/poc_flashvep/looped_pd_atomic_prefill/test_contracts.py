"""CPU checks for context, indivisible Prompt budgets, and Poisson traces."""
import unittest
from .common import *
from .configs import finish


class ContractTests(unittest.TestCase):
    def test_context_limits(self):
        for m,cells in GRID.items():
            for length,cap in cells:self.assertLessEqual(length+cap,CONTEXT_LIMITS[m])
    def test_full_prompt_budget(self):
        for m,cells in GRID.items():
            for length,cap in cells:
                c=base(m,'cpu_only',length,cap)
                self.assertGreaterEqual(c['token_budget'],length)
                self.assertEqual(c['token_budget']%length,0)
    def test_actual_poisson_offsets_change_with_rate(self):
        a=finish(base('qwen8','cpu_only',8000,200),count=8,rate=1.)
        b=finish(base('qwen8','cpu_only',8000,200),count=8,rate=2.)
        self.assertEqual(a['prompt_ids'],b['prompt_ids'])
        self.assertEqual(a['arrival_offsets'],[2*v for v in b['arrival_offsets']])
        self.assertTrue(all(a['arrival_offsets'][i]<a['arrival_offsets'][i+1] for i in range(7)))
    def test_full_is_not_a_wire_fragment_count(self):
        c=finish(base('huginn','cpu_only',3900,32),count=2)
        self.assertTrue(c['atomic_prompt']);self.assertEqual(c['depth'],32)


if __name__=='__main__':unittest.main()
