"""Run one isolated job. Preserve failures and restore verified owned burners."""
import argparse
import signal
import subprocess
import zipfile
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--keep-quiet',action='store_true');a=p.parse_args()
    setup();from .bootstrap import preserve
    preserve();path=ROOT/'configs'/a.name;cfg=json.loads(path.read_text());folder=ROOT/'raw'/cfg['name']
    if folder.exists():
        status=folder/'status.json'
        if status.exists() and json.loads(status.read_text())['status']=='COMPLETE':return
        raise FileExistsError('Preserve failed or incomplete namespace: '+cfg['name'])
    from .resources import inherited as resources
    resources.stop(list(range(8)));folder.mkdir(exist_ok=False)
    write(folder/'configuration.json',cfg)
    with zipfile.ZipFile(folder/'source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for package in ('looped_pd_atomic_prefill','looped_pd_bottleneck_crossover','adaptive_loop_token_pd_2gpu',
            'adaptive_recurrence_cut','looped_pd_abc','looped_pd_b_numerical_diagnosis'):
            for source in (REPO/'poc_flashvep'/package).rglob('*.py'):z.write(source,str(source.relative_to(REPO)))
        z.writestr('RLT_private_diff.patch',subprocess.check_output(['git','diff','--binary'],cwd=RLT))
    env=environment(cfg['gpus']);env.update(ARC_CONFIG=str(path),ARC_RUN=cfg['name'],ABC_LANE='isolated_atomic_pd')
    sources=[p for p in SOURCE.glob('*.py') if p.name in ('common.py','runtime.py','rlt_worker.py','ar_worker.py','capacity_worker.py')]
    env['ATOMIC_SOURCE_HASHES']=json.dumps({str(p):digest(p) for p in sources})
    command=[str(PYTHON),'-m','poc_flashvep.looped_pd_atomic_prefill.'+cfg['worker'],str(path)]
    if cfg.get('nsys'):
        command=['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node',
            '--trace-fork-before-exec=true','--force-overwrite=false','--output='+str(folder/'nsys_report')]+command
    child=None;interrupted=[False]
    def request_stop(*args):interrupted[0]=True
    signal.signal(signal.SIGTERM,request_stop);signal.signal(signal.SIGINT,request_stop)
    try:
        with (ROOT/'logs'/(cfg['name']+'.log')).open('w') as log:
            child=subprocess.Popen(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            append(ROOT/'commands.jsonl',dict(time=time.time(),name=cfg['name'],pid=child.pid,command=command,gpus=cfg['gpus'],
                repo_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
                source_archive_SHA256=digest(folder/'source.zip'),config_SHA256=digest(path),clean=True))
            print('START',cfg['name'],child.pid,flush=True);deadline=time.monotonic()+cfg.get('timeout',3600)+900
            stopped=None
            while child.poll() is None:
                if interrupted[0] or time.monotonic()>deadline:
                    assert os.getsid(child.pid)==child.pid
                    if stopped is None:os.killpg(child.pid,signal.SIGTERM);stopped=time.monotonic()
                    elif time.monotonic()-stopped>30:os.killpg(child.pid,signal.SIGKILL)
                time.sleep(.5)
            write(folder/'dispatcher_result.json',dict(time=time.time(),pid=child.pid,returncode=child.returncode,watchdog_or_signal=stopped is not None))
            print('END',cfg['name'],child.returncode,flush=True)
            assert child.returncode==0,'Job failed. Preserve its complete log.'
            status=folder/'status.json'
            assert status.exists() and json.loads(status.read_text())['status']=='COMPLETE','Missing valid terminal worker status'
    finally:
        if child is None or child.poll() is not None:
            if not a.keep_quiet and not resources.processes():resources.restore(list(range(8)))


if __name__=='__main__':main()
