"""Compare clean and Nsight P-only cohorts. Do not infer Serving speedup."""
import copy
import sqlite3
import subprocess
from .common import *
from .evidence import status,records
from .extension_discovery import enqueue
from .profiles import union

PLAN=ROOT/'state/P_duty_diagnostic_plan_20261102.json'


def plan():
    if PLAN.exists():return
    cases=[('ouro','qual_ouro_d128_kv25088_l8192_o32_v1',[1,4,8]),
        ('huginn','ext_huginn_sync_g4_qualification8_v1',[1,2,3])];new=[]
    for model,source,batches in cases:
        source=json.loads((ROOT/'configs'/(source+'.json')).read_text())
        for profiled in (False,True):
            c=copy.deepcopy(source);c.update(name=f'diagnostic_P_duty_{model}_{"profile" if profiled else "clean"}_v1',
                worker='p_duty_worker',capacity_mode='P_ONLY',phase='independent_capacity',P_duty_diagnostic=True,
                nsys=profiled,nsys_graph_trace='node',verify_transfer=False,state_probe=False,gpus=[0],timeout=1800,
                jobs=[dict(batch=b,cap=1,repeats=3) for b in batches],
                scope='P-only device-activity diagnostic. Same qualified model, BF16, full depth, and numerical fixes. No NIXL or D reservation. Not measured online capacity.')
            new.append(c)
    enqueue(new);write(PLAN,dict(time=time.time(),configs=[c['name'] for c in new]))


def analyze():
    from .analyze import save_csv
    output=[];summary=[]
    for model in ('ouro','huginn'):
        name=f'diagnostic_P_duty_{model}_profile_v1';clean=f'diagnostic_P_duty_{model}_clean_v1'
        if status(name)!=status(clean) or status(name)!='COMPLETE':continue
        folder=ROOT/'raw'/name;database=folder/'nsys_report.sqlite';report=folder/'nsys_report.nsys-rep'
        if not database.exists():
            result=subprocess.run(['nsys','export','--type=sqlite','--force-overwrite=false','--output='+str(database),str(report)],text=True,capture_output=True)
            write(folder/'nsys_export_result.json',dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
            if result.returncode:continue
        conn=sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True);conn.row_factory=sqlite3.Row
        strings={r['id']:r['value'] for r in conn.execute('SELECT * FROM StringIds')}
        nvtx={}
        for r in conn.execute('SELECT * FROM NVTX_EVENTS WHERE end IS NOT NULL'):
            label=r['text'] if r['text'] else strings.get(r['textId'],'')
            if label.startswith('APD_P_DUTY|'):nvtx[label]=r
        actual={r['tag']:r for r in records(folder/'cohorts.jsonl')}
        references={r['tag']:r for r in records(ROOT/'raw'/clean/'cohorts.jsonl')}
        for anchor in records(folder/'p_duty_anchors.jsonl'):
            marker=nvtx[anchor['marker']];a,b=anchor['P_interval'];zero=marker['start'];origin=anchor['anchor_monotonic']
            lo=zero+round((a-origin)*1e9);hi=zero+round((b-origin)*1e9);intervals=[];copies=[];count=0
            for r in conn.execute('SELECT start,end,globalPid FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE end>? AND start<?',(lo,hi)):
                pid=r['globalPid'] if r['globalPid']==anchor['pid'] else (r['globalPid']>>24)&0xffffff
                if pid!=anchor['pid']:continue
                intervals.append((max(lo,r['start']),min(hi,r['end'])));count+=1
            tables={r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if 'CUPTI_ACTIVITY_KIND_MEMCPY' in tables:
                for r in conn.execute('SELECT start,end,globalPid FROM CUPTI_ACTIVITY_KIND_MEMCPY WHERE end>? AND start<?',(lo,hi)):
                    pid=r['globalPid'] if r['globalPid']==anchor['pid'] else (r['globalPid']>>24)&0xffffff
                    if pid==anchor['pid']:copies.append((max(lo,r['start']),min(hi,r['end'])))
            tag=anchor['tag'];reference=references[tag];candidate=actual[tag]
            parity=candidate['outputs']==reference['outputs'] and candidate['input_ids']==reference['input_ids']
            overhead=(b-a)/reference['prefill_host_service_s']-1;busy=union(intervals)/(hi-lo)
            value=dict(model=model,batch=anchor['batch'],tag=tag,clean_P_host_service_ms=1000*reference['prefill_host_service_s'],
                profiled_P_host_service_ms=1000*(b-a),profile_wall_overhead_fraction=overhead,exact_output_parity=parity,
                recorded_P_kernel_busy_fraction=busy,recorded_P_kernel_and_copy_union_fraction=union(intervals+copies)/(hi-lo),
                recorded_kernel_invocations=count,recorded_copy_events=len(copies),
                profile_eligible_for_matched_clean=abs(overhead)<=.05 and parity,
                full_depth_rows=anchor['full_depth_rows'],observed_full_depth_rows=anchor['observed_full_depth_rows'],
                evidence='MEASURED_NSYS_LOCAL_P_SERVICE',
                scope='Local qualified P-only cohort, not native online PD. A non-kernel gap is not automatically CPU overhead or GPU idle. No architectural impossibility or E2E speedup follows.')
            output.append(value)
        conn.close()
    for model in ('ouro','huginn'):
        for batch in sorted({r['batch'] for r in output if r['model']==model}):
            values=[r for r in output if r['model']==model and r['batch']==batch]
            summary.append(dict(model=model,batch=batch,within_start_repeats=len(values),
                clean_host_service_ms_mean=sum(r['clean_P_host_service_ms'] for r in values)/len(values),
                recorded_kernel_fraction_mean=sum(r['recorded_P_kernel_busy_fraction'] for r in values)/len(values),
                matched_profile_pairs_within_5_percent=sum(r['profile_eligible_for_matched_clean'] for r in values),
                scope='Three within-start repeats. No independent-start confidence interval. Not a proven ceiling for every supported native P configuration.'))
    save_csv('p_duty_windows.csv',output);save_csv('p_duty_summary.csv',summary);write(ROOT/'p_duty_summary.json',summary);return summary


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('plan','analyze'));args=parser.parse_args()
    if args.action=='plan':plan()
    else:analyze()
