"""Keep bounded colocated tuning available at newly qualified long-input cells."""
from .common import *
from .configs import finish
from .evidence import status,compare,full_work

CONTROL_KEYS=('token_budget','kv_blocks','wavefront','scheduler_mode','native_mixed')


def controls(cfg):
    return {key:cfg[key] for key in CONTROL_KEYS if key in cfg}


def qualification():
    from .search import configured_base
    new=[]
    for model,length,cap in [('huginn',3500,32),('ouro',16384,100)]:
        if model=='ouro':
            p=ROOT/'state/optional16k_gate.json'
            if not p.exists() or not json.loads(p.read_text()).get('passed'):continue
        # This is a bounded generic scheduler/memory control, not a new method.
        reference=configured_base(model,f'qual_{model}_colocated_control_reference_l{length}_o{cap}_v1',length,cap,
            phase='long_correctness',gpus=[0,1],D_token_budget=128,
            D_kv_blocks=28288 if model=='huginn' else 25088)
        new.append(finish(reference,8,rate=.5 if model=='huginn' else 1.))
        variants=[('separate_full','DP',length,None,None,False),
            ('separate_c1024','DP',1024,None,None,False),
            ('mixed_c256','DP_Mixed',256,None,None,True),
            ('mixed_compact_c256','DP_Mixed',256,2048 if model=='huginn' else 4096,28288 if model=='huginn' else 25088,False)]
        for index,(label,arm,chunk,budget,blocks,wave) in enumerate(variants):
            c=configured_base(model,f'qual_{model}_colocated_{label}_l{length}_o{cap}_v1',length,cap,
                arm=arm,chunk=chunk,chunk_label='full' if chunk==length else str(chunk),
                phase='long_correctness',gpus=[2*(index%3),2*(index%3)+1],wavefront=wave)
            if budget is not None:c.update(token_budget=budget,kv_blocks=blocks)
            if arm=='DP_Mixed':c.update(worker='native_mixed_worker',scheduler_mode='mixed',atomic_prompt=False,native_mixed=True)
            c=finish(c,8,rate=.5 if model=='huginn' else 1.)
            new.append(c)
    return new


def pilots():
    from .search import references,serving_config
    selected=references();gates={};new=[]
    for path in (ROOT/'configs').glob('qual_*_colocated_*_l*_o*_v1.json'):
        cfg=json.loads(path.read_text())
        if '_reference_' in cfg['name']:continue
        reference=f'qual_{cfg["model"]}_colocated_control_reference_l{cfg["length"]}_o{cfg["cap"]}_v1'
        result=compare(reference,cfg['name']) if status(reference)==status(cfg['name'])=='COMPLETE' else dict(passed=False,status=status(cfg['name']),reference_status=status(reference))
        if result['passed']:
            result['work']=full_work(cfg['name']);result['passed'] &= result['work']['passed']
        # An otherwise correct native Mixed run need not form a mixed batch
        # at every arrival rate. Record the actual composition separately.
        gates[cfg['name']]=result
        if not result['passed']:continue
        cell=selected[cfg['model']+'_L'+str(cfg['length'])]
        mu=min(max(v['mu_P'] for v in cell['chunks'].values()),cell['D'][str(cfg['cap'])]['mu_D'])
        label=cfg['name'].split('_colocated_',1)[1].split('_l',1)[0]
        for factor in (.75,1.,1.25):
            name=f'pilot_{cfg["model"]}_l{cfg["length"]}_o{cfg["cap"]}_colocated_{label}_f{str(factor).replace(".","p")}_v1'
            c=serving_config(cell,name,cfg['cap'],cfg['chunk'],'qps_pilot',24,rate=mu*factor,arm=cfg['arm'])
            c.update(controls(cfg),worker=cfg['worker'],rate_factor=factor,reference_capacity=mu,
                control_scope='Bounded existing colocated scheduler tuning at a newly qualified cell. Full BF16 depth and numerical fixes remain unchanged. Not a new mechanism.')
            new.append(c)
    write(ROOT/'state/colocated_extra_gates.json',gates)
    return new
