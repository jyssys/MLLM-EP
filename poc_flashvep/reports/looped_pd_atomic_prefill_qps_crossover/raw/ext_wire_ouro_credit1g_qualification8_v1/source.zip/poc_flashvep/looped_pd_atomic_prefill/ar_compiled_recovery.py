"""Gate the official compiled batch-invariant, graph-NONE AR control."""
import copy
from .common import *
from .configs import finish
from .evidence import compare,status,rows
from .extension_discovery import enqueue
from .extension_runtime_controls import terminal

PATH=ROOT/'state/ar_compiled_recovery_20261102.json'
FAMILY='BI_COMPILED_NO_GRAPH'


def advance():
    state=json.loads(PATH.read_text()) if PATH.exists() else dict(stage='QUALIFICATION32')
    reference='ext_qwen_bi_compiled_no_graph_qualification32_reference_v1'
    if state['stage']=='QUALIFICATION32':
        names=[f'ext_qwen_bi_compiled_no_graph_qualification32_{label}_v1' for label in ('reference','repeat','dp2','dp2_repeat','c4096')]
        if not terminal(names):return state
        gates={label:compare(reference,f'ext_qwen_bi_compiled_no_graph_qualification32_{label}_v1') for label in ('repeat','dp2','dp2_repeat','c4096')}
        if not gates['repeat']['passed']:
            state.update(stage='BLOCKED_QUALIFICATION32',gates=gates);write(PATH,state);return state
        source=json.loads((ROOT/'configs'/(reference+'.json')).read_text());new=[]
        for chunk in (8000,4096):
            if chunk!=8000 and not gates['c4096']['passed']:continue
            c=copy.deepcopy(source);c.update(name=f'capacity_qwen8_ext_bi_compiled_none_c{chunk}_p_v1',worker='ar_capacity',
                capacity_mode='P_ONLY',phase='independent_capacity',gpus=[0],chunk=chunk,chunk_label='full' if chunk==8000 else str(chunk))
            c=finish(c,8);c['P_slots']=8;c['jobs']=[dict(batch=b,cap=1,repeats=3) for b in (1,2,4,8)];new.append(c)
        c=copy.deepcopy(source);c.update(name='capacity_qwen8_ext_bi_compiled_none_prefix_D_v1',worker='ar_prefix_capacity',
            phase='independent_capacity',capacity_mode='PREPARED_D',gpus=[0],jobs=[dict(batch=b,cap=200,repeats=3) for b in (1,4,8,16,32)])
        c=finish(c,32);new.append(c)
        c=copy.deepcopy(source);c.update(name='ext_calibration_qwen8_bi_compiled_none_l8000_v1',phase='calibration',
            gpus=[0,1],calibration_serial=True,timeout=1800)
        c=finish(c,16,split='calibration');new.append(c)
        enqueue(new);state.update(stage='CAPACITY_AND_CALIBRATION',gates=gates,source=source,costs=[c['name'] for c in new]);write(PATH,state)
    if state['stage']=='CAPACITY_AND_CALIBRATION' and terminal(state['costs']):
        from .analyze import capacity,percentile
        from ..looped_pd_bottleneck_crossover.analyze_serving import token_intervals
        samples=[r for r in capacity() if r.get('execution_family')==FAMILY and r['model']=='qwen8' and r['length']==8000]
        p=[r for r in samples if r['capacity_mode']=='P_ONLY'];d=[r for r in samples if r['capacity_mode']=='PREPARED_D' and r['output_cap']==200]
        calibration='ext_calibration_qwen8_bi_compiled_none_l8000_v1';values=rows(calibration)
        if not p or not d or status(calibration)!='COMPLETE' or len(values)!=16:
            state.update(stage='BLOCKED_CAPACITY_OR_CALIBRATION',P_samples=len(p),D_samples=len(d),calibration_requests=len(values));write(PATH,state);return state
        chunks={}
        for chunk in sorted({r['chunk'] for r in p}):
            group=[r for r in p if r['chunk']==chunk];best=max(r['finite_requests_per_s_mean'] for r in group)
            selected=min((r for r in group if r['finite_requests_per_s_mean']>=.95*best),key=lambda r:r['batch'])
            chunks[str(chunk)]=dict(mu_P=selected['finite_requests_per_s_mean'],P_slots=selected['batch'],source=selected)
        bestD=max(d,key=lambda r:r['finite_requests_per_s_mean']);bestC=max(chunks,key=lambda k:chunks[k]['mu_P'])
        tuned=4096 if '4096' in chunks else int(bestC)
        cell=dict(model='qwen8',length=8000,chunks=chunks,best_chunk=int(bestC),tuned_chunk=tuned,
            D={'200':dict(mu_D=bestD['finite_requests_per_s_mean'],source=bestD)})
        reference_file='capacity_references_qwen8_bi_compiled_none_extension.json';write(ROOT/'configs'/reference_file,{'qwen8_L8000':cell})
        slo_file='frozen_SLO_qwen8_bi_compiled_none_extension.json'
        if not (ROOT/'configs'/slo_file).exists():
            write(ROOT/'configs'/slo_file,{'qwen8_L8000':dict(TTFT_ms=2*percentile([r['ttft_ms'] for r in values],.95),
                TPOT_ms=2*percentile([r['tpot_ms'] for r in values],.95),ITL_ms=2*percentile([v for r in values for v in token_intervals(r)[0]],.99),
                requests=16,calibration=calibration,rule='Same preregistered 2x serial request-p95 and token-p99 rule. Separate qualified execution family.',
                frozen_before_heldout_search=time.time(),not_a_hard_guarantee=True)})
        mu=min(max(v['mu_P'] for v in chunks.values()),bestD['finite_requests_per_s_mean']);new=[];source=state['source']
        dp=state['gates']['dp2']['passed'] and state['gates']['dp2_repeat']['passed']
        for arm in (('PD_G1','DP2') if dp else ('PD_G1',)):
            for chunk in sorted(map(int,chunks)):
                # C4096 DP is not yet a direct qualified control. Do not infer
                # its equality from either Full DP or chunked pure PD.
                if arm=='DP2' and chunk!=8000:continue
                for factor in (.25,.5,.75,1.,1.25,1.5,2.):
                    c=copy.deepcopy(source);c.update(name=f'ext_pilot_qwen8_bi_compiled_none_{arm.lower()}_c{chunk}_f{str(factor).replace(".","p")}_v1',
                        phase='qps_pilot',arm=arm,chunk=chunk,chunk_label='full' if chunk==8000 else str(chunk),gpus=[0,1],
                        capacity_reference_file=reference_file,SLO_file=slo_file,reference_capacity=mu,rate_factor=factor)
                    c=finish(c,24,rate=mu*factor)
                    c['P_slots']=chunks[str(chunk)]['P_slots'] if arm=='PD_G1' else 32
                    new.append(c)
        enqueue(new);state.update(stage='QPS_PILOTS',pilots=[c['name'] for c in new],reference_capacity=mu,
            capacity_reference_file=reference_file,SLO_file=slo_file);write(PATH,state)
    if state['stage']=='QPS_PILOTS' and terminal(state['pilots']):
        state.update(stage='PILOTS_COMPLETE',time=time.time());write(PATH,state)
    return state


if __name__=='__main__':advance()
