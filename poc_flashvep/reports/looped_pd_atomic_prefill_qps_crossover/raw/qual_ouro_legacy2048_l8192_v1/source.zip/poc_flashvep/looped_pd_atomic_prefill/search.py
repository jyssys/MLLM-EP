"""Advance the declared discovery stages from actual completed evidence."""
import statistics
import random
from .common import *
from .configs import finish
from .evidence import records,rows,status,qualify,compare,atomic,transfer,full_work

STATE=ROOT/'state/search_stage.json'
LOCAL_REFERENCE_VERSION='v2'


def enqueue(configurations,stage):
    names=[save_config(c) for c in configurations]
    path=ROOT/'configs/study_plan.json';plan=json.loads(path.read_text())
    write(path,dict(configs=list(dict.fromkeys(plan['configs']+names))))
    write(STATE,dict(time=time.time(),stage=stage,generated=names))
    append(ROOT/'state/search_transitions.jsonl',dict(time=time.time(),stage=stage,configs=names))
    print('SEARCH_STAGE',stage,len(names),flush=True)
    return bool(names)


def allowed():
    path=ROOT/'state/model_gates.json'
    return json.loads(path.read_text()) if path.exists() else {}


def short_gates():
    gates={};new=[]
    for model in ('qwen8','ouro','huginn'):
        candidate=f'gate_{model}_native_full_l512_pd_g1_'+('v2' if model=='qwen8' else 'v1')
        reference='gate_qwen8_native_full_l512_dp2_v1' if model=='qwen8' else f'gate_{model}_legacy_g1_l512_v1'
        if status(candidate)!='COMPLETE' or status(reference)!='COMPLETE':
            gates[model]=dict(passed=False,stage='SHORT',reason='Missing successful gate namespace',candidate_status=status(candidate),reference_status=status(reference));continue
        result=qualify(model,reference,candidate);gates[model]=result
        if not result['passed']:continue
        length=8000 if model=='qwen8' else 8192 if model=='ouro' else 3900
        count=8;cap=16
        if model=='qwen8':
            for arm in ('PD_G1','DP2'):
                c=base(model,f'qual_{model}_full_l{length}_{arm.lower()}_v1',length,cap,arm=arm,phase='long_correctness')
                new.append(finish(c,count))
        else:
            c=base(model,f'qual_{model}_local_l{length}_v1',length,cap,worker='reference_worker',phase='long_correctness',state_probe=True)
            c['gpus']=c['gpus'][:1];new.append(finish(c,count))
            for label,chunk,wave in (('full',length,False),('legacy2048',2048,True)):
                c=base(model,f'qual_{model}_{label}_l{length}_v1',length,cap,chunk=chunk,chunk_label=label,wavefront=wave,
                    phase='long_correctness',state_probe=True,verify_transfer=True)
                new.append(finish(c,count))
    write(ROOT/'state/model_gates.json',gates)
    return enqueue(new,'LONG_QUALIFICATION')


def native_reference_qualification(model,candidate,reference):
    folder=ROOT/'raw'/reference;refs=records(folder/'references.jsonl')
    actual=rows(candidate);ref=refs[-1] if refs else None
    expected={int(k.rsplit('_q',1)[1]):v for k,v in ref['outputs'].items()} if ref else {}
    exact=bool(actual) and len(actual)==len(expected) and all(r['output_ids']==expected[r['sample_id']]['output_ids'] and
        r['exit_depths']==expected[r['sample_id']]['depths'] for r in actual)
    def state_map(name):
        return {(r['seed'],r['prompt_tokens']):(r['hidden_sha256'],r['planes']) for p in (ROOT/'raw'/name).glob('prompt_states_*.jsonl') for r in records(p)}
    a=state_map(candidate);b=state_map(reference)
    state_exact=bool(actual) and all(a.get((r['seed'],r['input_tokens']))==b.get((r['seed'],r['input_tokens'])) and (r['seed'],r['input_tokens']) in a for r in actual)
    result=dict(model=model,reference=reference,candidate=candidate,output_sequences=len(actual),exact_output_parity=exact,
        exact_valid_KV_hidden_state=state_exact,transfer=transfer(candidate),work=full_work(candidate),atomic=atomic(candidate),
        scope='Internal finite original-runtime reference, not original HF or answer accuracy.')
    result['passed']=exact and state_exact and all(result[k]['passed'] for k in ('transfer','work','atomic'))
    return result


def long_gates():
    gates=allowed()
    for model,gate in list(gates.items()):
        if not gate['passed']:continue
        length=8000 if model=='qwen8' else 8192 if model=='ouro' else 3900
        candidate=f'qual_{model}_full_l{length}_'+('pd_g1_v1' if model=='qwen8' else 'v1')
        reference=f'qual_{model}_full_l{length}_dp2_v1' if model=='qwen8' else f'qual_{model}_local_l{length}_{LOCAL_REFERENCE_VERSION}'
        if any(status(n)!='COMPLETE' for n in (candidate,reference)):
            gates[model]=dict(passed=False,stage='LONG',reason='Long qualification did not complete');continue
        if model=='qwen8':result=qualify(model,reference,candidate)
        else:
            result=native_reference_qualification(model,candidate,reference)
            legacy=f'qual_{model}_legacy2048_l{length}_v1'
            result['legacy_output_comparison']=compare(legacy,candidate) if status(legacy)=='COMPLETE' else dict(passed=False,reason='Legacy long gate failed')
            result['passed'] &= result['legacy_output_comparison']['passed']
        gates[model]=result
    write(ROOT/'state/model_gates.json',gates)
    return enqueue(capacity_configs(gates),'CAPACITY')


def capacity_configs(gates):
    new=[]
    for model,gate in gates.items():
        if not gate['passed']:continue
        for length in sorted({n for n,cap in GRID[model] if n!=16384}):
            caps=sorted({cap for n,cap in GRID[model] if n==length},reverse=True)
            primary=(length==8000 if model=='qwen8' else length==8192 if model=='ouro' else length==3900)
            chunks=[256,1024,2048,4096,length] if primary else [length]
            effective=[]
            for chunk in chunks:
                size=min(chunk,length)
                if size not in effective:effective.append(size)
            for chunk in effective:
                label='full' if chunk==length else str(chunk)
                c=base(model,f'capacity_{model}_l{length}_p_chunk{label}_v1',length,max(caps),chunk=chunk,chunk_label=label,
                    worker='ar_capacity' if model=='qwen8' else 'capacity_worker',phase='independent_capacity',capacity_mode='P_ONLY')
                c['gpus']=c['gpus'][:1];c=finish(c,8)
                c['jobs']=[dict(batch=b,cap=1,repeats=3) for b in (1,2,4)]
                # Local slots and source PD slots are explicit in the measured geometry.
                if model!='qwen8':c.update(capacity=4,slots=4)
                new.append(c)
            c=base(model,f'capacity_{model}_l{length}_d_v1',length,max(caps),worker='ar_capacity' if model=='qwen8' else 'capacity_worker',
                phase='independent_capacity',capacity_mode='PREPARED_D')
            c=finish(c,8);c['gpus']=c['gpus'][-1:]
            batches=(1,2,4,8,16) if model=='qwen8' else (1,2,4,8)
            c['jobs']=[dict(batch=b,cap=cap,repeats=3) for cap in caps for b in batches]
            if model=='qwen8':
                c['count']=max(batches)
                c=finish(c,c['count'])
            new.append(c)
    return new


def advance():
    state=json.loads(STATE.read_text()) if STATE.exists() else dict(stage='SHORT_GATES')
    if state['stage']=='SHORT_GATES':return short_gates()
    if state['stage']=='LONG_QUALIFICATION':return long_gates()
    # Later stages are installed before their dependent GPU queue can drain.
    write(ROOT/'state/search_waiting.json',dict(time=time.time(),stage=state['stage'],reason='CPU preparation of the next declared stage is still active.'))
    time.sleep(5)
    return True
