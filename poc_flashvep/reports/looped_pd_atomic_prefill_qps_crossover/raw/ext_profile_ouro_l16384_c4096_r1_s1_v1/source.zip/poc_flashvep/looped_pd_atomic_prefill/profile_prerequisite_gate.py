"""Avoid repeated heavy traces after a clean prerequisite already failed."""
from .common import *


def retained_profiles(entries):
    keep={v['name'] for v in entries if v['near_P_service']}
    keep.update(v['name'] for v in entries if v['state']!='PENDING')
    for chunk in {v['chunk'] for v in entries}:
        group=[v for v in entries if v['chunk']==chunk]
        if any(v['state'] in ('COMPLETE','INCOMPLETE') for v in group):continue
        # Keep one root-cause trace even if no point passes the service gate.
        root=max(group,key=lambda v:v['P_completion_rate'])
        keep.add(root['name'])
    return keep


def advance():
    # Only the serial queue owner can prune. It calls this between GPU jobs.
    # Unit tests, workers, and the concurrent manager cannot change the queue.
    words=Path('/proc/self/cmdline').read_bytes().split(b'\0')
    if b'poc_flashvep.looped_pd_atomic_prefill.campaign' not in words:return
    from .campaign import terminal
    from .extension_confirmation import measured_screen
    state_path=ROOT/'state/extension_confirmation_20261102.json'
    if not state_path.exists():return
    state=json.loads(state_path.read_text())
    for model in ('ouro','huginn'):
        marker=ROOT/'state'/f'profile_prerequisite_gate_{model}_20261102.json'
        item=state.get(model,{})
        if marker.exists() or item.get('stage')!='FINAL_RUNS':continue
        center=[name for name in item['finals'] if json.loads((ROOT/'configs'/(name+'.json')).read_text()).get('rate_index')==1]
        if not center or any(terminal(name)!='COMPLETE' for name in center):continue
        entries=[]
        for name in item['profiles']:
            cfg=json.loads((ROOT/'configs'/(name+'.json')).read_text());clean=cfg['profile_clean_reference']
            screen=measured_screen(json.loads((ROOT/'configs'/(clean+'.json')).read_text()))
            if screen is None:break
            entries.append(dict(name=name,clean=clean,chunk=cfg['chunk'],state=terminal(name),
                near_P_service=screen['checks']['P_near_finite_service'],
                P_completion_rate=float(screen['run'].get('P_completion_rate_central') or 0),strongest_P_reference=screen['finite_P']))
        if len(entries)!=len(item['profiles']):continue
        keep=retained_profiles(entries);path=ROOT/'state/skipped_jobs.json'
        skips=json.loads(path.read_text()) if path.exists() else {};omitted=[]
        for value in entries:
            if value['name'] in keep or value['state']!='PENDING':continue
            assert not (ROOT/'raw'/value['name']).exists(),'Never prune an attempted namespace'
            skips[value['name']]=dict(time=time.time(),status='NOT_RUN_FAILED_STRONG_P_SERVICE_PREREQUISITE',
                source_clean=value['clean'],observed_P_completion=value['P_completion_rate'],
                required_P_completion=.85*value['strongest_P_reference'],
                scope='All three independent clean starts remain measured. Keep one root-cause trace per chunk and every service-qualified profile. No workload or acceptance threshold changes.')
            omitted.append(value['name'])
        write(path,skips);write(marker,dict(time=time.time(),entries=entries,retained=sorted(keep),omitted=omitted,
            scope='Serial queue-owner fail-fast step between jobs. Preserve completed and active traces. Do not infer missing CUDA activity or delete failed evidence.'))


if __name__=='__main__':raise SystemExit('This gate runs only inside the serial campaign between jobs.')
