"""Recover native AR comparisons only through explicit equality gates."""
import copy
from .common import *
from .configs import finish
from .evidence import compare,status,rows
from .extension_discovery import enqueue
from .extension_runtime_controls import terminal

PATH=ROOT/'state/ar_recovery_20261102.json'


def advance():
    state=json.loads(PATH.read_text()) if PATH.exists() else dict(stage='WAIT_TRUE_BI_EAGER24')
    if state['stage']=='WAIT_TRUE_BI_EAGER24':
        a='ext_qwen_bi_eager_pd_qualification24_s0_v2';b='ext_qwen_bi_eager_pd_qualification24_s1_v2'
        if not terminal([a,b]):return state
        gate=compare(a,b) if status(a)==status(b)=='COMPLETE' else dict(passed=False)
        if not gate['passed']:
            state.update(stage='BLOCKED_TRUE_BI_EAGER24',gate=gate);write(PATH,state);return state
        source=json.loads((ROOT/'configs'/(a+'.json')).read_text());new=[]
        pool=json.loads((ROOT/'data/test_qwen8_L8000.json').read_text())[32:64]
        dataset='extension_qualification32_qwen8_L8000.json';write(ROOT/'data'/dataset,pool)
        for label,arm,chunk,rate in [('reference','PD_G1',8000,2.),('repeat','PD_G1',8000,4.),('dp2','DP2',8000,4.),
            ('c1024','PD_G1',1024,4.),('c4096','PD_G1',4096,4.)]:
            c=copy.deepcopy(source);c.update(name=f'ext_qwen_bi_eager_qualification32_{label}_v1',arm=arm,chunk=chunk,
                chunk_label='full' if chunk==8000 else str(chunk),phase='final_correctness',gpus=[0,1] if arm=='PD_G1' else [4,5],
                seed=2026110507,arrival_seed_base=20261121,timeout=1200)
            c=finish(c,32,rate=rate,start=0)
            c.update(dataset=dataset,prompt_ids=[r['prompt_id'] for r in pool],data_scope=dict(original_pool_records=32,offered_count=32,explicit_cyclic_reuse=False))
            new.append(c)
        for start,rate in enumerate((1.1432986051,2.2865972102)):
            c=copy.deepcopy(source);c.update(name=f'ext_qwen_bi_compiled_no_graph_qualification8_s{start}_v1',
                ar_enforce_eager=False,ar_cudagraph_mode='NONE',ar_execution_family='BI_COMPILED_NO_GRAPH',phase='long_correctness',gpus=[2,3],timeout=900)
            c=finish(c,8,rate=rate);new.append(c)
        enqueue(new);state.update(stage='QUALIFICATION32',gate24=gate,configs=[c['name'] for c in new],source=source);write(PATH,state)
    if state['stage']=='QUALIFICATION32' and terminal(state['configs']):
        reference='ext_qwen_bi_eager_qualification32_reference_v1';gates={}
        for label in ('repeat','dp2','c1024','c4096'):
            name=f'ext_qwen_bi_eager_qualification32_{label}_v1'
            gates[label]=compare(reference,name) if status(reference)==status(name)=='COMPLETE' else dict(passed=False,status=status(name))
        if not gates['repeat']['passed']:
            state.update(stage='BLOCKED_QUALIFICATION32',gates=gates);write(PATH,state);return state
        source=state['source'];new=[];names=[]
        from .search import configured_base
        for chunk in (8000,1024,4096):
            if chunk!=8000 and not gates['c'+str(chunk)]['passed']:continue
            c=copy.deepcopy(source);c.update(name=f'capacity_qwen8_ext_bi_eager_c{chunk}_p_v1',worker='ar_capacity',capacity_mode='P_ONLY',
                phase='independent_capacity',P_slots=8,gpus=[0],chunk=chunk,chunk_label='full' if chunk==8000 else str(chunk))
            c=finish(c,8);c['P_slots']=8;c['jobs']=[dict(batch=b,cap=1,repeats=3) for b in (1,2,4,8)]
            new.append(c);names.append(c['name'])
        c=copy.deepcopy(source);c.update(name='capacity_qwen8_ext_bi_eager_prefix_D_v1',worker='ar_prefix_capacity',phase='independent_capacity',
            capacity_mode='PREPARED_D',gpus=[0],jobs=[dict(batch=b,cap=200,repeats=3) for b in (1,4,8,16,32)])
        c=finish(c,32);new.append(c);names.append(c['name'])
        c=copy.deepcopy(source);c.update(name='ext_calibration_qwen8_bi_eager_l8000_v1',phase='calibration',gpus=[0,1],
            calibration_serial=True,ar_execution_family='BI_EAGER',timeout=1800)
        c=finish(c,16,split='calibration');new.append(c);names.append(c['name'])
        enqueue(new);state.update(stage='CAPACITY_AND_CALIBRATION',gates32=gates,costs=names);write(PATH,state)
    return state


if __name__=='__main__':advance()
