"""Read recorded CUDA intervals. Never substitute NVML for kernel busy."""
import sqlite3
import subprocess
import collections
from .common import *
from .evidence import status
from .analyze import save_csv


def union(intervals):
    total=0;end=None
    for lo,hi in sorted(intervals):
        if end is None or lo>end:total+=hi-lo;end=hi
        elif hi>end:total+=hi-end;end=hi
    return total


def pid_roles(folder,cfg):
    result={}
    for p in folder.glob('atomic_spans_*.json'):
        role=json.loads(p.read_text())['role'];pid=int(p.stem.rsplit('_',1)[1])
        if role in ('prefill','decode'):result[pid]=(role,cfg['gpus'][0 if role=='prefill' else 1])
    for role,gpu in zip(('prefill','decode'),cfg['gpus']):
        p=folder/(role+'_ready.json')
        if p.exists():result[json.loads(p.read_text())['pid']]=(role,gpu)
    return result


def parse(folder,cfg):
    report=folder/'nsys_report.nsys-rep';database=folder/'nsys_report.sqlite'
    if not report.exists():return dict(name=cfg['name'],status='NOT_AVAILABLE',reason='No completed Nsight report')
    if not database.exists():
        result=subprocess.run(['nsys','export','--type=sqlite','--force-overwrite=false','--output='+str(database),str(report)],text=True,capture_output=True)
        write(folder/'nsys_export_result.json',dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
        if result.returncode:return dict(name=cfg['name'],status='BLOCKED_PROFILE_EXPORT',reason=result.stderr[-1000:])
    conn=sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True);conn.row_factory=sqlite3.Row
    tables={r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    schema={name:[r[1] for r in conn.execute('PRAGMA table_info("'+name+'")')] for name in tables}
    write(folder/'nsys_schema.json',schema)
    if not {'NVTX_EVENTS','CUPTI_ACTIVITY_KIND_KERNEL'}<=tables:
        return dict(name=cfg['name'],status='BLOCKED_PROFILE_ACTIVITY',reason='No NVTX or CUDA kernel activity table')
    strings={r['id']:r['value'] for r in conn.execute('SELECT * FROM StringIds')} if 'StringIds' in tables else {}
    def label(r):return r['text'] if 'text' in r.keys() and r['text'] else strings.get(r['textId'],'') if 'textId' in r.keys() else ''
    windows=[r for r in conn.execute('SELECT * FROM NVTX_EVENTS') if label(r)=='APD_MEASURED_WINDOW' and r['end'] is not None]
    if len(windows)!=1:return dict(name=cfg['name'],status='BLOCKED_PROFILE_WINDOW',windows=len(windows))
    marker=windows[0];window=json.loads((folder/'window.json').read_text())
    duration=window['last_arrival']-window['start'];left=marker['start']+int(.2*duration*1e9);right=marker['start']+int(.9*duration*1e9)
    roles=pid_roles(folder,cfg);kernels=collections.defaultdict(list);names=collections.Counter();events=[];unmapped=0
    for r in conn.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE end>? AND start<?',(left,right)):
        raw=r['globalPid'] if 'globalPid' in r.keys() else None
        pid=raw if raw in roles else raw>>24 if raw is not None else None
        if pid not in roles:unmapped+=1;continue
        role,gpu=roles[pid];a=max(left,r['start']);b=min(right,r['end']);kernels[role].append((a,b))
        sid=r['demangledName'] if 'demangledName' in r.keys() else r['shortName'] if 'shortName' in r.keys() else None
        name=strings.get(sid,'UNKNOWN_KERNEL');names[(role,gpu,name)]+=1
        events.append(dict(role=role,physical_GPU=gpu,start_s=(a-marker['start'])/1e9,end_s=(b-marker['start'])/1e9,kernel=name))
    summary=[]
    for role,index in [('prefill',0),('decode',1)]:
        intervals=kernels[role];busy=union(intervals)
        summary.append(dict(role=role,physical_GPU=cfg['gpus'][index],kernel_busy_fraction=busy/(right-left) if right>left else None,
            kernel_busy_union_ms=busy/1e6,window_ms=(right-left)/1e6,kernel_count=len(intervals),
            idle_or_unrecorded_fraction=1-busy/(right-left) if right>left else None,
            scope='Union of recorded CUDA kernels in the central 20-90% arrival window. Not SM occupancy. Unrecorded DMA is not GPU idleness.'))
    save_csv('profiles/'+cfg['name']+'_kernel_names.csv',[dict(role=k[0],physical_GPU=k[1],kernel=k[2],invocations=v) for k,v in names.items()])
    save_csv('profiles/'+cfg['name']+'_kernel_intervals.csv',events)
    output=dict(name=cfg['name'],status='MEASURED_PROFILED_CUDA_ACTIVITY',central_arrival_window_s=.7*duration,
        phase_marker_ns=[marker['start'],marker['end']],devices=summary,unmapped_kernel_events=unmapped,
        source='Actual Nsight/CUPTI kernel intervals, never inferred from host duration.')
    clean_name=cfg.get('profile_clean_reference')
    if clean_name and status(clean_name)=='COMPLETE':
        clean=json.loads((ROOT/'raw'/clean_name/'window.json').read_text())
        a=window['end']-window['start'];b=clean['end']-clean['start']
        output.update(clean_reference=clean_name,profile_wall_overhead_fraction=a/b-1,
            overhead_scope='Single matched arrival-to-drain comparison. It is not an independent-start confidence interval.',
            eligible_profile_transfer_to_clean=abs(a/b-1)<=.05 and unmapped==0 and all(r['kernel_count'] for r in summary))
    else:output['eligible_profile_transfer_to_clean']=False
    write(folder/'profile_activity_analysis.json',output);return output


def main():
    output=[]
    for p in (ROOT/'configs').glob('*.json'):
        cfg=json.loads(p.read_text())
        if not isinstance(cfg,dict) or not cfg.get('nsys') or status(cfg['name'])!='COMPLETE':continue
        try:output.append(parse(ROOT/'raw'/cfg['name'],cfg))
        except Exception as error:output.append(dict(name=cfg['name'],status='BLOCKED_PROFILE_ANALYSIS',error=repr(error)))
    write(ROOT/'profile_activity.json',output);print('PROFILE_ANALYSES',len(output));return output


if __name__=='__main__':main()
