"""Diagnostic use of native recurrent graphs for P-side packed prefill.

The native implementation owns metadata copies, KV validity, and stream events.
This hook does not change D execution or the projection arithmetic.
"""
from dataclasses import replace
from types import MethodType
from .common import ROOT, append


def install(cfg):
    from vllm_rlt.engine.stage_engine import StageEngine
    from vllm_rlt.worker.cuda_graph import RecurrentGraphs
    initialize = StageEngine.__init__
    close = StageEngine.close

    def initialized(self, *args, **kwargs):
        result = initialize(self, *args, **kwargs)
        local_capacity = bool(cfg.get('capacity_mode') and cfg.get('P_graph_local_capacity'))
        if self.stage_config.role != 'prefill' and not local_capacity:
            return result
        runner = self.model_runner
        execution = replace(runner.execution_config,
                            cuda_graph_max_batch_size=cfg['P_prefill_graph_rows'],
                            cuda_graph_max_graphs=cfg.get('P_prefill_graph_shapes', 4))
        graphs = RecurrentGraphs(self.model, self.cache_manager, execution, False)
        self._autonomous_prefill_graphs = graphs
        original = self.model.recurrent_prepared
        cache_owner = self.cache_manager

        def recurrent(model, hidden, metadata, cache, *, compute_gate=True):
            # Capture uses a native device-cache proxy. It must not re-enter
            # graph selection. Decode and non-packed calls remain unchanged.
            eligible = (cache is cache_owner and not compute_gate
                        and metadata.cu_seqlens_q is not None
                        and metadata.max_seqlen_q > 1
                        and len(hidden) <= cfg['P_prefill_graph_rows'])
            if not eligible:
                return original(hidden, metadata, cache, compute_gate=compute_gate)
            call = graphs.select(hidden, metadata)
            if call.entry is None:
                return original(hidden, metadata, cache, compute_gate=compute_gate)
            graphs.prepare_inputs(call, hidden)
            return graphs.execute(call, hidden)

        self.model.recurrent_prepared = MethodType(recurrent, self.model)
        return result

    def closed(self):
        graphs = getattr(self, '_autonomous_prefill_graphs', None)
        if graphs is not None:
            append(ROOT/'raw'/cfg['name']/'native_prefill_graph_counts.jsonl',
                   dict(role=self.stage_config.role, captures=graphs.captures,
                        replays=graphs.replays, fallbacks=graphs.fallbacks,
                        row_limit=cfg['P_prefill_graph_rows']))
        return close(self)

    StageEngine.__init__ = initialized
    StageEngine.close = closed
