"""Minimal optional hooks. Qualified KV, arithmetic and native ACK stay intact."""
import os
from .common import *
INSTALLED=False


def install():
    global INSTALLED
    if INSTALLED:return
    INSTALLED=True
    cfg=json.loads(Path(os.environ['ARC_CONFIG']).read_text())
    if cfg.get('projection_graph_rows'):
        from .tile_graph import install_factory
        install_factory(cfg)
    if cfg.get('D_probe_tokens'):
        from .decode_probe import install as probe
        probe(cfg)
