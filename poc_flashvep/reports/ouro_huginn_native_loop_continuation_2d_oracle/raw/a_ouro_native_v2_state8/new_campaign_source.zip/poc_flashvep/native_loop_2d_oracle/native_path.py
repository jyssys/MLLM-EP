"""Keep atomic full requests. Materialize state only for an actual partial cut.

The candidate uses native non-wavefront progress, not the wavefront callback.
It keeps the original wavefront guard unchanged. It is not GPU-qualified yet.
"""
import os
import time
from dataclasses import replace


def install(cfg):
    if not cfg.get('native_path'):
        return
    import torch
    from vllm_rlt.worker import buffers, model_runner
    from vllm_rlt.core.scheduler import Scheduler
    from vllm_rlt.core.scheduling_policy import RefillPolicy
    from vllm_rlt.request import RequestPhase
    from vllm_rlt.worker.executor import Operation
    from vllm_rlt.pd.connector import PDStageConnector
    from vllm_rlt.pd.transport import NixlConnector
    from ..adaptive_recurrence_cut.connector import CutConnector
    from ..looped_pd_abc.boundary import BoundaryConnector
    from .common import ROOT, write
    assert not cfg['wavefront'] and cfg['scheduler_mode'] == 'refill'
    if getattr(Scheduler, '_native_continuation_candidate', False):
        return
    Scheduler._native_continuation_candidate = True

    # Keep zero-offload's full-Prompt submission path. Provision continuation
    # storage in both cases so the feature-enabled memory cost is visible.
    maximum = cfg['state_capacity_tokens']
    def state_rows(config, scheduler, *, staged_prefill=None):
        return maximum
    buffers.prefill_stage_rows = model_runner.prefill_stage_rows = state_rows

    # Imported partial requests use existing non-wavefront recurrent phases.
    # Full requests remain PREFILL and use the original native runner path.
    phases = (RequestPhase.PREFILL, RequestPhase.PREFILLING_PRELUDE,
              RequestPhase.PREFILLING_RECURRENT)
    RefillPolicy.PREFILL_PHASES = phases
    from vllm_rlt.core.scheduling_policy import PromptOnlyPolicy
    policy_init = PromptOnlyPolicy.__init__
    def prompt_policy(self, config, *, staged_prefill):
        policy_init(self, config, staged_prefill=staged_prefill)
        self.PREFILL_PHASES = phases
    PromptOnlyPolicy.__init__ = prompt_policy

    planned = Scheduler._planned_loop_count
    def grouped(self, items):
        selected = {item.phase for item in items}
        if selected == {RequestPhase.PREFILL}:
            return min(getattr(item.request, 'arc_export_cut', self.total_ut_steps) for item in items)
        if selected == {RequestPhase.PREFILLING_RECURRENT}:
            counts = []
            for item in items:
                r = item.request
                end = item.token_start + item.token_count
                target = getattr(r, 'arc_export_cut', self.total_ut_steps)
                if (item.token_start == 0 and end == len(r.prompt_token_ids)
                        and r.prefill_depth_ranges[item.depth][1] >= end
                        and all(left == 0 for left, right in r.prefill_depth_ranges[item.depth:target])):
                    counts.append(target - item.depth)
                else:
                    counts.append(self._max_contiguous_prefill_loops(item))
            return min(counts)
        return planned(self, items)
    Scheduler._planned_loop_count = grouped

    progress = Scheduler._apply_prefill_progress
    def advance(self, item, phase, *, loop_count=None, event=None):
        if phase == RequestPhase.PREFILL and loop_count < self.total_ut_steps:
            if item.token_start != 0 or item.token_count != len(item.request.prompt_token_ids):
                raise ValueError('Native partial loop continuation requires the full prompt span')
            return self._apply_split_prefill_progress(item.request, RequestPhase.PREFILLING_PRELUDE,
                item, loop_count=loop_count, event=event)
        return progress(self, item, phase, loop_count=loop_count, event=event)
    Scheduler._apply_prefill_progress = advance

    # The original fused Prelude path also appends Huginn Coda-KV work.
    # That work is valid only at full depth. D performs it after continuation.
    prepare = model_runner.ModelRunner._prepare_loop_inputs
    def inputs(self, batch, packed_metadata=None):
        result = prepare(self, batch, packed_metadata)
        partial = any(span.depth + batch.loop_count < cfg['depth'] for span in batch.spans)
        if partial:
            result = tuple(entry for entry in result if entry.forward.operation != Operation.CODA)
        return result
    model_runner.ModelRunner._prepare_loop_inputs = inputs

    execute = model_runner.ModelRunner._execute_batch
    def run_batch(self, batch, prepared):
        partial = (batch.operation == Operation.PRELUDE and batch.loop_count
            and any(span.depth + batch.loop_count < cfg['depth'] for span in batch.spans))
        if not partial:
            return execute(self, batch, prepared)
        original = self.runtime.forward
        def forward(entry):
            result = original(entry)
            if entry.operation == Operation.PRELUDE:
                offset = 0
                for span in batch.spans:
                    slot = self._ensure_request_slot(span.request)
                    self.prefill_states[slot, span.token_start:span.token_start + span.token_count].copy_(
                        result.hidden[offset:offset + span.token_count])
                    offset += span.token_count
            return result
        self.runtime.forward = forward
        try:
            return execute(self, batch, prepared)
        finally:
            self.runtime.forward = original
    model_runner.ModelRunner._execute_batch = run_batch

    class NativeCutConnector(CutConnector):
        @classmethod
        def create(cls, engine, *, config, notify):
            # Same validated partial-state format and native transport/ACK ABI.
            # No claim of an incremental native KV wire protocol is made here.
            parameter = next(engine.model.parameters())
            limit = engine.scheduler.config.max_num_seqs + (config.max_receiving_requests
                if engine.stage_config.produces_tokens else config.max_draining_requests)
            hidden = torch.zeros((limit, maximum * engine.model.config.hidden_size),
                                 device=parameter.device, dtype=parameter.dtype)
            self = cls(engine, hidden, NixlConnector(engine.stage_config.stage_id,
                engine.cache_manager, hidden, config), config, notify=notify)
            self.cfg = cfg
            self.original_accept = engine.accept_import
            engine.accept_import = self.accept_cut
            original_notify = self.notify
            def notification(kind, **fields):
                if kind == 'commit':
                    t = self.transfers[fields['tid']]
                    fields.update(rng_state=getattr(t, 'rng_state', None), arc_cut=t.cut)
                    if cfg.get('verify_transfer'):
                        fields['fingerprint'] = self.fingerprint(t)
                return original_notify(kind, **fields)
            self.notify = notification
            return self

    # Zero-offload uses the native transport, with the same continuation buffer
    # provision. Partial runs use the existing exact snapshot format once.
    import vllm_rlt.pd.engine as pd
    if cfg.get('native_partial_cut') is not None:
        cut = cfg['native_partial_cut']
        assert 0 < cut < cfg['depth']
        pd.PDStageConnector = NativeCutConnector
        from vllm_rlt.pd.engine import PDEngine
        initialize = PDEngine.__init__
        def init(engine, *args, **kwargs):
            result = initialize(engine, *args, **kwargs)
            send = engine._send
            def sending(destination, kind, **fields):
                if kind in ('reserve', 'prefill', 'commit'):
                    fields['arc_cut'] = cut
                return send(destination, kind, **fields)
            engine._send = sending
            return result
        PDEngine.__init__ = init
    else:
        pd.PDStageConnector = BoundaryConnector

    from vllm_rlt.engine.stage_engine import StageEngine
    initialize = StageEngine.__init__
    def stage(self, *args, **kwargs):
        result = initialize(self, *args, **kwargs)
        runner = self.model_runner
        write(ROOT / 'raw' / cfg['name'] / f'native_path_memory_{os.getpid()}.json', dict(
            role=self.stage_config.role, time=time.monotonic(),
            prefill_state_bytes=runner.prefill_states.numel() * runner.prefill_states.element_size(),
            allocated_bytes=torch.cuda.memory_allocated(), reserved_bytes=torch.cuda.memory_reserved(),
            partial_cut=cfg.get('native_partial_cut'), feature_enabled=True,
            scope='Feature-enabled initial allocator totals overlap component tensors. Not peak or exclusive graph-pool memory.'))
        return result
    StageEngine.__init__ = stage
