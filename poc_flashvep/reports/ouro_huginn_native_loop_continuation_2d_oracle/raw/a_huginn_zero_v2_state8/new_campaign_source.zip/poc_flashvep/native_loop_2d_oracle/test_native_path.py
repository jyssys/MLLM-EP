"""CPU regressions for orchestration seams. Not GPU numerical qualification."""
import ast
import unittest
from pathlib import Path


class ClosureTests(unittest.TestCase):
    def test_distinct_constructor_closures(self):
        source = Path(__file__).with_name('native_path.py').read_text()
        tree = ast.parse(source)
        functions = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
        for name, required in (('init', 'initialize_pd'), ('stage', 'initialize_stage')):
            calls = [node.func.id for node in ast.walk(functions[name])
                     if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)]
            self.assertIn(required, calls)
            self.assertNotIn('initialize', calls)


if __name__ == '__main__':
    unittest.main()
