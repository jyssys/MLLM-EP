"""CPU tests for legal token-prefix and loop-cut boundaries."""
import unittest
from .prepare import base
from .common import ROOT,MODEL_PINS

class Contracts(unittest.TestCase):
    def test_token_prefix_closes_prelude_window(self):
        from types import SimpleNamespace
        from ..adaptive_recurrence_cut.staged import install
        from .connector import install_token_barrier
        from vllm_rlt.core.scheduler import Scheduler
        install(dict(state_capacity_tokens=4096));install_token_barrier()
        request=SimpleNamespace(num_preluded_tokens=128,prompt_token_ids=[0]*256,ltp_prefix=128)
        self.assertFalse(Scheduler._prelude_window_open(None,request))
    def test_pins(self):
        self.assertEqual(MODEL_PINS['ouro'][2],4);self.assertEqual(MODEL_PINS['huginn'][2],32)
    def test_disjoint_prompts(self):
        import json
        for workload in ('W1','W2','W3','W4'):
            a=json.loads((ROOT/'data'/f'{workload}_calibration.json').read_text())
            b=json.loads((ROOT/'data'/f'{workload}_test.json').read_text())
            self.assertFalse({r['prompt_sha256'] for r in a}&{r['prompt_sha256'] for r in b})
            for row in a+b:
                self.assertTrue(all(len(v)+row['cap']<=4096 for v in row['input_ids'].values()))
    def test_prefix_candidates(self):
        for n in (128,512,1536,3584):
            for chunk in (128,256):
                candidates=[0,n]+[min(n,max(chunk,int(n*f)//chunk*chunk)) for f in (.25,.5,.75)]
                for k in candidates:
                    self.assertTrue(0<=k<=n)
                    self.assertTrue(k in (0,n) or k%chunk==0)

if __name__=='__main__':unittest.main()
