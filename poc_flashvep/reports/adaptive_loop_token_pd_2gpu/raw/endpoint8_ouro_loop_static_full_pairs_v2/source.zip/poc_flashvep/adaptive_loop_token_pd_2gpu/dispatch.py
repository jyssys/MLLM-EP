"""Resume-safe dispatcher with a hard wall-clock cutoff and owned-resource lease."""
import argparse
import json
import os
import signal
import subprocess
import time
import zipfile
from .common import *

def main():
    p=argparse.ArgumentParser();p.add_argument('configs',nargs='+');p.add_argument('--parallel',type=int,default=1)
    p.add_argument('--quiet',action='store_true');a=p.parse_args();setup()
    from .resources import base as resources
    pending=[]
    for name in a.configs:
        path=ROOT/'configs'/name;cfg=json.loads(path.read_text());dest=ROOT/'raw'/cfg['name']
        if dest.exists():
            status=dest/'status.json'
            if status.exists() and json.loads(status.read_text())['status']=='COMPLETE':continue
            raise FileExistsError('Preserved existing namespace: '+str(dest))
        pending.append((path,cfg))
    if not pending:return
    devices=list(range(8)) if a.quiet else sorted({g for _,c in pending for g in c['gpus']})
    resources.stop(devices);active=[];failed=[]
    try:
        while pending or active:
            occupied={g for _,c,_ in active for g in c['gpus']}
            for path,cfg in list(pending):
                if len(active)>=a.parallel:break
                if occupied.intersection(cfg['gpus']):continue
                if remaining()<max(3600,cfg.get('estimated_seconds',300)+3600):
                    append(ROOT/'state/skipped.jsonl',dict(name=cfg['name'],reason='NOT_RUN_TIME_BUDGET',time=time.time()))
                    pending.remove((path,cfg));continue
                dest=ROOT/'raw'/cfg['name'];dest.mkdir(exist_ok=False)
                with zipfile.ZipFile(dest/'source.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
                    for folder in ('adaptive_loop_token_pd_2gpu','adaptive_recurrence_cut','looped_pd_abc','looped_pd_b_numerical_diagnosis'):
                        for source in (REPO/'poc_flashvep'/folder).glob('*.py'):archive.write(source,str(source.relative_to(REPO)))
                    archive.writestr('rlt_dirty.patch',subprocess.check_output(['git','diff','--binary'],cwd=RLT))
                env=environment(cfg['gpus']);env.update(ARC_CONFIG=str(path),ARC_RUN=cfg['name'],LTP_WORKER='1',ABC_LANE='quiet_pair' if a.quiet else 'parallel_correctness')
                handle=(ROOT/'logs'/f'{cfg["name"]}.log').open('w')
                command=[str(PYTHON),'-m','poc_flashvep.adaptive_loop_token_pd_2gpu.worker',str(path)]
                child=subprocess.Popen(command,cwd=REPO,env=env,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
                append(ROOT/'commands.jsonl',dict(time=time.time(),name=cfg['name'],command=command,pid=child.pid,gpus=cfg['gpus'],quiet=a.quiet))
                active.append((child,cfg,handle));pending.remove((path,cfg));occupied.update(cfg['gpus'])
                print('START',cfg['name'],child.pid,flush=True)
            for child,cfg,handle in list(active):
                if remaining()<300 and child.poll() is None:
                    os.killpg(child.pid,signal.SIGTERM)
                if child.poll() is None:continue
                handle.close();active.remove((child,cfg,handle));status=ROOT/'raw'/cfg['name']/'status.json'
                if child.returncode or not status.exists() or json.loads(status.read_text())['status']!='COMPLETE':failed.append(cfg['name'])
                print('END',cfg['name'],child.returncode,flush=True)
            budget(status='GPU_RUNS' if active else 'BETWEEN_RUNS',active=[c['name'] for _,c,_ in active],pending=[c['name'] for _,c in pending],failed=failed)
            time.sleep(1.)
    finally:
        if not active:resources.restore(devices)
        else:append(ROOT/'state/dispatcher_interruption.jsonl',dict(time=time.time(),active=[dict(name=c['name'],pid=p.pid) for p,c,h in active]))
    if failed:raise RuntimeError('Failed runs: '+str(failed))

if __name__=='__main__':main()
