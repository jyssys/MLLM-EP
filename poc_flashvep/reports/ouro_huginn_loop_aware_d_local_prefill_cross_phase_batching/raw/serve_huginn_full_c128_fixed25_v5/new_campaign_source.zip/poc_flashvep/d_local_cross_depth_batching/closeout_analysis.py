"""Keep execution, state qualification, and expansion decisions separate."""
import csv
import time
from .common import *
from .analyze import table


def main():
    matrix=[];failures=[];decisions={}
    for path in sorted((ROOT/'configs').glob('*.json')):
        cfg=json.loads(path.read_text())
        if 'name' not in cfg:continue
        folder=ROOT/'raw'/cfg['name'];receipt=folder/'dispatcher_result.json'
        result=json.loads(receipt.read_text()) if receipt.exists() else {}
        status=result.get('status') or ('COMPLETE' if result.get('complete') else 'FAILED' if result else 'NOT_RUN_SUPERSEDED_OR_BUDGET_PRIORITY')
        matrix.append(dict(name=cfg['name'],model=cfg['model'],method=cfg.get('dlocal_method'),worker=cfg['worker'],
            count=cfg['count'],status=status,complete=result.get('complete',False),returncode=result.get('returncode'),
            timing_qualification=result.get('timing_qualification','NORMAL_GUARDED_EXECUTION' if result else 'NOT_RUN'),
            config=str(path.relative_to(ROOT)),log=f'logs/{cfg["name"]}.log'))
        if result and not result.get('complete'):
            failures.append(dict(name=cfg['name'],kind='EXECUTION_FAILURE',status=status,
                log=f'logs/{cfg["name"]}.log',receipt=str(receipt.relative_to(ROOT))))
        q=folder/'local_qualification.json'
        if q.exists() and not json.loads(q.read_text())['passed']:
            failures.append(dict(name=cfg['name'],kind='BLOCKED_CORRECTNESS',status='OUTPUT_OR_VALID_STATE_MISMATCH',
                log=f'logs/{cfg["name"]}.log',receipt=str(q.relative_to(ROOT))))
    opportunities=list(csv.DictReader((ROOT/'readiness_opportunity.csv').open())) if (ROOT/'readiness_opportunity.csv').exists() else []
    slos=json.loads((ROOT/'configs/frozen_SLO.json').read_text())
    for model in ('ouro','huginn'):
        states={}
        for method in ('full','chunked','paced'):
            name=f'qual32_{model}_full_scoped_v3' if method=='full' else f'qual32_{model}_{method}_c128_v4'
            p=ROOT/'raw'/name/'local_qualification.json'
            states[method]=json.loads(p.read_text())['passed'] if p.exists() else None
        controls=[]
        for name in (f'opportunity_{model}_c128_alignment_v1',f'opportunity_{model}_c248_alignment_v1',f'opportunity_{model}_c248_d_device_v1'):
            rows={v['method']:v for v in opportunities if v.get('name')==name}
            if not all(m in rows for m in ('same_align','cross')):continue
            same,cross=rows['same_align'],rows['cross']
            limit=slos[f'{model}_L{4096 if model=="ouro" else 2048}']
            safe=all(v['output_exact']=='True' and float(v['TPOT_p95_ms'])<=.9*limit['TPOT_ms'] and float(v['ITL_p99_ms'])<=limit['ITL_ms'] for v in (same,cross))
            controls.append(dict(name=name,physical_GPU=cross.get('physical_GPU'),micro_decode_screen=safe,
                cross_over_aligned_same_local=float(cross['local_first_ms'])/float(same['local_first_ms']),
                cross_over_aligned_same_cohort=float(cross['cohort_host_ms'])/float(same['cohort_host_ms']),
                independent_starts=1,warm_repetitions=int(cross['warm_repetitions'])))
        grid=ROOT/'raw'/f'micro_{model}_strict_grid_v5/micro_summary.json'
        grid_exact=json.loads(grid.read_text())['all_micro_states_exact'] if grid.exists() else None
        qualified=all(v is True for v in states.values()) and grid_exact is True
        meaningful=any(v['micro_decode_screen'] and (v['cross_over_aligned_same_local']<.95 or v['cross_over_aligned_same_cohort']<.95) for v in controls)
        verdict='INCONCLUSIVE'
        if qualified and controls:
            verdict='MICRO_ONLY' if meaningful else 'NO_GO_LOOP_BATCHING'
        decisions[model]=dict(N32_generic_state_qualification=states,corrected_core_grid_exact=grid_exact,
            aligned_same_depth_controls=controls,verdict=verdict,
            online_cross_depth_benefit='NOT_RUN_PHASE_C_GATE' if not meaningful else 'NOT_MEASURED',
            contiguous_clean_kernel_slack='NOT_MEASURED_QUALIFIED_TRACE_UNAVAILABLE',
            novelty='NOT_ESTABLISHED_BEYOND_NATIVE_MIXED_CDB_AND_GENERIC_ALIGNMENT',
            scope='Bounded PoC expansion decision. It does not prove that all deflection or depth-mixed workloads lack headroom.')
        for method in ('generic_same_depth_online','cross_depth_online'):
            matrix.append(dict(name=f'conditional_{model}_{method}_3x128',model=model,method=method,
                worker='NOT_IMPLEMENTED_CONDITIONAL',count=384,status=decisions[model]['online_cross_depth_benefit'],complete=False))
        matrix.append(dict(name=f'conditional_{model}_persistence512',model=model,method='persistence',count=512,
            worker='CONDITIONAL',status='NOT_RUN_PHASE_C_GATE',complete=False))
    table(ROOT/'configuration_matrix.csv',matrix);table(ROOT/'failure_inventory.csv',failures)
    write(ROOT/'final_model_decisions.json',decisions)
    write(ROOT/'closeout_counts.json',dict(time=time.time(),executed_jobs=sum('config' in v and v['status']!='NOT_RUN_SUPERSEDED_OR_BUDGET_PRIORITY' for v in matrix),
        complete_jobs=sum(v['complete'] for v in matrix if 'config' in v),failed_or_blocked_records=len(failures),
        configured_not_run=sum(v['status']=='NOT_RUN_SUPERSEDED_OR_BUDGET_PRIORITY' for v in matrix),
        scope='A micro grid is one GPU job with multiple legal-state cells. Conditional online plans are not executed jobs.'))
    print(json.dumps(decisions))


if __name__=='__main__':main()
