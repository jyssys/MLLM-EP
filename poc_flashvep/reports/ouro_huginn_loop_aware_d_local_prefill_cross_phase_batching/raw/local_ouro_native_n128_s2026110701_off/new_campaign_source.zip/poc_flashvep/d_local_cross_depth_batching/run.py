"""Use the inherited exclusive GPU lease and bounded cleanup."""
import argparse
from .common import *


def execute(name):
    initialize()
    from ..native_split_deep_validation import run as inherited
    inherited.initialize = initialize
    return inherited.execute(name)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    args = parser.parse_args()
    raise SystemExit(0 if execute(args.name) else 1)
