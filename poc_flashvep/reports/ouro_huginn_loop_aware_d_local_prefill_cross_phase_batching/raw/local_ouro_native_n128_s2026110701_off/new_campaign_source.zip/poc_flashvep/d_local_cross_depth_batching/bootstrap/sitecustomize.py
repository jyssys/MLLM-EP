"""Load the qualified numerical path, then isolated campaign hooks."""
import os
if os.environ.get('FLUIDTOKEN_LOOP_WORKER') == '1':
    try:
        import runpy
        from poc_flashvep.d_local_cross_depth_batching.common import configure, REPO
        configure()
        runpy.run_path(str(REPO / 'poc_flashvep/native_split_deep_validation/bootstrap/sitecustomize.py'))
        from poc_flashvep.looped_pd_atomic_prefill.common import config
        if config().get('dlocal_campaign'):
            from poc_flashvep.d_local_cross_depth_batching.hooks import install
            install(config())
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(70)
