"""Campaign hooks. Native behavior stays unchanged unless explicitly selected."""


def install(cfg):
    if cfg.get('dlocal_method') != 'native':
        raise NotImplementedError('D-local methods require explicit qualification')
