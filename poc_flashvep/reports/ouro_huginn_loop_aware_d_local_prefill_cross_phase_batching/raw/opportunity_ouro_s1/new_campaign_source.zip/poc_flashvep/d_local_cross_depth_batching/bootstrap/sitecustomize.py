"""Load the qualified numerical path, then isolated campaign hooks."""
import os
if os.environ.get('FLUIDTOKEN_LOOP_WORKER') == '1':
    try:
        import runpy
        from poc_flashvep.d_local_cross_depth_batching.common import configure, REPO
        configure()
        import json
        from pathlib import Path
        contract = json.loads(Path(os.environ['ARC_CONFIG']).read_text())
        if contract.get('dlocal_method', 'native') != 'native':
            from poc_flashvep.native_split_deep_validation import graph_policy
            original_geometry = graph_policy.preferred_geometry
            def local_geometry(cfg, role):
                if role != 'decode':
                    return original_geometry(cfg, role)
                chunk = cfg['length'] if cfg['dlocal_method'] == 'full' else cfg.get('dlocal_chunk', 32)
                return {(chunk*b, chunk) for b in range(1, 9)
                        if chunk*b <= cfg['D_prefill_graph_rows']}
            graph_policy.preferred_geometry = local_geometry
        runpy.run_path(str(REPO / 'poc_flashvep/native_split_deep_validation/bootstrap/sitecustomize.py'))
        from poc_flashvep.looped_pd_atomic_prefill.common import config
        if config().get('dlocal_campaign'):
            from poc_flashvep.d_local_cross_depth_batching.hooks import install
            install(config())
            from poc_flashvep.d_local_cross_depth_batching.trace import install as trace
            trace(config())
            from poc_flashvep.d_local_cross_depth_batching.pacing import install as pacing
            pacing(config())
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(70)
