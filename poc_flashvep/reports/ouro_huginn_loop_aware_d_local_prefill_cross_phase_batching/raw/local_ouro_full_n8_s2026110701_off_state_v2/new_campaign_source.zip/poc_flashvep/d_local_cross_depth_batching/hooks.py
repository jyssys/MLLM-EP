"""Whole-request local ownership; native transfers remain unchanged."""
import os
import time
from dataclasses import replace
from .common import ROOT, write


def install(cfg):
    from vllm_rlt.pd.engine import PDEngine
    from vllm_rlt.engine.worker import StageWorker
    from vllm_rlt.engine.stage_engine import StageEngine
    from vllm_rlt.core.scheduler import Scheduler
    from vllm_rlt.core.scheduling_policy import SchedulingPolicy
    from vllm_rlt.request import RequestPhase as Phase
    folder = ROOT / 'raw' / cfg['name']
    method = cfg.get('dlocal_method', 'native')
    records = []
    init_pd, add, admit = PDEngine.__init__, PDEngine.add_request, PDEngine._admit
    command, output = StageWorker.command, StageWorker.output
    init_stage, close_stage = StageEngine.__init__, StageEngine.close
    planned = Scheduler._planned_loop_count

    def append(event, **fields):
        records.append(dict(time=time.monotonic(), event=event, **fields))
        if cfg.get('dlocal_debug'):
            with (folder / f'dlocal_live_{os.getpid()}.jsonl').open('a') as handle:
                handle.write(__import__('json').dumps(records[-1])+'\n')

    def initialized_pd(self, *args, **kwargs):
        if method not in ('native', 'full'):
            kwargs['decode_scheduler_config'] = replace(kwargs['decode_scheduler_config'],
                mode='mixed', wavefront_chunked_prefill=False,
                prefill_chunk_size=cfg.get('dlocal_chunk', 32),
                max_num_batched_tokens=cfg.get('dlocal_token_budget', 256))
        return init_pd(self, *args, **kwargs)

    def added(self, rid, tokens, params=None, **kwargs):
        result = add(self, rid, tokens, params, **kwargs)
        if method != 'native':
            w = next(w for w in self.transfers.values() if w.request.request_id == rid)
            measured = rid.startswith('r0_q')
            # Explicit all-local qualification also covers startup warm-up.
            selected = cfg.get('dlocal_all', False) or (measured and
                int(rid.rsplit('q', 1)[1]) % cfg.get('dlocal_every', 4) == 0)
            w.dlocal_selected = selected
            append('PLACEMENT', request_id=rid, local=selected, phase=w.phase,
                P_has_started=False)
        return result

    def admitted(self):
        local = [w for w in self.transfers.values() if getattr(w, 'dlocal_selected', False)
                 and not w.cancelled and w.phase == 'waiting']
        for w in local:
            length = len(w.request.prompt_token_ids) + w.request.sampling_params.max_tokens - 1
            eligible = [p for p in self.peers.values() if p.role == 'decode'
                and p.slots < min(cfg['D_slots'], p.client.info['transfer_slots'])
                and p.reserved_blocks + self._blocks(p, length) <=
                    p.client.info['num_blocks'] - (p.client.info['watermark_blocks'] if p.slots else 0)]
            if not eligible:
                continue
            d = min(eligible, key=lambda p: p.reserved_blocks)
            w.d, w.p, w.p_released = d.name, None, True
            w.d_reserved_blocks = self._blocks(d, length)
            d.reserved_blocks += w.d_reserved_blocks
            d.slots += 1
            w.phase = 'dlocal_prefill'
            w.timings['admitted'] = time.monotonic() - w.created
            self._send(d.name, 'dlocal_add', tid=w.tid,
                tokens=w.request.prompt_token_ids, params=w.request.sampling_params,
                trace_id=w.trace_id)
            append('LOCAL_CREDIT_RESERVED', request_id=w.request.request_id,
                tid=w.tid, blocks=w.d_reserved_blocks, D_reserved=d.reserved_blocks,
                D_total=d.client.info['num_blocks'], P_reserved=0)
        # Hide local waiters only from the native admission scan. Their original
        # ownership remains local, including temporary credit refusal.
        for w in local:
            if w.phase == 'waiting':
                w.phase = 'dlocal_waiting'
        try:
            return admit(self)
        finally:
            for w in local:
                if w.phase == 'dlocal_waiting':
                    w.phase = 'waiting'

    def commanded(self, record):
        if record['kind'] != 'dlocal_add':
            return command(self, record)
        assert self.engine.stage_config.role == 'decode'
        tid = record['tid']
        if not hasattr(self, '_dlocal_ids'):
            self._dlocal_ids = set()
        assert tid not in self._dlocal_ids and tid not in self.connector.transfers
        self.engine._add_request(tid, record['tokens'], record['params'],
            trace_id=record.get('trace_id'))
        self._dlocal_ids.add(tid)
        self.send('prefill_started', tid=tid)
        append('LOCAL_ENQUEUED', tid=tid, seed=record['params'].seed,
            prompt_tokens=len(record['tokens']), native_transfer=False)

    def produced(self, value):
        if value.request_id not in getattr(self, '_dlocal_ids', ()):
            return output(self, value)
        self.send('output', request_id=value.request_id, output=value)
        if value.finished:
            assert not self.engine.has_request(value.request_id), 'Local work must retire before credit release'
            self._dlocal_ids.remove(value.request_id)
            self.send('released', tid=value.request_id, role='decode')
            append('LOCAL_RETIRED', tid=value.request_id, tokens=len(value.token_ids),
                exit_depths=list(value.exit_depths), cache_allocated=self.engine.cache_manager.has_allocation(value.request_id))

    class PrioritySeparate(SchedulingPolicy):
        PREFILL_PHASES = (Phase.PREFILLING_PRELUDE, Phase.PREFILLING_RECURRENT)

        def schedule(self, scheduler, *, prefer_recurrent=False):
            # Ready decode work wins. Inflight work is not yet ready. A new
            # decode can become ready during a nonpreemptible prefill slice.
            for phase in (Phase.CODA, Phase.PRELUDE, Phase.RECURRENT):
                if scheduler.has_ready(phase):
                    return scheduler._take(phase)
            scheduler._admit()
            for phase in self.PREFILL_PHASES:
                if scheduler.has_ready(phase):
                    return scheduler._take(phase)
            return None

    def initialized_stage(self, *args, **kwargs):
        result = init_stage(self, *args, **kwargs)
        if self.stage_config.role == 'decode' and method not in ('native', 'full'):
            assert self.scheduler.staged_prefill and not self.scheduler.wavefront_chunked_prefill
            if method in ('chunked', 'paced'):
                self.scheduler.policy = PrioritySeparate(self.scheduler.config)
            self.scheduler._dlocal_quantum = cfg['depth'] if method == 'chunked' else cfg.get('dlocal_quantum', 1)
        append('STAGE_CONFIG', role=self.stage_config.role,
            staged=self.scheduler.staged_prefill, mode=self.scheduler.config.mode,
            chunk=self.scheduler.config.prefill_chunk_size)
        if cfg.get('dlocal_debug') and self.stage_config.role == 'decode':
            step = self.step
            snapshot_clock = [0.]
            def stepped():
                result = step()
                if time.monotonic() - snapshot_clock[0] > 1.:
                    snapshot_clock[0] = time.monotonic()
                    append('SCHEDULER_SNAPSHOT', queues={str(k):list(v) for k,v in self.scheduler.queues.items()},
                        policy=type(self.scheduler.policy).__name__,
                        requests={rid:str(r.phase) for rid,r in self.scheduler.requests.items()})
                return result
            self.step = stepped
        return result

    def loop_count(self, items):
        count = planned(self, items)
        if hasattr(self, '_dlocal_quantum') and any(i.phase in
                (Phase.PREFILLING_PRELUDE, Phase.PREFILLING_RECURRENT) for i in items):
            # Preserve the scheduler's causal bound. Only yield earlier.
            return min(count, self._dlocal_quantum)
        return count

    def closed(self):
        write(folder / f'dlocal_events_{os.getpid()}.json', dict(events=records,
            scope='Host enqueue/retirement and exact reservation accounting. Enqueue is not actual GPU execution start.'))
        return close_stage(self)

    # The coordinator owns its separate record list; flush at engine close too.
    close_pd = PDEngine.close
    def closed_pd(self):
        try:
            return close_pd(self)
        finally:
            write(folder / f'dlocal_events_{os.getpid()}.json', dict(events=records,
                scope='Whole-request placement before P execution. Native requests retain the original protocol.'))
    PDEngine.__init__, PDEngine.add_request, PDEngine._admit = initialized_pd, added, admitted
    PDEngine.close = closed_pd
    StageWorker.command, StageWorker.output = commanded, produced
    StageEngine.__init__, StageEngine.close = initialized_stage, closed
    Scheduler._planned_loop_count = loop_count
