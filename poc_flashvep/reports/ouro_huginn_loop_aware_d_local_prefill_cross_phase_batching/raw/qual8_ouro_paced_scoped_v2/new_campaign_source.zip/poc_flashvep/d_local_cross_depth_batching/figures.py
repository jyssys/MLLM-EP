"""Plot measured data and explicit missing-evidence panels."""
import csv
import json
import math
from .common import ROOT, write


def main():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
        'figure.dpi':150,'savefig.bbox':'tight'})
    manifest=[]
    def save(fig,name,scope,sources):
        fig.savefig(ROOT/'figures'/(name+'.png'));fig.savefig(ROOT/'figures'/(name+'.svg'))
        plt.close(fig);manifest.append(dict(name=name,PNG=f'figures/{name}.png',SVG=f'figures/{name}.svg',
            scope=scope,sources=sources))
    def missing(axis,text):
        axis.set_facecolor('#f3f3f3');axis.text(.5,.5,text,ha='center',va='center',transform=axis.transAxes,wrap=True)
        axis.set_xticks([]);axis.set_yticks([])
    models=('ouro','huginn')
    # Only qualified activity windows are eligible for the primary timeline.
    fig,axes=plt.subplots(2,2,figsize=(11,6.5))
    profiles=[]
    for index,model in enumerate(models):
        path=ROOT/'raw'/f'local_{model}_native_thin_trace128/dlocal_profile_qualification.json'
        if not path.exists() or not json.loads(path.read_text()).get('qualified'):
            missing(axes[index,0],f'{model.title()}: NOT_MEASURED\nNo qualified kernel timeline')
            missing(axes[index,1],'Safe insertion windows cannot be inferred\nfrom an invalid or missing activity trace.')
            continue
        q=json.loads(path.read_text());folder=path.parent
        gaps=json.loads((folder/'kernel_gap_samples.json').read_text())['gaps_ms']
        positive=sorted(g for g in gaps if g>0)
        axes[index,0].plot(positive,np.arange(1,len(positive)+1)/len(positive),color='#247ba0')
        axes[index,0].set_xscale('log');axes[index,0].set_xlabel('Measured kernel-free interval (ms)')
        axes[index,0].set_ylabel('Empirical CDF');axes[index,0].set_title(f'{model.title()}: kernel union {100*q["kernel_union_fraction"]:.1f}%')
        a=q['local_clean'];b=q['local_profile']
        labels=('ITL p99','Maximum ITL');x=np.arange(2)
        axes[index,1].bar(x-.17,[a['ITL_p99_ms'],a['max_ITL_ms']],.34,label='Marker-free control',color='#777')
        axes[index,1].bar(x+.17,[b['ITL_p99_ms'],b['max_ITL_ms']],.34,label='Qualified trace',color='#247ba0')
        axes[index,1].set_xticks(x,labels);axes[index,1].set_ylabel('Local decode interval (ms)');axes[index,1].legend(fontsize=8)
        profiles.append(str(path.relative_to(ROOT)))
    fig.suptitle('Figure 1. Kernel gaps are not guaranteed decode-safe slack')
    fig.text(.5,.01,'Kernel gaps can contain DMA. A valid gap distribution does not prove that a full prefill slice fits.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.05,1,.95))
    save(fig,'figure_1_decode_safe_windows','Qualified activity-only observations. No simulated idle intervals.',profiles)

    fig,axes=plt.subplots(1,2,figsize=(11,4.5));memory_sources=[]
    stacks=[];labels=[]
    for model in models:
        folder=ROOT/'raw'/f'local_{model}_native_n128_s2026110701_off'
        for role in ('prefill','decode'):
            matches=[p for p in folder.glob('memory_inventory_close_*.json') if json.loads(p.read_text())['role']==role]
            if not matches:continue
            p=matches[0];v=json.loads(p.read_text());memory_sources.append(str(p.relative_to(ROOT)))
            stacks.append([v['weight_and_model_buffer_storage_bytes']/2**30,v['KV_storage_bytes']/2**30,
                (v['exposed_runner_workspace_storage_bytes']+v['exposed_NIXL_hidden_staging_storage_bytes'])/2**30,
                (v['exposed_graph_tensor_storage_bytes']+v['opaque_or_unattributed_allocator_bytes'])/2**30])
            labels.append(model.title()+' '+('P' if role=='prefill' else 'D'))
    if stacks:
        bottom=np.zeros(len(stacks));colors=('#50514f','#247ba0','#70c1b3','#f3b61f')
        for j,label in enumerate(('Weights + model buffers','KV pool','Exposed workspace + staging','Graph / allocator residual')):
            values=np.array(stacks)[:,j];axes[0].bar(labels,values,bottom=bottom,label=label,color=colors[j]);bottom+=values
        axes[0].set_ylabel('Unique allocated storage (GiB)');axes[0].tick_params(axis='x',rotation=15);axes[0].legend(fontsize=8)
    else:missing(axes[0],'NOT_MEASURED: HBM inventory')
    counts=[]
    for model in models:
        paths=sorted((ROOT/'raw').glob(f'qual32_{model}_full*/local_qualification.json'))
        if not paths:
            counts.append(None)
        else:
            q=json.loads(paths[-1].read_text());counts.append(q['count'] if q['passed'] else None)
    for i,value in enumerate(counts):
        if value is None:axes[1].text(i,.5,'N32 not qualified',ha='center',rotation=90)
        else:axes[1].bar(i,value,color='#70c1b3')
    axes[1].set_xticks(range(2),('Ouro','Huginn'));axes[1].set_ylim(0,36)
    axes[1].set_ylabel('Exact D-local full-prompt requests');axes[1].set_title('Correctness, not clean throughput')
    fig.suptitle('Figure 2. Whole-request D ownership uses the existing KV pool')
    fig.text(.5,.01,'Allocator totals overlap these components. Opaque graph memory is not fully attributed.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.05,1,.94))
    save(fig,'figure_2_d_local_ownership_and_hbm','Measured storage inventory and N32 exactness. No added KV pool.',memory_sources)

    fig,axes=plt.subplots(1,2,figsize=(11,4.7));micro_sources=[]
    for index,model in enumerate(models):
        path=ROOT/'raw'/f'micro_{model}_fair_grid_s1/full_core_micro.json'
        if not path.exists():missing(axes[index],f'{model.title()}: NOT_MEASURED');continue
        items=[x for x in json.loads(path.read_text()) if x.get('control_version',0)>=3 and x['hidden_exact'] and x['KV_exact']]
        micro_sources.append(str(path.relative_to(ROOT)))
        series={}
        for item in items:
            if item['decode_batch']!=2:continue
            vals=[np.median(r['batched_ms']) for r in item.get('paired_repetitions',[])]
            if vals:series[item['chunk'],item['depth_class']]=vals
        for label,color,shift in (('same','#777',-.15),('cross','#247ba0',.15)):
            x=[];y=[];err=[]
            for j,chunk in enumerate((16,32,64,128)):
                v=series.get((chunk,label))
                if not v:continue
                x.append(j+shift);y.append(np.median(v));err.append([np.median(v)-min(v),max(v)-np.median(v)])
            if x:axes[index].bar(x,y,.29,color=color,label=label+' depth',yerr=np.array(err).T,capsize=3)
        axes[index].set_xticks(range(4),('16','32','64','128'));axes[index].set_xlabel('Prefill query tokens + 2 decode rows')
        axes[index].set_ylabel('Core + attention enclosure (ms)');axes[index].set_title(model.title());axes[index].legend(fontsize=8)
    fig.suptitle('Figure 3. Matched same-depth versus cross-depth batching')
    fig.text(.5,.01,'Three warm repetitions in one process. Whiskers show min–max, not an independent-start confidence interval.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.05,1,.94))
    save(fig,'figure_3_same_vs_cross_depth_micro','Measured legal ready-state operations; graph input staging is included. Not online serving.',micro_sources)

    runs=list(csv.DictReader((ROOT/'serving_runs.csv').open()))
    fig,axes=plt.subplots(2,4,figsize=(13,6));sources=[]
    methods=('native','chunked','paced')
    for i,model in enumerate(models):
        selected={}
        for method in methods:
            candidates=[r for r in runs if r['model']==model and r['method']==method and r['marker_on']=='False'
                and int(r['observed_requests'])==128]
            if candidates:selected[method]=candidates[-1]
        for j,(field,title) in enumerate((('TTFT_p95_ms','TTFT p95 (ms)'),('TPOT_p95_ms','TPOT p95 (ms)'),
                ('ITL_p99_ms','ITL p99 (ms)'),('joint_SLO_goodput','Joint SLO goodput (req/s)'))):
            ax=axes[i,j]
            for k,method in enumerate(methods):
                if method not in selected:
                    ax.text(k,.5,'NOT_MEASURED',ha='center',rotation=90,transform=ax.get_xaxis_transform(),fontsize=8);continue
                r=selected[method];sources.append(r['name'])
                ax.bar(k,float(r[field]),color='#247ba0' if r['decode_screen_pass']=='True' else '#ed553b')
            ax.set_xticks(range(3),('Native','Chunked','Loop-paced'),rotation=20);ax.set_title(model.title()+': '+title,fontsize=10)
    fig.suptitle('Figure 4. Marker-free serving; red bars fail the decode screen')
    fig.text(.5,.01,'Fixed D placement is a controlled baseline, not the official Kairos policy. Cross-depth online expansion remains gated.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.05,1,.94))
    save(fig,'figure_4_serving_latency_and_goodput','Finite-cohort measurements. Missing arms are not zero.',sorted(set(sources)))

    fig,axes=plt.subplots(1,2,figsize=(11,4.5));op_sources=[]
    for i,model in enumerate(models):
        name='opportunity_ouro_graph_control_v2' if model=='ouro' else 'opportunity_huginn_s1'
        path=ROOT/'raw'/name/'opportunity_micro.json'
        if not path.exists():missing(axes[i],model.title()+': NOT_MEASURED');continue
        data=[r for r in json.loads(path.read_text()) if not r['warmup'] and 'graph_after' in r]
        for j,method in enumerate(('separate','same','cross')):
            values=[r['cohort_host_ms'] for r in data if r['method']==method]
            if values:axes[i].bar(j,np.median(values),color=('#aaa','#777','#247ba0')[j])
        axes[i].set_xticks(range(3),('Separate','Same-depth','Cross-depth'),rotation=15)
        axes[i].set_ylabel('Closed-loop cohort time (ms)');axes[i].set_title(model.title())
        op_sources.append(str(path.relative_to(ROOT)))
    fig.suptitle('Figure 5. Ready-work opportunity control with common graph policy')
    fig.text(.5,.01,'Two decode streams + one whole local prompt. Three warm repetitions; not a PD online-goodput measurement.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.05,1,.94))
    save(fig,'figure_5_ready_work_opportunity_control','Native priorities are common. Only recurrent compatibility changes. No modeled speedup.',op_sources)
    write(ROOT/'figure_manifest.json',manifest)


if __name__=='__main__':main()
