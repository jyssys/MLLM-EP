"""CPU regression tests for placement and the native warm-up barrier."""
from .hooks import local_placement


def test_native_warmup_keeps_transfer_owned_readiness():
    for rid in ('deep_primary_serial_warmup', 'recovery_warm_full_P_batch_0',
                'recovery_warm_short_D_geometry_0', 'r-1_q0'):
        assert not local_placement(rid, all_local=True)


def test_fixed_placement_matches_across_local_arms():
    assert [i for i in range(128) if local_placement(f'r0_q{i}')] == list(range(0, 128, 4))


def test_local_qualification_does_not_change_native_warmup():
    assert all(local_placement(f'r0_q{i}', all_local=True) for i in range(32))
    assert local_placement('dlocal_warm_primary')
    assert not local_placement('r-1_q0', all_local=True)
