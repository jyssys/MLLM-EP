"""Exclude D-blocked admissions from the compute-ready backlog screen."""
import statistics
from .common import ROOT
from .analyze import records,table


def slope(points):
    if len(points)<2:return None
    mx=statistics.mean(t for t,v in points)
    my=statistics.mean(v for t,v in points)
    denominator=sum((t-mx)**2 for t,v in points)
    return sum((t-mx)*(v-my) for t,v in points)/denominator if denominator else None


def analyze(name,window):
    import json
    folder=ROOT/'raw'/name
    left=window['start']+.2*(window['last_arrival']-window['start'])
    right=window['start']+.9*(window['last_arrival']-window['start'])
    local=[]
    for path in folder.glob('memory_progress_*.jsonl'):
        local.extend(r for r in records(path) if r['role']=='prefill' and 'queued_not_inflight_not_connector_blocked_ids' in r)
    local.sort(key=lambda r:r['time'])
    timeline=[]
    for row in records(folder/'admission_reasons.jsonl'):
        Dblocked=sum(any(r.startswith('DECODE_') for r in q['reasons']) for q in row['waiting'])
        # No D KV/slot refusal and no P KV refusal. The remaining P slot
        # wait is reported separately from already admitted P-ready work.
        unadmitted=sum('PREFILL_NO_SLOT' in q['reasons'] and
            all(r=='PREFILL_NO_SLOT' for r in q['reasons']) for q in row['waiting'])
        earlier=[v for v in local if v['time']<=row['time'] and row['time']-v['time']<=1.]
        admitted=len(earlier[-1]['queued_not_inflight_not_connector_blocked_ids']) if earlier else None
        timeline.append(dict(name=name,time=row['time'],central_window=left<=row['time']<=right,
            coordinator_D_credit_blocked=Dblocked,
            unadmitted_P_slot_wait_D_credit_clear=unadmitted,
            admitted_owner_queue_not_inflight_or_connector_blocked=admitted,
            ready_backlog_lower_bound=unadmitted+(admitted or 0),owner_sample_available=admitted is not None,
            scope='Distinct admitted and unadmitted populations. D-blocked waiting is excluded. The owner field excludes observed inflight/connector-blocked rows.'))
    points=[(r['time'],r['ready_backlog_lower_bound']) for r in timeline if r['central_window']]
    mid=(left+right)/2
    a=[v for t,v in points if t<mid]
    b=[v for t,v in points if t>=mid]
    result=dict(P_ready_lower_bound_slope_per_s=slope(points),
        P_ready_lower_bound_half_growth=statistics.mean(b)-statistics.mean(a) if a and b else None,
        P_ready_lower_bound_max=max((v for t,v in points),default=None),
        P_owner_queue_available=bool(local),
        queue_scope='Conservative D-clear P-slot-wait plus available admitted owner queue. These populations remain separate in the timeline. This is not by itself proof of GPU saturation.')
    return result,timeline


def main():
    import json
    rows=[];timeline=[]
    for path in (ROOT/'raw').glob('*/window.json'):
        value,series=analyze(path.parent.name,json.loads(path.read_text()))
        rows.append(dict(name=path.parent.name,**value))
        timeline.extend(series)
    table('p_ready_queue_analysis.csv',rows)
    table('p_ready_queue_timeline.csv',timeline)
    return rows


if __name__=='__main__':main()
