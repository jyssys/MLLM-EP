"""Use the native supported CUDA-only profiler without replacing execution."""
import json
import os
import time
from .common import ROOT,write,append


def clock():
    lo=time.monotonic()
    epoch=time.time_ns()
    hi=time.monotonic()
    return dict(monotonic=(lo+hi)/2,epoch_ns=epoch,uncertainty_s=hi-lo)


def install(cfg):
    from vllm_rlt.engine.stage_engine import StageEngine
    from vllm_rlt.profiling import ProfileConfig
    initialize=StageEngine.__init__
    close=StageEngine.close
    folder=ROOT/'raw'/cfg['name']
    roles=cfg.get('capture_roles',[cfg.get('capture_role','prefill')])
    def initialized(self,*args,**kwargs):
        result=initialize(self,*args,**kwargs)
        role=self.stage_config.role
        if role in roles:
            self.start_profile(ProfileConfig(output_dir=str(folder/'cuda_only_profile'/role),activities=('cuda',),
                record_shapes=False,with_stack=False,profile_memory=False,with_flops=False),role=self.stage_config.role)
            anchor=clock()
            self.profiling.current.profiler.add_metadata_json('recovery_clock',json.dumps(anchor))
            write(folder/f'cuda_only_clock_{role}.json',dict(**anchor,pid=os.getpid(),role=role,
                logical_device=self.model_runner.device.index,
                evidence='MEASURED_HOST_CLOCK_PAIR_FOR_NATIVE_KINETO',
                scope='Start before worker-ready and request warm-up. Retain baseTimeNanoseconds when converting exported device timestamps.'))
        return result
    def closed(self):
        role=self.stage_config.role
        if role in roles and self.profiling.recording:
            append(folder/f'cuda_only_events_{role}.jsonl',dict(event='METRIC_WINDOW_END',**clock()))
            self.stop_profile()
            status=self.wait_for_profile_artifacts(300)
            write(folder/f'cuda_only_status_{role}.json',status)
        return close(self)
    StageEngine.__init__=initialized
    StageEngine.close=closed


def analyze(name,clean,role='prefill'):
    import tarfile
    from .common import configure
    from .profile_analysis import union
    from ..looped_pd_atomic_prefill import evidence
    folder=ROOT/'raw'/name
    archives=list((folder/'cuda_only_profile'/role).glob('rank-*/cycle-*.tar.gz'))
    if len(archives)!=1:return dict(name=name,status='NATIVE_CUDA_TRACE_NOT_AVAILABLE')
    with tarfile.open(archives[0]) as archive:
        member=next(m for m in archive.getmembers() if m.name.endswith('/trace.json') or m.name=='trace.json')
        raw=json.load(archive.extractfile(member))
    anchor=json.loads((folder/f'cuda_only_clock_{role}.json').read_text())
    base=raw.get('baseTimeNanoseconds')
    assert isinstance(base,int),'Native Chrome trace must retain its absolute timestamp base'
    assert raw['recovery_clock']=={k:anchor[k] for k in ('monotonic','epoch_ns','uncertainty_s')}
    window=json.loads((folder/'window.json').read_text())
    kernels=[]
    for event in raw['traceEvents']:
        if event.get('ph')!='X' or event.get('cat')!='kernel':continue
        if 'device' in event.get('args',{}) and event['args']['device']!=anchor['logical_device']:continue
        start=anchor['monotonic']+(base+1000*event['ts']-anchor['epoch_ns'])/1e9
        end=start+event['dur']/1e6
        if end<window['start'] or start>window['end']:continue
        kernels.append(dict(start_monotonic=start,end_monotonic=end,name=event['name'],pid=anchor['pid']))
    assert kernels,'No kernels overlap the actual measured window. Do not invent a clock offset.'
    duration=window['end']-window['start']
    intervals=[(max(window['start'],r['start_monotonic']),min(window['end'],r['end_monotonic'])) for r in kernels]
    reference=json.loads((ROOT/'raw'/clean/'window.json').read_text())
    difference=duration/(reference['end']-reference['start'])-1
    configure();evidence.ROOT=ROOT
    parity=evidence.compare(clean,name)['passed']
    alignment=dict(anchor=anchor,window_start=window['start'],window_end=window['end'],
        kernels=kernels,evidence='MEASURED_NATIVE_CUDA_ONLY_KINETO_KERNEL_INTERVALS')
    write(folder/f'aligned_kernels_{role}.json',alignment)
    result=dict(name=name,clean=clean,role=role,status='PARSED',recorded_kernel_invocations=len(kernels),
        window_start_monotonic=window['start'],window_end_monotonic=window['end'],window_seconds=duration,
        kernel_busy_fraction=union(intervals)/duration,anchor_uncertainty_s=anchor['uncertainty_s'],
        matched_wall_difference_fraction=difference,exact_output_parity=parity,
        eligible_for_matched_clean=abs(difference)<=.05 and parity,
        evidence='MEASURED_NATIVE_CUDA_ONLY_KINETO',scope='Native supported profiler with CUDA activities only. No CPU operator recording. Kernel union is not SM occupancy. Reject material perturbation.')
    write(folder/f'profile_analysis_{role}.json',result)
    if role=='prefill':
        write(folder/'aligned_kernels.json',alignment)
        write(folder/'profile_analysis.json',result)
    return result
