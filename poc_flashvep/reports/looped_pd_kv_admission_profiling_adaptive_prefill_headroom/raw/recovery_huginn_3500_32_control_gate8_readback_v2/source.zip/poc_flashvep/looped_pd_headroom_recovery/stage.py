"""Run the unchanged native StageWorker with one inherited IPC descriptor."""
import pickle
import sys
from pathlib import Path
from multiprocessing.connection import Connection


def main():
    from .runtime import install
    install()
    from vllm_rlt.engine.worker import worker_main
    stage_config, device, model_source, options, kwargs = pickle.loads(Path(sys.argv[1]).read_bytes())
    worker_main(stage_config, device, Connection(int(sys.argv[2])), model_source, options, **kwargs)


if __name__ == '__main__':
    main()
