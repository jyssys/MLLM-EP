"""CPU regressions for new isolation and profiling helpers."""
import subprocess
import sys
import unittest
from .runtime import ProcessAdapter


class RuntimeTests(unittest.TestCase):
    def test_plane_selection_preserves_all_operand_bytes(self):
        import torch
        from .state_probe import plane
        tensor=torch.arange(11*4*3*5).reshape(11,4,3,5)
        blocks=torch.tensor([9,1,6,3])
        for layer in range(4):
            old=tensor.index_select(0,blocks)[:,layer]
            actual=plane(tensor,blocks,layer)
            self.assertTrue(torch.equal(old,actual))
            self.assertEqual(old.contiguous().numpy().tobytes(),actual.contiguous().numpy().tobytes())

    def test_process_adapter_matches_native_client(self):
        child=subprocess.Popen([sys.executable,'-c','pass'])
        adapted=ProcessAdapter(child)
        self.assertEqual(adapted.pid,child.pid)
        adapted.join(10)
        self.assertFalse(adapted.is_alive())
        self.assertEqual(adapted.exitcode,0)

    def test_actual_request_uses_generated_token_ids(self):
        from pathlib import Path
        source=Path('/home/esjung/external/looped-pd-abc-rlt/vllm_rlt/request.py').read_text()
        self.assertIn('generated_token_ids: list[int]',source)
        self.assertNotIn('num_output_tokens:',source)
        hook=Path(__file__).with_name('runtime.py').read_text()
        self.assertIn('len(r.generated_token_ids)',hook)
        self.assertNotIn('r.num_output_tokens',hook)

    def test_capture_is_selected_stage_only(self):
        from pathlib import Path
        source=Path(__file__).with_name('runtime.py').read_text()
        self.assertIn("stage_config.role != cfg.get('capture_role', 'prefill')",source)
        self.assertIn("'--capture-range=cudaProfilerApi'",source)


if __name__=='__main__':
    unittest.main()
