"""Observe native owners. Keep reservation, ACK and numerical rules unchanged."""
import faulthandler
import functools
import json
import os
import pickle
import signal
import subprocess
import time
from pathlib import Path
from .common import ROOT, PYTHON, REPO, configure, write, append

INSTALLED = False


class ProcessAdapter:
    """Expose the Process methods used by the unchanged native StageClient."""
    def __init__(self, process):
        self.process = process
        self.pid = process.pid

    @property
    def exitcode(self):
        return self.process.poll()

    def is_alive(self):
        return self.process.poll() is None

    def join(self, timeout=None):
        try:
            self.process.wait(timeout)
        except subprocess.TimeoutExpired:
            pass

    def terminate(self):
        self.process.terminate()

    def kill(self):
        self.process.kill()


def install():
    global INSTALLED
    if INSTALLED:
        return
    INSTALLED = True
    old = configure()
    cfg = old.config()
    folder = ROOT / 'raw' / cfg['name']
    if cfg.get('worker') == 'native_mixed_worker':
        return  # Its existing installer applies the same numerical patch.
    from ..looped_pd_atomic_prefill.runtime import install as qualified
    qualified()
    import torch
    from vllm_rlt.engine.stage_engine import StageEngine
    from vllm_rlt.worker.model_runner import ModelRunner
    stack = (folder / f'worker_stacks_{os.getpid()}.log').open('a')
    faulthandler.register(signal.SIGUSR1, file=stack, all_threads=True)
    # Keep the handle alive for asynchronous stack requests from the watchdog.
    StageEngine._recovery_stack_handle = stack
    initialize = StageEngine.__init__
    step = StageEngine._step
    close = StageEngine.close
    clocks = {}
    capture = {'started': False, 'stopped': False, 'until': None, 'submissions': 0}

    def snapshot(engine, event):
        now = time.monotonic()
        cache = engine.cache_manager
        free, total = torch.cuda.mem_get_info(engine.model_runner.device)
        weights = sum(p.numel() * p.element_size() for p in engine.model_runner.model.parameters()) if hasattr(engine.model_runner, 'model') else None
        active = [dict(request_id=r.request_id, phase=str(r.phase), prompt_tokens=len(r.prompt_token_ids),
                       prefilled=r.num_prefilled_tokens, output_tokens=len(r.generated_token_ids))
                  for r in engine.scheduler.requests.values()]
        append(folder / f'memory_progress_{os.getpid()}.jsonl', dict(time=now, pid=os.getpid(), role=engine.stage_config.role,
            event=event, device_total_bytes=total, device_free_bytes=free,
            allocator_allocated_bytes=torch.cuda.memory_allocated(engine.model_runner.device),
            allocator_reserved_bytes=torch.cuda.memory_reserved(engine.model_runner.device),
            allocator_peak_bytes=torch.cuda.max_memory_allocated(engine.model_runner.device),
            weight_bytes=weights, KV_pool_bytes=cache.key_cache.numel()*cache.key_cache.element_size()*2,
            KV_total_blocks=cache.num_blocks, KV_used_blocks=cache.num_used_blocks,
            KV_free_blocks=cache.num_blocks-cache.num_used_blocks, KV_block_bytes=cache.bytes_per_block,
            requests=active, connector_blocked=list(getattr(engine, '_connector_blocked', ())),
            evidence='MEASURED_OWNER_SNAPSHOT', scope='Allocator totals overlap the KV pool and weights. Do not stack them. Unexposed graph/workspace/staging attribution is NOT_MEASURED.'))

    def initialized(self, *args, **kwargs):
        result = initialize(self, *args, **kwargs)
        clocks[id(self)] = 0.
        snapshot(self, 'INITIALIZED')
        return result

    def stepped(self, *args, **kwargs):
        now = time.monotonic()
        if now-clocks.get(id(self), 0.) >= cfg.get('memory_sample_seconds', .5):
            clocks[id(self)] = now
            snapshot(self, 'PROGRESS')
        if capture['started'] and not capture['stopped'] and now >= capture['until']:
            torch.cuda.cudart().cudaProfilerStop()
            capture['stopped'] = True
            append(folder / 'capture_events.jsonl', dict(time=time.monotonic(), pid=os.getpid(), event='STOP', role=self.stage_config.role))
        return step(self, *args, **kwargs)

    def closed(self):
        if capture['started'] and not capture['stopped']:
            torch.cuda.cudart().cudaProfilerStop()
            capture['stopped'] = True
            append(folder / 'capture_events.jsonl', dict(time=time.monotonic(), pid=os.getpid(), event='STOP_CLOSE', role=self.stage_config.role))
        snapshot(self, 'CLOSE')
        return close(self)

    StageEngine.__init__ = initialized
    StageEngine._step = stepped
    StageEngine.close = closed
    if cfg.get('capture_seconds'):
        submit = ModelRunner.submit
        def captured_submit(self, scheduled_batch=None, *, batch):
            role = getattr(self, '_recovery_role', None)
            # Device index follows the native pair mapping. Only the selected
            # process is launched under Nsight, so D remains uninstrumented.
            selected = str(self.device) == ('cuda:0' if cfg.get('capture_role', 'prefill') == 'prefill' else 'cuda:1')
            capture['submissions'] += 1
            if selected and not capture['started'] and capture['submissions'] > cfg.get('capture_after_submissions', 2):
                torch.cuda.cudart().cudaProfilerStart()
                capture.update(started=True, until=time.monotonic()+cfg['capture_seconds'])
                append(folder / 'capture_events.jsonl', dict(time=time.monotonic(), pid=os.getpid(), event='START', device=str(self.device),
                    marker='RECOVERY_CAPTURE', wall_ns=time.time_ns()))
                torch.cuda.nvtx.mark('RECOVERY_CAPTURE_CLOCK')
            return submit(self, scheduled_batch, batch=batch)
        ModelRunner.submit = captured_submit
    if cfg.get('P_only_profiler'):
        import multiprocessing as mp
        import vllm_rlt.engine.llm_engine as llm
        original = llm.start_stage_worker
        def profiled(stage_config, device, model_source, options, *, connector_factory=None, max_control_messages=32):
            if stage_config.role != cfg.get('capture_role', 'prefill'):
                return original(stage_config, device, model_source, options,
                    connector_factory=connector_factory, max_control_messages=max_control_messages)
            parent, child = mp.get_context('spawn').Pipe()
            payload = folder / f'profile_stage_{stage_config.role}.pickle'
            # Payload contains dataclasses and native factory parameters only.
            # It contains no model tensors and no replacement model execution.
            payload.write_bytes(pickle.dumps((stage_config, device, model_source, options,
                dict(connector_factory=connector_factory, max_control_messages=max_control_messages))))
            command = ['nsys', 'profile', '--trace=cuda,nvtx', '--sample=none', '--cpuctxsw=none', '--cuda-graph-trace=node',
                '--capture-range=cudaProfilerApi', '--capture-range-end=stop', '--force-overwrite=false',
                '--output='+str(folder/'p_only_trace'), str(PYTHON), '-m', 'poc_flashvep.looped_pd_headroom_recovery.stage', str(payload), str(child.fileno())]
            log = (folder / 'p_only_profiler.log').open('w')
            process = subprocess.Popen(command, cwd=REPO, env=os.environ.copy(), pass_fds=(child.fileno(),), stdout=log, stderr=subprocess.STDOUT)
            child.close()
            append(folder/'profile_launch.jsonl', dict(time=time.time(), pid=process.pid, role=stage_config.role, command=command))
            return ProcessAdapter(process), parent
        llm.start_stage_worker = profiled
