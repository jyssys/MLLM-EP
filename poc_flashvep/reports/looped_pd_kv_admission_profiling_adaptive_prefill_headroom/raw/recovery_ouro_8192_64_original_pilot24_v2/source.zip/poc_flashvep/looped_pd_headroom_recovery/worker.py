"""Use the qualified runner without changing tensor or transfer semantics."""
import importlib
import os
from .common import configure


def main():
    old = configure()
    cfg = old.config()
    if cfg['worker'] == 'native_mixed_worker':
        from ..looped_pd_atomic_prefill import native_mixed_worker
        native_mixed_worker.install()
    else:
        from .runtime import install
        install()
    module = importlib.import_module('poc_flashvep.looped_pd_atomic_prefill.' + cfg['worker'])
    module.ROOT = old.ROOT
    module.main()


if __name__ == '__main__':
    main()
