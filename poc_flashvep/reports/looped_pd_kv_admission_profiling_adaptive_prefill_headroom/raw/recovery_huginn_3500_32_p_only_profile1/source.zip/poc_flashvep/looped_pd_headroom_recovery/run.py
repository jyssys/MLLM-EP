"""Run one immutable namespace. Isolate timing and retain failed evidence."""
import argparse
import fcntl
import importlib
import signal
import zipfile
from .common import *


def execute(name, keep_quiet=True):
    setup()
    preserve()
    path=ROOT/'configs'/(name+'.json')
    cfg=json.loads(path.read_text())
    folder=ROOT/'raw'/name
    if folder.exists():
        result=folder/'dispatcher_result.json'
        if result.exists():return json.loads(result.read_text())['returncode']==0
        raise RuntimeError('Unfinished namespace requires explicit evidence review: '+name)
    owner=resources()
    with (ROOT/'state/quiet_lane.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        owner.stop(list(range(8)))
        folder.mkdir()
        write(folder/'configuration.json',cfg)
        write(folder/'isolation.json',dict(time=time.time(),active=owner.processes(),approved_burners=owner.burners(),
            GPU_query=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,pci.bus_id,memory.total,memory.free,driver_version','--format=csv'],text=True),
            lane='EXCLUSIVE_ALL_GPU_QUIET_LANE'))
        with zipfile.ZipFile(folder/'source.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
            for package in ('looped_pd_headroom_recovery','looped_pd_atomic_prefill','looped_pd_bottleneck_crossover',
                'adaptive_loop_token_pd_2gpu','adaptive_recurrence_cut','looped_pd_abc','looped_pd_b_numerical_diagnosis'):
                for p in (REPO/'poc_flashvep'/package).rglob('*.py'):
                    archive.write(p,str(p.relative_to(REPO)))
            archive.write(ROOT/'state/private_runtime.patch','private_runtime.patch')
        env=environment(cfg['gpus'])
        env.update(ARC_CONFIG=str(path),ARC_RUN=name,ABC_LANE='isolated_headroom_recovery')
        command=[str(PYTHON),'-m','poc_flashvep.looped_pd_headroom_recovery.worker',str(path)]
        if cfg.get('local_nsys'):
            command=['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node',
                '--capture-range=cudaProfilerApi','--capture-range-end=stop','--force-overwrite=false',
                '--output='+str(folder/'p_only_trace')]+command
        stopped=False
        started=time.monotonic()
        with (ROOT/'logs'/(name+'.log')).open('w') as log:
            child=subprocess.Popen(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            append(ROOT/'commands.jsonl',dict(time=time.time(),name=name,pid=child.pid,command=command,
                source_SHA256=digest(folder/'source.zip'),config_SHA256=digest(path),
                git_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()))
            write(ROOT/'state/active.json',dict(name=name,pid=child.pid,gpus=cfg['gpus'],time=time.time()))
            print('START',name,child.pid,flush=True)
            signature=None
            progress=time.monotonic()
            while child.poll() is None:
                paths=[folder/'requests.jsonl',folder/'cohorts.jsonl']
                current=[(p.name,p.stat().st_size) for p in paths if p.exists()]
                if current!=signature:signature=current;progress=time.monotonic()
                limit=cfg.get('startup_timeout',240)+cfg.get('timeout',300)
                reason=None
                if time.monotonic()-started>limit:reason='BOUNDED_JOB_WATCHDOG'
                if cfg.get('P_only_profiler') and signature and time.monotonic()-progress>60:
                    reason='PROFILE_NO_RESPONSE_PROGRESS_60S'
                if reason:
                    for stackfile in folder.glob('worker_stacks_*.log'):
                        pid=int(stackfile.stem.rsplit('_',1)[1])
                        try:
                            if Path('/proc',str(pid)).stat().st_uid==os.getuid():os.kill(pid,signal.SIGUSR1)
                        except ProcessLookupError:pass
                    write(folder/'watchdog.json',dict(reason=reason,time=time.time(),progress=signature))
                    assert os.getsid(child.pid)==child.pid
                    os.killpg(child.pid,signal.SIGTERM)
                    try:child.wait(15)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                    stopped=True
                    break
                time.sleep(.5)
        status_path=folder/'status.json'
        leftovers=[]
        for row in owner.processes():
            try:
                if Path('/proc',str(row['pid'])).stat().st_uid==os.getuid() and os.getsid(row['pid'])==child.pid:
                    leftovers.append(row)
            except ProcessLookupError:pass
        if leftovers:
            append(folder/'owned_session_cleanup.jsonl',dict(time=time.time(),registered_session=child.pid,GPUs=leftovers))
            try:os.killpg(child.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            until=time.monotonic()+15
            while time.monotonic()<until:
                alive=[]
                for row in owner.processes():
                    try:
                        if os.getsid(row['pid'])==child.pid:alive.append(row)
                    except ProcessLookupError:pass
                if not alive:break
                time.sleep(.5)
            if alive:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
        status=json.loads(status_path.read_text()) if status_path.exists() else {}
        ok=child.returncode==0 and status.get('status')=='COMPLETE'
        write(folder/'dispatcher_result.json',dict(returncode=child.returncode,status=status.get('status'),
            watchdog=stopped,complete=ok,elapsed_seconds=time.monotonic()-started,time=time.time()))
        write(ROOT/'state/active.json',dict(status='IDLE',time=time.time()))
        print('END',name,child.returncode,status.get('status'),flush=True)
        if not keep_quiet and not owner.processes():owner.restore(list(range(8)))
        return ok


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('name')
    p.add_argument('--restore',action='store_true')
    a=p.parse_args()
    raise SystemExit(0 if execute(a.name,not a.restore) else 1)
