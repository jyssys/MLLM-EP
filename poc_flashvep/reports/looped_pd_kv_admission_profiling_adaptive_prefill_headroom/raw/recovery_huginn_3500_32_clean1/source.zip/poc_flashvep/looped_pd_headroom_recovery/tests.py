"""CPU regressions for new isolation and profiling helpers."""
import subprocess
import sys
import unittest
from .runtime import ProcessAdapter


class RuntimeTests(unittest.TestCase):
    def test_union_does_not_sum_overlapping_kernel_times(self):
        from .profile_analysis import union
        self.assertEqual(union([(0,10),(2,4),(8,14),(20,23)]),17)
        self.assertEqual(union([]),0)
    def test_vector_bytecheck_preserves_legacy_stream(self):
        import torch
        from types import SimpleNamespace as NS
        from .bytecheck import fingerprint
        from ..looped_pd_abc.verify import fingerprint as legacy
        keys=torch.arange(40*8*4*2*3,dtype=torch.float32).reshape(40,8,4,2,3).to(torch.bfloat16)
        cache=NS(num_layers=8,max_loops=4,block_size=4,key_cache=keys,value_cache=keys+1)
        allocation=NS(block_tables=tuple(tuple(range(d*7,d*7+6)) for d in range(4)))
        cache._get_allocation=lambda tid:allocation
        connector=NS(cache=cache,engine=NS(model=NS(recurrent_kv_layers=(2,3,4,5),coda_kv_layers=(6,7))),
            hidden=torch.arange(24,dtype=torch.bfloat16).reshape(3,8))
        for n in (1,3,4,7,8,19):
            transfer=NS(tid='cpu',request=NS(prompt_token_ids=list(range(n))),slot=1)
            self.assertEqual(fingerprint(connector,transfer),legacy(connector,transfer))
        connector.cut=2
        self.assertEqual(fingerprint(connector,transfer),legacy(connector,transfer))

    def test_plane_selection_preserves_all_operand_bytes(self):
        import torch
        from .state_probe import plane
        tensor=torch.arange(11*4*3*5).reshape(11,4,3,5)
        blocks=torch.tensor([9,1,6,3])
        for layer in range(4):
            old=tensor.index_select(0,blocks)[:,layer]
            actual=plane(tensor,blocks,layer)
            self.assertTrue(torch.equal(old,actual))
            self.assertEqual(old.contiguous().numpy().tobytes(),actual.contiguous().numpy().tobytes())

    def test_process_adapter_matches_native_client(self):
        child=subprocess.Popen([sys.executable,'-c','pass'])
        adapted=ProcessAdapter(child)
        self.assertEqual(adapted.pid,child.pid)
        adapted.join(10)
        self.assertFalse(adapted.is_alive())
        self.assertEqual(adapted.exitcode,0)

    def test_actual_request_uses_generated_token_ids(self):
        from pathlib import Path
        source=Path('/home/esjung/external/looped-pd-abc-rlt/vllm_rlt/request.py').read_text()
        self.assertIn('generated_token_ids: list[int]',source)
        self.assertNotIn('num_output_tokens:',source)
        hook=Path(__file__).with_name('runtime.py').read_text()
        self.assertIn('len(r.generated_token_ids)',hook)
        self.assertNotIn('r.num_output_tokens',hook)

    def test_capture_is_selected_stage_only(self):
        from pathlib import Path
        source=Path(__file__).with_name('runtime.py').read_text()
        self.assertIn("stage_config.role != cfg.get('capture_role', 'prefill')",source)
        self.assertIn("'--capture-range=cudaProfilerApi'",source)


if __name__=='__main__':
    unittest.main()
