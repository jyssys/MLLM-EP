"""Capture activity before measured serving and export after serving ends."""
import ctypes
import os
import time
from .common import ROOT, write


def library():
    lib=ctypes.CDLL(str(ROOT/'tools/deferred_activity.so'))
    lib.activity_timestamp.argtypes=[ctypes.POINTER(ctypes.c_uint64)]
    lib.activity_end.argtypes=[ctypes.c_char_p]
    for key in ('dropped','invalid','count','allocated'):
        getattr(lib,'activity_'+key).restype=ctypes.c_uint64
    return lib


def anchor(lib):
    value=ctypes.c_uint64();lower=time.monotonic_ns()
    assert lib.activity_timestamp(ctypes.byref(value))==0
    upper=time.monotonic_ns()
    return dict(cupti_ns=value.value,monotonic_lower_ns=lower,monotonic_upper_ns=upper)


def install(cfg):
    assert not cfg.get('kernel_activity_seconds') and not cfg.get('sparse_device_trace')
    import torch
    from vllm_rlt.engine.stage_engine import StageEngine
    previous_stats=StageEngine.stats;previous_close=StageEngine.close
    folder=ROOT/'raw'/cfg['name'];state=dict(started=False)

    def stats(engine,*args,**kwargs):
        result=previous_stats(engine,*args,**kwargs)
        if not state['started']:
            lib=library();assert lib.activity_begin()==0
            state.update(started=True,lib=lib,begin=anchor(lib),role=engine.stage_config.role)
            write(folder/f"full_activity_{state['role']}_begin.json",dict(
                anchor=state['begin'],pid=os.getpid(),scope='Capture starts at the first stage stats response. Analysis clips to the measured cohort.'))
        return result

    def close(engine):
        if state['started']:
            torch.cuda.synchronize()
            end=anchor(state['lib']);role=state['role']
            code=state['lib'].activity_end(str(folder/f'full_activity_{role}.csv').encode())
            write(folder/f'full_activity_{role}_end.json',dict(anchor=end,result=code,
                dropped=state['lib'].activity_dropped(),invalid=state['lib'].activity_invalid(),
                kernels=state['lib'].activity_count(),allocated_bytes=state['lib'].activity_allocated(),
                scope='Export occurs after measured serving. CUDA synchronization occurs only during close.'))
            state['started']=False
            assert code==0,'Deferred activity collector failed'
        return previous_close(engine)

    StageEngine.stats=stats;StageEngine.close=close
