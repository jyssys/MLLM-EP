"""Write the final report from retained gates, not from expected outcomes."""
import statistics
from datetime import datetime
from zoneinfo import ZoneInfo
from .common import *

FINAL = REPO / 'poc_flashvep/reports/ouro_huginn_loop_specific_native_split_deep_validation_final_summary.md'


def load(name, default):
    path = ROOT / name
    return json.loads(path.read_text()) if path.exists() else default


def number(value, digits=3):
    return f'{value:.{digits}f}' if isinstance(value, (int, float)) else 'NOT_MEASURED'


def table(headers, rows):
    lines = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |']
    return '\n'.join(lines + ['| ' + ' | '.join(str(cell).replace('|', '/') for cell in row) + ' |' for row in rows])


def ratio_cell(entry):
    if not entry or 'geometric_mean_ratio' not in entry:
        return 'NOT_MEASURED'
    interval = entry.get('ratio_CI95')
    return (number(entry['geometric_mean_ratio'], 4) +
            (f' [{interval[0]:.4f}, {interval[1]:.4f}]' if interval else ' [CI_NOT_ESTABLISHED]') +
            f', n={entry["starts"]}')


def main():
    initialize()
    status = load('analysis_status.json', {})
    qualifications = load('state/qualification.json', {}).get('models', {})
    rows = load('serving_results.json', [])
    clean = [row for row in rows if row['data_split'] == 'heldout' and not row['markers']
             and row['correctness_passed'] and not row['calibration']]
    pairs = load('paired_confirmation_ratios.json', {})
    graph_rows = load('graph_cache_results.json', [])
    provenance = load('state/heldout_data_provenance.json', {})
    validation = load('oracle_static_validation.json', {})
    oracle = load('oracle_headroom.json', {})
    failures = load('failure_inventory.json', [])
    selection = load('state/frozen_static_selection.json', {}).get('selected', {})
    preservation = load('state/preservation.json', {})
    decision = {}
    for model in ('ouro', 'huginn'):
        partials = []
        negative = []
        loop_targets = []
        for method, metrics in pairs.get(model, {}).get('marker_free', {}).items():
            if method in ('native', 'zero'):
                continue
            sample = [row for row in clean if row['model'] == model and row['load'] == 'medium' and row['method'] == method]
            entry = metrics.get('TTFT_p95_ms', {})
            interval = entry.get('ratio_CI95')
            if len(sample) >= 3 and interval and interval[1] < 1 and all(row['Decode_SLO_screen'] and row['graph_coverage_passed'] for row in sample):
                partials.append(method)
            if method.startswith(('loop', '2d_')):
                loop_targets.append(method)
                if len(sample) >= 3 and (not all(row['Decode_SLO_screen'] for row in sample) or
                                         (interval and interval[0] >= 1)):
                    negative.append(method)
        methods = {row['method'] for row in clean if row['model'] == model and row['load'] == 'medium'}
        comparable = all(any(method.startswith(axis) for method in methods) for axis in ('native', 'token', 'loop', '2d_'))
        repeated = comparable and all(sum(row['model'] == model and row['load'] == 'medium' and row['method'] == method for row in clean) >= 3
                                      for method in methods)
        decision[model] = dict(
            practical_verdict='CONDITIONAL_GO' if partials else
                'NO_GO_ON_MEASURED_STATIC_CANDIDATES' if repeated and loop_targets and len(negative) == len(loop_targets) else 'INCONCLUSIVE',
            confirmed_TTFT_candidates=partials,
            rejected_or_confidently_slower_loop_candidates=negative,
            exclusive_loop_novelty='NO_GO_LOOP_SPECIFIC' if repeated else 'INCONCLUSIVE',
            oracle_verdict=oracle.get('status', 'NOT_MEASURED'),
            scope='A practical TTFT result does not establish goodput improvement or an exclusive recurrent mechanism. An identical generic logical-layer boundary is equivalent.')
    write(ROOT / 'final_decisions.json', decision)
    text = [
        '# Deep validation of native Token, Loop, and 2D splits',
        '## 1. Outcome and scope',
        table(['Model', 'Measured static-method verdict', 'Repeated TTFT candidates', 'Exclusive Loop-specific verdict'],
              [[model, value['practical_verdict'], ', '.join(value['confirmed_TTFT_candidates']) or 'NONE_CONFIRMED', value['exclusive_loop_novelty']]
               for model, value in decision.items()]),
        'The static-candidate verdict covers tested cuts and finite cohorts only. It does not establish a global impossibility result.',
        'Generic logical-layer execution can reproduce the same Loop boundary, state ownership, and aliased weights. This case is `EQUIVALENT_MECHANISM`.',
        'A wider 2D candidate space does not establish novelty. No new online dynamic scheduler is presented in this campaign.',
        '## 2. Environment, preservation, and time',
        f'Start: {datetime.fromtimestamp(START, ZoneInfo("Asia/Seoul")).isoformat()}.',
        f'Report time: {datetime.now(ZoneInfo("Asia/Seoul")).isoformat()}.',
        f'Elapsed wall time: {(time.time() - START) / 3600:.3f} hours. The fixed overall budget is 11 hours.',
        f'GPU stop: {datetime.fromtimestamp(GPU_DEADLINE, ZoneInfo("Asia/Seoul")).isoformat()}.',
        f'Source parent: `{BASE}`. Publication branch: `{BRANCH}`.',
        'The publication receipt records the evidence commit. The final remote-verification file records the final metadata commit and remote SHA.',
        'The active checkout and real staged index remain separate from the publication branch. The external runtime remains unchanged.',
        'The source archives record every loaded intervention and the qualified private-runtime diff for each run.',
        f'Preserved active HEAD: `{preservation.get("worktree_HEAD", "NOT_MEASURED")}`. Private runtime HEAD: `{preservation.get("private_HEAD", "NOT_MEASURED")}`.',
        f'Preserved staged-index SHA256: `{preservation.get("index_entries_SHA256", "NOT_MEASURED")}`.',
        f'Preserved private-diff SHA256: `{preservation.get("private_diff_SHA256", "NOT_MEASURED")}`.',
        'Hardware: eight H100 80GB devices. Each serving job uses one isolated two-GPU 1P1D pair.',
        'Ouro uses GPUs 0/1. Huginn uses GPUs 4/5. Other GPUs remain quiet during clean timing to prevent shared-host interference.',
        'No eight-GPU serving speedup is claimed. Approved burners resume only when the experiment does not own the quiet lane.',
        'Preservation details: [preservation.json](ouro_huginn_loop_specific_native_split_deep_validation/state/preservation.json).',
        '## 3. Models, data, loads, and SLOs',
        table(['Model', 'Precision / depth', 'Input / output tokens', 'Low / medium / heavy nominal QPS', 'P/D slots'], [
            ['ByteDance/Ouro-1.4B', 'Original BF16 / R4', '4096 / 32', '1.23460875 / 3.4569045 / 6.356', '2 / 8'],
            ['tomg-group-umd/huginn-0125', 'Original BF16 / R32', '2048 / 16', '0.37903355455 / 1.06129395274 / 1.971', '2 / 8']]),
        'All methods retain original weights, qualified numerical fixes, exact Attention, and full recurrent work. Huginn retains Prelude, Coda, and reinjection.',
        'The prompt pool uses pinned ShareGPT and LongBench text. Inputs are length-controlled tokenizer prefixes. Outputs use fixed caps with ignore-EOS.',
        'These lengths are not natural response distributions or Azure traffic. Huginn remains inside its 4096-token context limit.',
        'Discovery uses the previous pool. Confirmation uses 128 new prompt IDs. Separate calibration uses 32 additional IDs.',
        'Model revisions: Ouro `574fa66cb8bf5abdc979642d01cf2b79b16bfab1`. Huginn `bb6621b65e90b6a4b9b29ef88dc83866d450470c`.',
        'ID, source-hash, and model-specific first-128-token-prefix checks exclude overlap between previous, held-out, and calibration pools.',
        'The actual token IDs, source revisions, and dataset counts are retained in the data manifest. Prefix caching remains disabled.',
        'All paired methods share prompt IDs, generation seeds, fixed output caps, and open-loop Poisson arrival offsets.',
        'SLOs remain unchanged from the previous campaign:',
        table(['Model', 'TTFT, ms', 'Request-average TPOT, ms', 'Token ITL p99, ms'], [
            ['Ouro', '1112.9925646819174', '53.70702898374411', '65.08287642151119'],
            ['Huginn', '1963.9920117333531', '186.5715059141318', '192.8212538175284']]),
        'The additional-work screen requires TPOT p95 at most 90% of its limit and ITL p99 at most its frozen limit.',
        'Joint goodput counts requests that meet both request TTFT and request-average TPOT. Failed and timed-out offered requests remain in the denominator.',
        'Finite overloaded cohorts are not sustainable serving capacity.',
        '## 4. Scheduler recovery and exactness',
        'An unused D-local-probe pacing hook changed the effective D scheduler. The new configs disable this unused hook for every method.',
        'The runtime checks requested and effective non-Wavefront settings after stage construction. The native one-depth Wavefront guard remains unchanged.',
        'The isolated Huginn Native and Token1984 N8 tests separate this configuration correction from the later graph intervention.',
    ]
    qualification_rows = []
    for model, item in qualifications.items():
        for method, gate in item['qualification'].items():
            checks = gate.get('checks', [])
            qualification_rows.append([model, method, 'PASS' if gate['passed'] else 'FAIL_OR_INCOMPLETE',
                                       ', '.join(str(row.get('name', row.get('status'))) for row in checks)])
    text += [table(['Model', 'Method', 'N8 and N32 gate', 'Retained checks'], qualification_rows),
        'N32 means simultaneous submission of 32 requests. It does not mean 32 active GPU requests.',
        'Exact gates compare output tokens, valid prompt KV hashes, the recorded prompt hidden state, transferred valid bytes, full recurrent rows, and source lifetime.',
        'The hidden-state gate covers the recorded boundary. It does not compare every intermediate tensor after every operation.',
        'Source retirement follows native ACK. Final coordinator credits and native allocations must retire. Forced full-PD branches are not a complete online admission policy.',
        'Original-HF fidelity, downstream accuracy, and every-token hidden-state equivalence remain NOT_MEASURED.',
        '## 5. Graph-cache diagnosis and control',
        'The native packed graph cache uses exact query/context geometry. Startup order can fill four entries before primary single-request shapes appear.',
        'The cache does not evict old entries. A full cache sends unseen shapes to eager execution.',
        'The common intervention reserves primary B1/B2 geometries and performs one serial full-prompt warm-up before ordinary warm-up.',
        'The cache4 qualification exposed a three-request D geometry. The main comparison therefore uses the common eight-entry cap and exact D-geometry warm-up.',
        'All main methods use the same policy. Warm-up requests do not enter measured latency or throughput.',
        'Ouro 2D requires four P geometries: 4096, 8192, 3072, and 6144 query rows. The query length remains part of each key.',
        'Legacy4, reserved4, and reserved8 controls preserve the policy and budget distinction. The control packages change admission and warm-up together.',
        'A primary-shape hit is not a GPU kernel count. Capture time and host preparation time are not exclusive kernel time.',
    ]
    g = [row for row in graph_rows if row['name'].startswith(('d_', 'h_')) and row['role'] == 'prefill']
    text += [table(['Run', 'P hit ratio', 'Cold entries', 'Eager fallbacks', 'Cache entries'],
                  [[row['name'], number(row.get('measured_existing_hit_ratio'), 4), row['cold_entries'], row['fallbacks'], len(row['entries'])] for row in g]),
        '## 6. Held-out clean serving and load dependence',
        'The following cells average per-run percentiles across independent starts. They are not pooled request percentiles.',
        'Full p50/p95/p99 metrics and offered/realized/completed rates remain in serving_results.csv and raw per-request files.',
    ]
    performance = []
    keys = sorted({(row['model'], row['load'], row['method']) for row in clean})
    for model, load, method in keys:
        sample = [row for row in clean if (row['model'], row['load'], row['method']) == (model, load, method)]
        mean = lambda key: statistics.mean(row[key] for row in sample)
        performance.append([model, load, method, len(sample), number(mean('TTFT_p95_ms')),
            number(mean('TPOT_p95_ms')), number(mean('ITL_p99_ms')), number(mean('E2E_p95_ms')),
            number(mean('joint_SLO_goodput'), 4), f'{sum(row["Decode_SLO_screen"] for row in sample)}/{len(sample)}'])
    text += [table(['Model', 'Load', 'Method', 'Starts', 'TTFT p95 ms', 'TPOT p95 ms', 'ITL p99 ms', 'E2E p95 ms', 'Joint goodput req/s', 'Decode-screen passes'], performance),
        '## 7. Huginn Loop31 and paired uncertainty',
        'Marker-free confirmation is the primary latency comparison. The unit of replication is an independent start, not an individual request or token.',
        'Intervals use a paired t interval on log ratios. Three to five starts require the stated small-sample distribution assumption.',
        'A TTFT confidence interval below one supports a TTFT reduction. It does not establish an E2E or goodput improvement.',
        'If all tested Token partials fail the Decode screen, Native full-PD remains the safe Token-only endpoint. An unsafe diagnostic partial is not a strong safe baseline.',
    ]
    ratio_rows = []
    for model in ('ouro', 'huginn'):
        for method, fields in pairs.get(model, {}).get('marker_free', {}).items():
            if method == 'native':
                continue
            ratio_rows.append([model, method, ratio_cell(fields.get('TTFT_p95_ms')),
                               ratio_cell(fields.get('E2E_p95_ms')), ratio_cell(fields.get('joint_SLO_goodput'))])
    text += [table(['Model', 'Method / Native', 'TTFT ratio [95% CI]', 'E2E ratio [95% CI]', 'Goodput ratio [95% CI]'], ratio_rows),
        'Marker ON/OFF runs remain separate. Service TTFT is NOT_MEASURED in marker-free runs.',
        'The safe Token reference also considers Native and zero-offload full-prefix endpoints. Discovery fixes this choice before held-out results exist.',
        'The absolute global-wall interference screen remains 5%. Local TTFT and ITL tail changes are reported separately.',
        'A global pass does not prove negligible tail perturbation. Rejected traces do not become clean performance evidence.',
        '## 8. TTFT decomposition and actual migration',
        'Native versus feature-enabled zero-offload is a same-boundary transport/runtime control. Loop versus zero is a separate redistribution comparison.',
        'A Native-to-Loop difference must not automatically become a Loop-compute gain. The control ratios remain in paired_zero_path_reference_ratios.json.',
        'Request TTFT starts at scheduled arrival. Queue/admission ends at the first actual model-stream Prefill entry.',
        'Service TTFT starts at that entry and includes native handoff, D continuation, Coda, and first output delivery.',
        'The per-request timestamp file reports clock-mapping brackets. Nonlinear clock drift is not fully bounded.',
        'Per-request intervals precede percentiles. Component p95 values are not added. Overlapping host/device/transfer durations are not added as speedup.',
        'Work counters report actual serving continuations. They do not count the previous independent D-local probes.',
        'Recurrent token rows are not FLOPs. Token suffix Attention reads the completed prefix, so equal rows do not imply equal Attention work.',
        'Transfer payload counters exclude control messages and transport headers. Commit, ACK, and source-retention intervals remain separate.',
        'HBM snapshots report GiB and percentages of the recorded physical HBM total. Allocator totals overlap component tensors.',
        'Exposed graph tensors do not account for every opaque graph-pool or library allocation. Warm-up memory is not claimed as clean peak HBM.',
        'Current kernel union, SM cycles, achieved bandwidth, and achieved GEMM throughput are NOT_MEASURED unless a separately qualified profile is present.',
        'CUDA event enclosures can include launch gaps and waits. They are not exclusive GPU kernel time.',
        '## 9. Structural attribution and logical-layer equivalence',
        'The qualified numerical fix uses fixed 256-row Down-projection GEMMs. A full prompt does not imply one large Down-projection GEMM.',
        'For B1 Huginn, Loop31 moves 2048 semantic rows through one loop. Token1984 moves 64 rows through 32 loops.',
        'The unchanged Down projection uses eight fixed tiles per core layer in the first case and 32 in the second.',
        'This fourfold tile difference covers that projection only. Batching can change it. It is not a measured fourfold total-runtime difference.',
        'For Ouro, Loop3 and Token3072 have equal semantic D rows and equal fixed Down-tile counts at B1. Their Attention and submission costs differ.',
        'Huginn Loop31 also changes full-prompt Coda placement. Its 3.125% recurrent-row fraction excludes Coda and is not a FLOP fraction.',
        'Small service changes near capacity can amplify queue delay. The observed queue and Service TTFT results must support that explanation.',
        'A generic logical-layer split can reproduce these boundaries with shared recurrent-weight aliases. Both workers already hold the full model.',
        'Therefore a favorable native-runtime trade-off does not establish exclusive Loop-specific architecture novelty or a weight-residency saving.',
        '## 10. Validated offline oracle',
        f'Validation status: `{validation.get("status", "NOT_MEASURED")}`. Headroom status: `{oracle.get("status", "NOT_MEASURED")}`.',
        'Calibration prompts remain disjoint from discovery and confirmation. The cost model freezes before confirmation results exist.',
        'The event model includes P/D serialization, homogeneous batching, native transfer, ACK/source leases, D KV receiving credit, and fixed-depth Decode.',
        'Missing batch costs require explicit interpolation or extrapolation. Event enclosures and residuals are not exclusive GPU/CPU execution times.',
        'The validation screen requires median absolute relative error at most 15% and p95 error at most 25%. It also rejects false Decode-safe predictions.',
        'The report retains start-cluster error intervals. An inaccurate model cannot establish Feasible Oracle headroom.',
        'The restricted offline search knows future arrival times and output caps. It is not an online method or a global optimality certificate.',
        'Mixed-frontier GPU scheduling remains unqualified. Static-model accuracy alone does not prove accuracy for every dynamic plan.',
        '## 11. Prior work and reusable implementation',
        'The Token baseline is a FluidToken-style reproduction, not the official FluidPD system.',
        'FluidPD describes pressure-aware Token deflection with PPI/DPI and Decode slack. Our experiment retains native worker roles and exact prefix/suffix handoff.',
        'FluidPD permits stream-average TPOT slack borrowing. This experiment also retains its stricter frozen ITL p99 gate. The SLO contracts are not identical.',
        'The current native runner groups the selected D continuation into one operation. A Token suffix can therefore contain more recurrent iterations per scheduling quantum.',
        'Alternative suffix pacing or a common smaller D recurrence quantum is NOT_MEASURED. A result against these atomic candidates does not dominate every Token scheduler.',
        'Source: [FluidPD](https://arxiv.org/html/2610.06917v1). The inspected paper did not identify reusable official implementation code.',
        'The LoopServe reference uses a different pooled cache and execution ABI. The campaign reuses compatible scheduling lessons, not an unverified runtime transplant.',
        '## 12. Figures and complete evidence',
        'The figure manifest records measured, structural, modeled, and missing evidence separately.',
        '[Figure manifest](ouro_huginn_loop_specific_native_split_deep_validation/figure_manifest.json).',
        '[Serving results](ouro_huginn_loop_specific_native_split_deep_validation/serving_results.csv).',
        '[Paired intervals](ouro_huginn_loop_specific_native_split_deep_validation/paired_confirmation_ratios.json).',
        '[Graph results](ouro_huginn_loop_specific_native_split_deep_validation/graph_cache_results.csv).',
        '[Work and payload](ouro_huginn_loop_specific_native_split_deep_validation/work_and_payload.csv).',
        '[Fixed-tile accounting](ouro_huginn_loop_specific_native_split_deep_validation/fixed_tile_accounting.csv).',
        '[HBM inventory](ouro_huginn_loop_specific_native_split_deep_validation/gpu_memory_gib_percent.csv).',
        '[Oracle validation](ouro_huginn_loop_specific_native_split_deep_validation/oracle_static_validation.json).',
        '## 13. Failures, missing conditions, and research decision',
        f'Completed dispatches: {status.get("completed_dispatches", "NOT_MEASURED")}. Failed dispatches: {status.get("failed_dispatches", "NOT_MEASURED")}.',
        f'Completed-dispatch offered requests: {status.get("completed_offered_requests", "NOT_MEASURED")}. This count includes exactness and calibration, not just clean serving.',
        'The configuration inventory retains every prepared and attempted condition. Failure logs remain intact.',
        'N512 persistence is NOT_RUN unless its explicit state receipt exists. N128 repetition does not become 512 independent texts.',
        'A missing or inaccurate feasible oracle remains INCONCLUSIVE. It cannot establish structural absence of headroom.',
        'Do not begin a full dynamic-scheduler campaign solely because a selected static cut improves TTFT. Require Decode-safe repeated gains and a justified contribution.',
        '## 14. Reproduction and publication',
        'Use the qualified virtual environment and the preserved private runtime. Check the source and configuration hashes before each replay.',
        'Do not rerun immutable configuration names into existing raw directories. Use a fresh evidence namespace for a replay.',
        '```bash\n/home/esjung/.venvs/looped-pd-abc/bin/python -m poc_flashvep.native_split_deep_validation.audit\n/home/esjung/.venvs/looped-pd-abc/bin/python -m unittest discover -s poc_flashvep/native_split_deep_validation -p "test_*.py" -t .\n/home/esjung/.venvs/looped-pd-abc/bin/python -m poc_flashvep.native_split_deep_validation.analyze\n/home/esjung/.venvs/looped-pd-abc/bin/python -m poc_flashvep.native_split_deep_validation.oracle\n/home/esjung/.venvs/looped-pd-abc/bin/python -m poc_flashvep.native_split_deep_validation.figures\n```',
        'The publication uses a temporary Git index and ordinary push. The real staged index and private-runtime diff are checked before and after publication.',
        'Final resource and remote-SHA receipts are retained under state/.',
    ]
    token_pairs = load('paired_token_reference_ratios.json', {})
    token_rows = []
    for model, comparisons in token_pairs.items():
        for method, fields in comparisons['comparisons'].items():
            token_rows.append([model, method + ' / ' + comparisons['reference'],
                ratio_cell(fields.get('TTFT_p95_ms')), ratio_cell(fields.get('E2E_p95_ms')),
                ratio_cell(fields.get('joint_SLO_goodput'))])
    text.insert(text.index('## 8. TTFT decomposition and actual migration'),
        table(['Model', 'Method / selected Token', 'TTFT ratio [95% CI]', 'E2E ratio [95% CI]', 'Goodput ratio [95% CI]'], token_rows))
    FINAL.write_text('\n\n'.join(text) + '\n')
    print(FINAL)


if __name__ == '__main__':
    main()
