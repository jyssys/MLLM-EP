"""Reserve primary exact query geometries without changing native graph math."""
import os
import time
from types import MethodType


def preferred_geometry(cfg, role):
    """Return (query rows, maximum sequence query length), not padding buckets."""
    t = cfg['length']
    frontier = cfg.get('native_frontier')
    if role == 'prefill':
        queries = ([frontier[1]] if frontier and frontier[0] == 0 else
                   [t, frontier[1]] if frontier else [t])
        slots, limit = cfg['P_slots'], cfg['P_prefill_graph_rows']
    else:
        queries = ([t - frontier[1]] if frontier else
                   [t] if cfg.get('native_partial_cut') is not None else [])
        slots, limit = cfg['D_slots'], cfg['D_prefill_graph_rows']
    batches = [1, 2, 4, 8] if cfg['deep_graph_budget'] <= 4 else list(range(1, 9))
    return {(q * b, q) for q in queries for b in batches if b <= slots and q * b <= limit}


def install(cfg):
    from vllm_rlt.engine.stage_engine import StageEngine
    from vllm_rlt.worker.cuda_graph import PreparedGraph
    from ..looped_pd_atomic_prefill import rlt_worker
    from .common import ROOT, write, prior
    append = prior.parent.prior.append
    folder = ROOT / 'raw' / cfg['name']
    marker = folder / 'measurement_begin.json'
    initialize, close = StageEngine.__init__, StageEngine.close

    def initialized(engine, *args, **kwargs):
        result = initialize(engine, *args, **kwargs)
        graphs = getattr(engine, '_autonomous_prefill_graphs', None)
        if graphs is None:
            return result
        role = engine.stage_config.role
        allowed = preferred_geometry(cfg, role)
        counts = {phase: dict(selects=0, existing_hits=0, cold_entries=0, fallbacks=0,
                              policy_bypass=0, captures=0, prepare_host_s=0.)
                  for phase in ('startup', 'measured')}
        geometries = {}
        measured = [False]
        select, prepare = graphs.select, graphs.prepare_inputs
        def phase():
            if not measured[0]:
                measured[0] = marker.exists()
            return 'measured' if measured[0] else 'startup'

        def selected(owner, hidden, metadata):
            stage = phase()
            row = counts[stage]
            q = len(metadata.rows)
            geometry = (q, metadata.max_seqlen_q)
            description = (q, len(metadata.context_lengths), metadata.max_seqlen_q,
                           metadata.cu_seqlens_q is not None, getattr(metadata, 'write_mask', None) is not None)
            key = repr(description)
            entry = geometries.setdefault(key, dict(key=list(description), startup=0, measured=0,
                                                    existing_hits=0, fallbacks=0, cold_entries=0))
            entry[stage] += 1
            row['selects'] += 1
            if cfg['deep_graph_policy'] == 'primary_reserved' and geometry not in allowed:
                owner.fallbacks += 1
                row['fallbacks'] += 1
                row['policy_bypass'] += 1
                entry['fallbacks'] += 1
                return PreparedGraph(metadata)
            previous = len(owner.entries)
            call = select(hidden, metadata)
            if call.entry is None:
                row['fallbacks'] += 1
                entry['fallbacks'] += 1
            elif len(owner.entries) > previous:
                row['cold_entries'] += 1
                entry['cold_entries'] += 1
            else:
                row['existing_hits'] += 1
                entry['existing_hits'] += 1
            return call

        def prepared(owner, call, hidden):
            stage = phase()
            captures = owner.captures
            begin = time.perf_counter()
            result = prepare(call, hidden)
            counts[stage]['prepare_host_s'] += time.perf_counter() - begin
            counts[stage]['captures'] += owner.captures - captures
            return result

        graphs.select = MethodType(selected, graphs)
        graphs.prepare_inputs = MethodType(prepared, graphs)
        engine._deep_graph_audit = dict(role=role, allowed_geometries=sorted(allowed),
            policy=cfg['deep_graph_policy'], budget=cfg['deep_graph_budget'], counts=counts,
            geometries=geometries, initial_allocated_bytes=__import__('torch').cuda.memory_allocated())
        return result

    def closed(engine):
        value = getattr(engine, '_deep_graph_audit', None)
        if value is not None:
            graphs = engine._autonomous_prefill_graphs
            entries = [dict(key=list(key), captured=entry.graph is not None,
                            input_hidden_bytes=entry.hidden.numel() * entry.hidden.element_size())
                       for key, entry in graphs.entries.items()]
            write(folder / f'deep_graph_cache_{os.getpid()}.json', dict(value, entries=entries,
                scope='Exact native packed-prefill cache. Startup and measured counters are separate. Host preparation time is not exclusive kernel time.'))
        return close(engine)
    StageEngine.__init__, StageEngine.close = initialized, closed

    if not cfg.get('deep_serial_primary_warmup'):
        return
    serve = rlt_worker.serve
    def warm_primary(engine, inputs):
        from vllm_rlt import SamplingParams
        from ..looped_pd_headroom_recovery.graph_warmup import worker_stats
        seed = cfg['seed'] - 20000
        rid = 'deep_primary_serial_warmup'
        phase_marker = folder / 'native_graph_warmup_phase.json'
        write(phase_marker, dict(state='RUNNING', kind='deep_primary_serial', seeds=[seed], count=1))
        before = worker_stats(engine)
        begin = time.monotonic()
        engine.add_request(rid, list(inputs[0]), SamplingParams(max_tokens=1, temperature=0., seed=seed,
            min_loops=cfg['depth'], max_loops=cfg['depth'], exit_threshold=1., ignore_eos=True))
        finished = False
        while not finished:
            if time.monotonic() - begin > 180:
                raise TimeoutError('Deterministic primary graph warm-up')
            for out in engine.step():
                if out.finished:
                    assert out.request_id == rid and len(out.token_ids) == 1
                    assert set(out.exit_depths) == {cfg['depth']}
                    finished = True
        while getattr(engine, 'transfers', {}):
            if time.monotonic() - begin > 180:
                raise TimeoutError('Deterministic primary ACK drain')
            assert not engine.step()
        after = worker_stats(engine)
        work = sum(v['issued_loop_rows'] - before[k]['issued_loop_rows'] for k, v in after.items())
        assert work == len(inputs[0]) * cfg['depth']
        append(folder / 'deep_primary_warmup.jsonl', dict(host_seconds=time.monotonic() - begin,
            input_tokens=len(inputs[0]), full_recurrent_rows=work, passed=True,
            scope='One exact startup request before ordinary warm-up. Excluded from serving statistics.'))
        write(phase_marker, dict(state='COMPLETE', kind='deep_primary_serial'))

    def served(engine, inputs, args, run, warmup=False, contract=None):
        if warmup:
            warm_primary(engine, inputs)
        return serve(engine, inputs, args, run, warmup, contract)
    rlt_worker.serve = served
