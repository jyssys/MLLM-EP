"""Matched legacy/reserved cache controls. Never use legacy as the main baseline."""
from .common import *
from .prepare import configuration
from .qualification import qualify
from .serving import evaluate


def main(gate):
    initialize()
    if not gate['models']['ouro']['qualification'].get('2d_c3_k3072', {}).get('passed'):
        return
    cfg = configuration('ouro', '2d_c3_k3072', 8, 'h_ouro_2d_legacy_cache_state8',
                        state=True, simultaneous=True, policy='legacy')
    save(cfg)
    qualification = qualify(cfg['name'], 'b_ouro_native_reserved4_state8')
    ledger = dict(qualification=qualification, results=[])
    if not qualification['passed']:
        write(ROOT / 'state/cache_sensitivity.json', ledger)
        return
    for start in (1, 2, 3):
        for policy in (('primary_reserved', 'legacy') if start == 2 else ('legacy', 'primary_reserved')):
            cfg = configuration('ouro', '2d_c3_k3072', 128, f'h_ouro_2d_{policy}_s{start}_on128',
                                start=start, policy=policy, arrival_seed=2026110510 + start)
            result = evaluate(cfg, f'c_ouro_native_discovery_s{start}_off128')
            ledger['results'].append(result)
            write(ROOT / 'state/cache_sensitivity.json', ledger)
    return ledger
