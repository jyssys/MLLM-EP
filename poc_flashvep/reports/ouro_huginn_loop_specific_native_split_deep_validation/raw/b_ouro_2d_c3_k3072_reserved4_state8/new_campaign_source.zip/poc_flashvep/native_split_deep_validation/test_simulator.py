import copy
import unittest
from .simulator import Simulation


def curve(one, two):
    return {'1': dict(median=one), '2': dict(median=two)}


def fixture():
    action = dict(P_steps={'prelude': curve(10., 18.)}, D_prompt={},
                  handoff_ms=dict(median=3.), ACK_lag_ms=dict(median=1.),
                  serial_TPOT_ms=dict(median=6.), serial_service_ms=dict(median=14.),
                  P_window_gap_ms=dict(median=0.), D_window_gap_ms=dict(median=0.))
    partial = copy.deepcopy(action)
    partial.update(P_steps={'prelude': curve(8., 15.)}, D_prompt=curve(3., 5.), D_max_batch=2)
    return dict(actions=dict(native=action, loop1=partial), depth=2, cap=3, P_slots=2,
                D_slots=2, D_credit_limit=3,
                decode=dict(prelude=curve(1., 1.), recurrent=curve(2., 2.), coda=curve(1., 1.)))


class SimulatorTests(unittest.TestCase):
    def run_model(self, methods):
        return Simulation(fixture(), [0.] * len(methods), methods,
                          dict(TTFT_ms=1000., TPOT_ms=100., ITL_ms=100.)).run()

    def test_source_ack_and_causal_handoff_are_not_free(self):
        result = self.run_model(['native'] * 8)
        self.assertEqual(len(result['requests']), 8)
        for request in result['requests']:
            self.assertEqual(len(request['tokens']), 3)
            self.assertGreaterEqual(request['start'], request['arrival'])
            self.assertGreater(request['D_received'], request['P_completed'])
            self.assertGreater(request['source_ACK'], request['D_received'])
            self.assertGreater(request['tokens'][0], request['D_received'])

    def test_mixed_actions_complete_all_output_work(self):
        result = self.run_model(['native', 'loop1'] * 4)
        self.assertTrue(all(row['finished'] for row in result['requests']))
        self.assertEqual(len(result['requests']), 8)

    def test_unmeasured_actions_cannot_enter(self):
        with self.assertRaises(ValueError):
            self.run_model(['unmeasured'])


if __name__ == '__main__':
    unittest.main()
