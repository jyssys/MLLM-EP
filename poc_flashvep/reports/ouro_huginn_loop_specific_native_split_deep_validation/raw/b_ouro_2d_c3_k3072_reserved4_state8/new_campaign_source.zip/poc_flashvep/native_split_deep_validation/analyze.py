"""Analyze retained results without turning missing or rejected evidence into a win."""
import csv
import math
import statistics
from collections import Counter
from .common import *
from .granularity import account


def csv_write(path, rows):
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value) if isinstance(value, (dict, list)) else value
                             for key, value in row.items()})


def ratio(values):
    result = dict(starts=len(values), start_ratios=values)
    if not values:
        return result
    logs = [math.log(value) for value in values]
    center = statistics.mean(logs)
    result['geometric_mean_ratio'] = math.exp(center)
    critical = {3: 4.302652729911275, 4: 3.182446305284263, 5: 2.7764451051977987}
    if len(logs) in critical:
        half = critical[len(logs)] * statistics.stdev(logs) / math.sqrt(len(logs))
        result['ratio_CI95'] = [math.exp(center - half), math.exp(center + half)]
    result['scope'] = 'Paired independent-start log-ratio t interval. Requests and tokens are not independent starts. Small-sample normal-log-ratio assumption.'
    return result


def main():
    initialize()
    prior.parent.prior.preserve()
    inventory, serving, graphs, work, memory, tiles, failures = [], [], [], [], [], [], []
    for path in sorted((ROOT / 'configs').glob('*.json')):
        cfg = json.loads(path.read_text())
        if not isinstance(cfg, dict) or 'name' not in cfg:
            continue
        folder = ROOT / 'raw' / cfg['name']
        receipt_path = folder / 'dispatcher_result.json'
        receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
        row = dict(name=cfg['name'], model=cfg['model'], method=cfg['method'], count=cfg['count'],
            phase=cfg['phase'], split=cfg['data_split'], markers=cfg['observe_service_timing'],
            complete=receipt.get('complete', False), status=receipt.get('status', 'NOT_COMPLETED'),
            elapsed_job_wall_seconds=receipt.get('elapsed_seconds'), configuration_SHA256=digest(path))
        inventory.append(row)
        if receipt and not receipt.get('complete'):
            log = (ROOT / 'logs' / (cfg['name'] + '.log')).read_text(errors='replace')
            errors = [line for line in log.splitlines()
                      if line.startswith(('ValueError:', 'TypeError:', 'RuntimeError:', 'AttributeError:', 'AssertionError:'))]
            failures.append(dict(row, errors=errors))
        gate_path = folder / 'deep_serving_gate.json'
        if not gate_path.exists():
            continue
        gate = json.loads(gate_path.read_text())
        if not gate.get('complete'):
            continue
        serving.append(dict(gate['metrics'], name=cfg['name'], model=cfg['model'], method=cfg['method'],
            phase=cfg['phase'], data_split=cfg['data_split'], markers=cfg['observe_service_timing'],
            start=cfg['independent_start'], load=cfg['load'], count=cfg['count'],
            correctness_passed=gate['passed'], graph_coverage_passed=gate['performance_eligible_graphs'],
            calibration=bool(cfg.get('oracle_calibration')), cache_policy=cfg['deep_graph_policy']))
        work.append(dict(name=cfg['name'], model=cfg['model'], method=cfg['method'], **gate['actual_work']))
        for item in gate['graphs']['roles']:
            graphs.append(dict(name=cfg['name'], model=cfg['model'], method=cfg['method'],
                **{key: value for key, value in item.items() if key != 'measured'}, **item['measured']))
        tiles.extend(account(cfg['name']))
        for pattern, moment in (('memory_inventory_initial_*.json', 'INITIAL_STAGE'),
                                ('native_factory_memory_*.json', 'AFTER_CONNECTOR')):
            for source in folder.glob(pattern):
                value = json.loads(source.read_text())
                denominator = 81559 * 1024**2
                amount = {key: number for key, number in value.items()
                          if key.endswith('_bytes') and isinstance(number, (float, int))}
                memory.append(dict(name=cfg['name'], role=value['role'], moment=moment,
                    **{key + '_GiB': number / 1024**3 for key, number in amount.items()},
                    **{key + '_physical_HBM_percent': 100 * number / denominator for key, number in amount.items()},
                    physical_HBM_GiB=denominator / 1024**3,
                    scope='Component and allocator totals overlap. Not an additive HBM breakdown or complete opaque graph attribution.'))
    for name, rows in (('configuration_inventory', inventory), ('serving_results', serving),
                       ('graph_cache_results', graphs), ('work_and_payload', work),
                       ('gpu_memory_gib_percent', memory), ('fixed_tile_accounting', tiles),
                       ('failure_inventory', failures)):
        write(ROOT / (name + '.json'), rows)
        csv_write(ROOT / (name + '.csv'), rows)
    confirmation = [row for row in serving if row['data_split'] == 'heldout' and row['load'] == 'medium'
                    and row['correctness_passed'] and not row['calibration']]
    paired, markers = {}, []
    fields = ['TTFT_p95_ms', 'service_TTFT_ms_p95', 'E2E_p95_ms', 'TPOT_p95_ms', 'ITL_p99_ms',
              'joint_SLO_goodput', 'requests_per_second']
    for model in ('ouro', 'huginn'):
        paired[model] = {}
        for observed in (False, True):
            selected = [row for row in confirmation if row['model'] == model and row['markers'] == observed]
            native = {row['start']: row for row in selected if row['method'] == 'native'}
            methods = sorted({row['method'] for row in selected})
            section = paired[model]['marker_on' if observed else 'marker_free'] = {}
            for method in methods:
                candidates = {row['start']: row for row in selected if row['method'] == method}
                section[method] = {}
                for field in fields:
                    values = [candidates[start][field] / native[start][field]
                        for start in sorted(native.keys() & candidates.keys())
                        if field in native[start] and field in candidates[start]
                        and native[start][field] is not None and candidates[start][field] is not None
                        and native[start][field] > 0 and candidates[start][field] > 0]
                    section[method][field] = ratio(values)
            if not observed:
                continue
            for row in selected:
                controls = [value for value in confirmation if value['model'] == model
                    and value['method'] == row['method'] and value['start'] == row['start'] and not value['markers']]
                if not controls:
                    continue
                control = controls[0]
                wall = 100 * (row['response_span_s'] / control['response_span_s'] - 1)
                markers.append(dict(model=model, method=row['method'], start=row['start'],
                    on=row['name'], off=control['name'], wall_change_percent=wall,
                    TTFT_p95_change_percent=100 * (row['TTFT_p95_ms'] / control['TTFT_p95_ms'] - 1),
                    ITL_p99_change_percent=100 * (row['ITL_p99_ms'] / control['ITL_p99_ms'] - 1),
                    global_wall_screen_passed=abs(wall) <= 5,
                    scope='Global wall screen does not bound local request-tail perturbation.'))
    write(ROOT / 'paired_confirmation_ratios.json', paired)
    write(ROOT / 'marker_interference.json', markers)
    csv_write(ROOT / 'marker_interference.csv', markers)
    completed = [row for row in inventory if row['complete']]
    summary = dict(time=time.time(), elapsed_hours=(time.time() - START) / 3600,
        configurations=len(inventory), completed_dispatches=len(completed), failed_dispatches=len(failures),
        completed_offered_requests=sum(row['count'] for row in completed),
        completed_count_distribution=dict(Counter(row['count'] for row in completed)),
        marker_free_heldout_medium_runs=sum(not row['markers'] for row in confirmation),
        overall_deadline_epoch=DEADLINE, GPU_stop_epoch=GPU_DEADLINE,
        kernel_union='NOT_MEASURED_UNLESS_SEPARATE_PROFILE_IS_QUALIFIED',
        scope='Intermediate analysis until CAMPAIGN_CLOSED. Dispatch completion is separate from correctness, graph, Decode, and model-validation gates.')
    write(ROOT / 'analysis_status.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
