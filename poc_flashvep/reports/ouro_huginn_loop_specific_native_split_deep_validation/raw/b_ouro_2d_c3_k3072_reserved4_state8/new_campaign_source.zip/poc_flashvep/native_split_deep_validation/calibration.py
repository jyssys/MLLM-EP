"""Measure serial and burst costs on data that never enters confirmation."""
from .common import *
from .prepare import configuration
from .serving import evaluate


def main(gate, serving_ledger):
    initialize()
    ledger = dict(status='CALIBRATION_IN_PROGRESS', results=[])
    target = ROOT / 'state/cost_calibration.json'
    for model in ('huginn', 'ouro'):
        qualified = gate['models'][model]['qualification']
        methods = [method for method, value in qualified.items() if value.get('passed')]
        methods = ['native'] + [method for method in methods if method != 'native']
        pool_path = ROOT / 'data' / f'calibration_{model}_L{2048 if model == "huginn" else 4096}.json'
        pool = json.loads(pool_path.read_text())
        batch_name = pool_path.name.replace('calibration_', 'calibration_batch_')
        batch_file = ROOT / 'data' / batch_name
        if batch_file.exists():
            assert json.loads(batch_file.read_text()) == pool[8:]
        else:
            write(batch_file, pool[8:])
        for mode, count in (('serial', 8), ('burst', 24)):
            reference = None
            for method in methods:
                if time.time() >= LONG_START_CUTOFF - 1800:
                    ledger['status'] = 'NOT_RUN_TIME_BUDGET'
                    write(target, ledger)
                    return
                cfg = configuration(model, method, count, f'f_{model}_{method}_{mode}_cost{count}',
                                    split='calibration', markers=True)
                cfg.update(oracle_calibration=True, observe_device_execution=True,
                    calibration_serial=mode == 'serial', phase='INSTRUMENTED_CALIBRATION_NOT_CLEAN_SERVING',
                    seed=202611055001, arrival_rate=None, arrival_offsets=[index * .00001 for index in range(count)],
                    arrival_pattern='SERIAL_CALIBRATION' if mode == 'serial' else 'CONTROLLED_BOUNDED_BURST')
                if mode == 'burst':
                    cfg.update(dataset=batch_name, prompt_ids=[row['prompt_id'] for row in pool[8:]])
                result = evaluate(cfg, reference)
                ledger['results'].append(result)
                write(target, ledger)
                if method == 'native':
                    if not result.get('passed'):
                        break
                    reference = cfg['name']
    ledger['status'] = 'CALIBRATION_FINISHED'
    write(target, ledger)
