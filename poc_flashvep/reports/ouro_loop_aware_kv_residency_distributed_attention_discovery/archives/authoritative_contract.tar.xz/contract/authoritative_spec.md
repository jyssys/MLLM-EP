# Ouro: Loop-Aware KV Residency and Distributed Attention — Eight-GPU Research PoC

**Status:** Prospective, measurement-first research protocol. No performance claim is implied.

**Canonical server copy:** `/home/esjung/MLLM-EP-github/poc_flashvep/reports/ouro_loop_aware_kv_residency_distributed_attention_poc_spec.md`  
**Repository:** `/home/esjung/MLLM-EP-github`  
**Suggested reports:** `/home/esjung/MLLM-EP-github/poc_flashvep/reports/ouro_loop_aware_kv_residency_distributed_attention_discovery/`  
**Authorized physical GPUs:** NVIDIA H100 IDs **0,1,2,3,4,5,6,7**; never presume additional devices.  
**Model:** pinned `ByteDance/Ouro-1.4B` Base, BF16, original weights and semantics. Baseline is Ouro native Static R4. A second Ouro size is optional if available and verified.  
**Serving runtime:** pinned vLLM-RLT checkout with verified model, CUDA/FA4/Triton settings and unmodified native async/Mixed path for the strongest single-GPU baseline.  
**Research emphasis:** exact BF16 KV placement, memory movement, attention execution, single-GPU diagnosis and **real 2/4/8-GPU extensibility**.  
**Explicit exclusion:** Do **not** restart the paused native-vLLM Ouro Loop-PP project or implement loop-partitioned model execution. No cross-GPU loop-stage partition; all inter-GPU work here concerns context/KV sharding or distributed attention with exact model semantics. No additional training, KV quantization, model-depth reduction, hidden-state approximations or attention sparsification in the primary path.

---

## 0. Research question, decision boundary, and intellectual honesty

**Primary question:** Can the recurrence-indexed KV storage/access structure of an Ouro looped Transformer be exploited to improve exact inference memory capacity, real end-to-end latency or quality-qualified serving throughput, with a design that scales from one H100 to 2/4/8 H100s and improves beyond generic optimized Paged KV, tensor parallel (TP), and context/KV parallel (CP/KVP) baselines?

**Working title:** *Loop-Aware KV Residency and Distributed Attention (LAKRA)*. This is a hypothesis, not a proven algorithm or novelty claim. A negative result is valuable when it cleanly identifies a capacity-only benefit or a bandwidth/communication bottleneck.

Separate four independent claims:

1. **Capacity:** More complete BF16 KV tokens/sequences resident across GPUs or fewer allocator bytes wasted. This does **not** imply faster tokens/s at the same batch.
2. **Latency:** Full generated-token TTFT/ITL/TPOT/E2E is lower than the strongest matched optimized baseline, including communication, events and host coordination.
3. **Serving capacity:** At a stated SLO, the sustainable offered request rate is higher, with stable queues and sufficiently long natural requests. Do not replace it with finite drained throughput.
4. **Loop-specific incremental contribution:** A state/layout/planner feature exploiting repeated loops improves on *the same exact distributed-attention implementation* with a generic depth-agnostic KV layout/policy. A generic CP speedup is not automatically a looped-Transformer novelty.

**Baseline caution from previous Ouro work:** earlier observations included large KV footprint (around 12 GiB for B1 / 16K context in one prior configuration), but decode attention-core fraction was only ~7.3% in another profiled condition, and a prior generic CP operator was slower than local attention. Those were **different configurations**; reproduce the accounting and never infer that large KV bytes necessarily dominate GPU wall time. Exact model KV shapes, memory reservation and attention fraction must be remeasured with the current pinned runtime.

**No forcing a contribution:** if runtime and roofline measurements show too little KV critical-path headroom, terminate kernel/multiGPU engine development before expensive refactoring and report `NO_GO_HEADROOM`. If only larger context can fit across 2/4/8 GPUs, characterize a legitimate `CAPACITY_ONLY` result without rebranding it a latency win.

---

## 1. Research precedents and exact differentiation

### 1.1 Required papers and projects

Read and summarize source-grounded mechanisms and exact output constraints; keep an immutable bibliography in `related_work.md`:

- **FlashLoop: Fast and Memory-Efficient Looped Transformers via Lazy Updates**, arXiv 2609.29812; https://arxiv.org/abs/2609.29812 ; https://superone77.github.io/FlashLoop/ . Training-free but alters execution via token-sparse updates, sparse attention and low-bit cross-loop KV residuals. Reports up to 1.64× E2E and ~6× memory reduction; its reported benchmark accuracy retention is **not** bit-exact equivalence.
- **Hybrid Latent Attention for Looped Language Models (HLA)**, arXiv 2610.07940; https://arxiv.org/abs/2610.07940 . Keeps recent exact KV, uses compact latent memory for older tokens; trains added parameters with original Ouro weights frozen. Reports ~10.7× KV reduction and up to 7.4× decode throughput. It modifies attention representation and is not a drop-in exact BF16 cache placement policy.
- **ResidualQuant**, arXiv 2610.10381; https://arxiv.org/abs/2610.10381 . Low-bit cross-loop KV residual quantization. Strong competitor if ever exploring compression; excluded from exact BF16 primary method.
- **Looped Latent Attention (LLA)**, arXiv 2607.15456; https://arxiv.org/abs/2607.15456 . Learned cross-loop low-rank KV codec and reconstruction, distinct from lossless/byte-exact residency.
- **Memory-Efficient Looped Transformer (MELT)**, arXiv 2605.07721; https://arxiv.org/abs/2605.07721 . Learns a shared recurrent KV representation via post-training; not the original four-independent-KV architecture.
- **Native Ouro**: https://ouro-llm.github.io/ ; checkpoint and architecture source version pins.
- **vLLM-RLT**: https://github.com/InferMatrixLab/vllm-rlt/tree/4a350344027960a48384626aa646f1765fda6d4f ; scheduler, KV manager, attention runner, Paged KV and async graph implementations. Record *actual* discovered code locations, not assumed paths.
- **Generic CP/KV parallelism**, optimized attention and paged KV literature; survey Ring Attention, FlashAttention exact online softmax composition and existing inference-grade KV sharding (as available). Compare operator-level and E2E, not just memory-footprint diagrams. Note that generic training CP and inference decode KVP have different workloads.

### 1.2 Existing negative and positive evidence

Before coding, read the following user-project evidence, retaining exact provenance:

- `399c87bc69eaa4fbee5ee2815a9e2aeda0c95d33`: ELB decode grouping — native async/Mixed remained strongest; don't reintroduce grouped decode scheduling as the new method.
- `b3c064d7fe65753b4e5a0f20c517083d27eac00c`: dual objective C/G — C changed without improvement beyond G-only.
- `821b11653695d0a470bd88bfcc997ae1bbcf5bc9`: budget joint C/G — larger choice space produced same actual plans as tuned G-only.
- `d6ba31c7275019867e2aca473818d42d9b1fcbb0`: deadline/compute characterization — future queue-wait labels do not form a valid candidate-specific completion predictor.
- Relevant October recurrent memory/computation asymmetry and prior CP reports where accessible; extract actual job, hardware, attention share, baseline, and reason for CP slowdown. Cite the actual stored report if found; otherwise label remembered numbers as historical leads needing verification.

### 1.3 Three explicit differences from prior compression methods

- Keep **all** original KV vectors and original exact attention formula; primary intervention is *physical storage layout, page ownership, access path or distributed execution*. Exact BF16 does not mean identical outputs under altered floating-point reduction order. Verify numerical and task fidelity separately.
- Do not promise large logical KV compression. At four truly distinct full-BF16 loop caches, exact residency cannot simply eliminate three of four representations without a mathematically proven lossless encoding; allocator waste removal is distinct from information compression.
- If a loop-specific scheme wins, ablate against a generic page layout and generic exact CP using the same kernels, GPU count and scheduling to isolate recurrence-specific effects.

---

## 2. Hypotheses and proposed architecture tracks

### H0: bottleneck existence

An Ouro configuration (context, concurrency, depth and cache pressure) must show measurable **attention/KV critical-path** or **capacity-induced** cost. Quantify the exact fraction and report whether a feasible method could impact E2E by at least a preregistered practical threshold. No memory movement method is justified by KV size alone.

### Track A: exact single-GPU KV residency/layout

**A0 baseline:** Native per-layer/per-depth Paged KV with original allocation, page table and attention kernels.

**A1 candidates, only if diagnostic support exists:**

1. **Loop-depth-major page organization:** organize exact BF16 KV pages using `(request, physical layer, recurrence depth, token page)` ordering that improves page locality, TLB/metadata behavior or contiguous attention access at the measured active loop. The new organization must preserve every original KV value, valid-token ownership, causal masks and exact context range. Quantify page-table and kernel costs. RLT currently already indexes per-depth KV; merely renaming its indices is not a new layout.
2. **Exact memory planner / fragmentation reduction:** exploit loop-indexed lifetime accounting and real request sizes to reduce *allocator reservation/waste*, not the theoretical KV payload. Compare to a size-aware generic allocator with the same information and admission policy; distinguish allocator savings from temporary uncommitted pages.
3. **Ahead-of-use staging/prefetch in HBM:** only where actual memory tiering/cold-page behavior exists, exploit deterministic loop access order and event readiness to pre-stage exact KV pages without stalling the critical path. If the whole BF16 cache fits in HBM, moving it around needlessly is likely slower. Do not build a CPU-offload cache unless a transfer-budget calculation predicts plausible benefit.
4. **Device-page reuse/tier test:** optional exact GPU-to-GPU resident KV page staging under measured memory pressure. Mark all transfer costs and synchronization; do not migrate full depth caches on every output token without a proven break-even.

**Track A anti-pattern:** Offloading an entire multi-GiB per-depth cache to CPU each decode token can require more PCIe bytes/time than the original Attention computation. Estimate bytes and time first using the **measured** pinned-host bandwidth and repeat per token/layer; do not use theoretical peak as achieved throughput.

### Track B: 2/4/8-GPU exact context/KV-sharded attention

This is a **genuine multi-GPU extension**, not distributing the four recurrence model loops among GPUs.

- Partition the **token/context pages of each loop's KV cache** among 2, 4 or 8 GPU ranks. Each GPU can own context shards for *every* loop; no rank is assigned exclusive model recurrence stages.
- For each requested exact attention operator, compute local partial attention over rank-resident original BF16 K/V and merge partial results using stable logsumexp statistics `(local_max, local_sum, weighted_value)` or an equivalent exact attention reduction. Preserve causal masks, position/rope semantics, multiple heads, decode/prefill edge cases and per-loop namespace.
- Prefer transferring **small queries and softmax partial summaries** over transporting whole historical K/V, when the measured topology and operator permit. Verify whether head layout/attention kernels really support it; don't claim bandwidth savings merely because a schematic looks efficient.
- Record launch latency **per layer and recurrent step**. For R4 × 24 physical layers there may be many small distributed attention/collective calls; a nominal 4× per-GPU memory saving can lose E2E to communication latency. Assess an explicit break-even.
- Use existing production-quality collective/attention primitives or real supported libraries where possible. Do not implement a new complete serving engine for an unvalidated operator theory. An operator-only proof is still useful if E2E integration is blocked.
- Reproduce a **depth-agnostic** exact KV-sharded attention baseline on the same GPUs; only then introduce `loop-aware` placement, prefetch or page ordering, and measure the incremental benefit.
- A baseline with TP=2/4/8 must be included only where structurally legal (head divisibility, model kernels, supported runtime); otherwise report `UNSUPPORTED_TP_BASELINE` instead of inventing numbers. Also compare single-GPU RLT and independent DP replicas on aggregate throughput, clearly separating per-request model parallelism from DP.

### Track C: truly loop-aware KV movement / placement optimization

This track is conditional on Tracks A/B demonstrating either significant attention cost, bandwidth pressure or memory-capacity limits, *and* a measurable difference across loop depth.

Potential **testable** mechanisms:

1. **Depth-aware page placement:** distribute context-page shards so current and next legal loop's requests use page-local computation and avoid unnecessary cross-GPU page migration; compare against balanced generic token sharding. Never move whole loop model execution to a different GPU.
2. **Loop-order prefetch and admission:** given current complete depth and observed valid page ranges, schedule asynchronous staging or communication of the *next* depth's exact pages/summaries while running independent kernel work. Do not assume attention for loop t+1 can execute before loop t hidden-state dependency resolves. Analyze transfer-compute overlap on the actual stream graph.
3. **Depth-and-context pressure mapping:** adapt shard placement only when context and batch pressure makes the generic partition imbalanced or unable to fit. Ensure all model outputs remain valid and original BF16 KV is retained.
4. **Fair distributed cache metadata:** co-locate page tables, prevent costly per-depth remapping, and quantify KV metadata and collective launch cost; compare with a generic precomputed static page map.

A Track-C policy is not automatically new because it knows loop index. The **measured benefit must specifically depend on loop recurrence structure**, not merely a generic memory allocator or context-parallel schedule.

### Strong falsifiers

- GPU decode attention + KV critical-path share stays ~single digits at all relevant feasible contexts and batching scales.
- Exact remote attention incurs more per-step collective latency than any attention latency saved.
- KV cache already fits and page-fragmentation is negligible; no reliable extra capacity gain exists.
- A depth-agnostic CP or allocator reaches the same Pareto points.
- A purported dynamic KV placement causes enormous repeated host/GPU migration or copies non-ready KV state.

---

## 3. Mathematical accounting, memory model and performance ceilings

### 3.1 Exact KV payload formula

For a homogeneous implementation, theoretical KV payload for one sequence is:

`M_KV = 2 (K and V) × sizeof(dtype) × N_physical_layers × R × N_kv_heads × head_dim × N_context_tokens`.

Use **actual Ouro checkpoint config**, attention projection shape, GQA/MQA group count, page block size, loop KV indexing, prelude/coda KV and any special stored activations. If the runtime stores extra nonrecurrent cache namespaces, account for them explicitly. Do **not** turn the idealized expression into an assertion about RLT's physical reserved memory.

Record separately:
- theoretical payload bytes;
- initialized/committed pages and resident valid tokens per depth;
- allocator allocated and reserved bytes, KV pool cap, graph/static workspaces;
- host-pinned bytes and any CPU offload;
- HBM used/free; per-process and per-GPU totals;
- paging fragmentation, unusable blocks, admission stalls and OOM threshold.

Plot `M_KV` vs batch/context (`B=1,2,4,8,16`, `L=1K,2K,4K,8K,16K,32K`, optionally 64K/128K only with support), vs R in a **separate diagnostic**. Static R4 is the measured serving contract. Do not compare R2 reduced model compute/quality to R4 and claim a cache win.

### 3.2 Attention time and memory-bound diagnosis

Collect layer- and loop-resolved **full** timing:

`T_token = T_prelude + Σ_{r=1..4} Σ_{layer=1..24}(T_attn + T_ffn + T_norm + T_misc + waits) + T_coda + T_delivery`, with actual overlap semantics. This is a conceptual ledger; **do not add overlapping host/device events** to obtain E2E.

Measure attention read bytes, achieved HBM bandwidth (hardware metrics if available), compute throughput, SM occupancy, attention launch count, page-table overhead, L2 hit metrics, and GPU device-activity interval union. Distinguish KV **size**, KV **bytes actually read**, GPU **active service**, and actual **critical-path saved by replacement**.

The previous 7.3% attention-core fraction is a historical lead, **not** a new measurement. For a reproducible configuration where attention makes only fraction `f` of total latency, even eliminating the entire operator (an unrealistic upper bound) yields at most `1/(1-f)` speedup when that share is on the critical path. At `f=0.073`, the notional bound is ~1.079×; this is not an achievable improvement claim. For CPU offload or distributed attention, also add their own overhead.

### 3.3 Memory placement break-even

For transfer of `D` **actual bytes** over measured useful bandwidth `BW_eff`, lower-bound communication time is `D / BW_eff` before launch/event/collective overhead. Estimate from actual page migration frequency per output token. Compare against attention time that could be displaced and the available independent computation to hide it. Avoid using GPU theoretical HBM/NVLink/PCIe rates as measured rates.

For sharded attention, measure message sizes and collective counts **per loop and physical layer**; reconstruct an empirical time budget for 2/4/8 ranks. If a required collective repeats 96 times per complete token, even small per-call latency can dominate. Prefer a single-operator microbenchmark ahead of whole-server integration.

### 3.4 Three distinct success metrics

- **Memory headroom:** additional concurrently supported requests/context at the same GPU budget, exact KV and same quality.
- **Throughput/latency:** qualified full-output timing with identical model work, no hidden transfer excluded.
- **Incremental novelty:** Track-C ablation versus generic CP/page planner with same kernels and hardware.

All three should be shown; don't conflate them.

---

## 4. Phase matrix and primary gates

| Phase | Purpose | Primary outputs | Condition |
|---|---|---|---|
| P0 | Literature/source audit and baseline reconstruction | source pins, prior-work matrix, hardware topology | Mandatory |
| P1 | Single-GPU critical path + KV accounting | per-loop/layer fraction, HBM/page footprint, context scaling | Mandatory |
| P2 | Exact single-GPU residency/layout and tiering microtests | allocator/layout gains or transfer break-even | Mandatory bounded diagnostics |
| P3 | 2GPU exact KV-sharded attention operator | exact softmax merge, topology/latency/bytes | Mandatory **operator feasibility** to establish multiGPU path |
| P4 | 4/8GPU KV sharding scaling and generic CP baseline | operator and memory-capacity curve | Conditional on P3 legality; diagnostic scaling required where feasible |
| P5 | Loop-aware placement/prefetch vs depth-agnostic baselines | incremental algorithm and true causal headroom | Only after P1/P3 headroom |
| P6 | Natural serving, SLO/capacity, quality/generalization | strong baselines and 2/4/8 scaling | Only when a viable candidate exists |

**Deliver P0, P1 and bounded P2/P3 even if the first profile is negative.** Do not permit the previous failure mode of implementing a broad adaptive policy before a physical benefit is measured. A blocked supported kernel/API does not authorize inventing a new model-parallel engine or reopening paused Loop PP.

---

## 5. P0 — Source pins, 8GPU topology and prior-work controls

1. Inspect the repository's actual state, detached/staged work, existing Ouro RLT checkouts, checkpoint and run configs. Preserve all existing changes. Create a separate feature branch and immutable report folder.
2. Lock exact checkpoint/tokenizer SHA, model config, batch/precision, RLT source pin, PyTorch/CUDA/FA4/Triton, graph/async flags and request stopping semantics.
3. Map physical GPU IDs 0–7 to UUID, GPU-GPU peer paths (`nvidia-smi topo -m`, `nvidia-smi nvlink -s` if supported), host NUMA, PCIe/NVLink fabrics, transport/peer access and observed point-to-point/all-reduce bandwidth/latency. Do **not** assume full uniform NVLink mesh.
4. Ownership: inspect current processes; stop only verified experiment-owned burners when authorized. Never interfere with other user jobs, despite physical IDs being authorized.
5. Pretest one, two, four and eight independent Ouro instances running *non-distributed* workloads; quantify shared-host CPU/IO/memory/power/clock contention. Use a quiet lane if parallelism degrades timing by a registered meaningful threshold (e.g. >3%). GPU concurrency is for productivity, not license to corrupt comparisons.
6. Reproduce **unmodified optimized** native RLT Async + CUDA Graph + Mixed baseline, at representative B1/B4 and 2K/8K. Do not regress to deliberately slow Sync/G1 to make the proposed method look better.
7. Research novelty table: FlashLoop, HLA, ResidualQuant, LLA, MELT, generic CP/KVP, Paged KV, native Mixed; list exactness, training, precision, parallelism, measured apples-to-apples comparisons, and code availability.
8. Freeze at least source-family-disjoint TRAIN/VALIDATION/FINAL workload manifest, length caps, SLO definitions, hardware policies and metrics before final tests.

**P0 deliverables:** `environment_lock.md`, `topology.md`, `source_audit.md`, `related_work.md`, `baseline_reproduction.md`, `contention_calibration.csv`, `run_manifest.jsonl`.

---

## 6. P1 — Single-GPU long-context KV and attention physical bottlenecks

### 6.1 Grid and progression

- First pass: `L={1K,2K,4K,8K,16K,32K}` with `B={1,2,4,8}` subject to real capacity; add 64K only if model supports it and no pathological OOM/position mismatch occurs.
- Stable decode: completed output tokens 64/128 after warm-up, EOS handling explicit. Natural requests: 64–512 cap, default natural stopping; do not silently force all responses to identical length in a natural lane.
- Confound controls: same full R4, same prompt, fixed KV state and same provider backend; native Mixed control separately. Short-prefill vs long-prefill use true natural text, not a padded context of repeated tokens unless labeled diagnostic.
- Add B16 only where capacity allows; don't extrapolate hypothetical cells as observed.
- Use two to three independent GPU/process blocks for discovery and at least three starts for nominated crossover cells. Rotate baselines across physical GPUs.

### 6.2 Required evidence

- Model-layer/loop per-step attention vs FFN vs norm/GEMM vs graph/event/host fractions; full token duration; all 96 KV namespaces and page mapping.
- Physical `HBM allocated`, `HBM reserved`, `KV payload`, `KV initialized`, `unusable reserve`, graph workspace and non-KV weights. Plot versus B/L/R4.
- Empirical read bytes and achieved bandwidth for KV access, GPU L2 caches where measured, memory stalls.
- First failure point: first OOM, first admission rejection, first large TTFT/TPOT tail; classify memory capacity vs bandwidth vs compute vs shared CPU bottleneck.
- Look for **loop-dependent** differences at identical length: KV page count, attention compute efficiency, graph capture, kernel variants, page-table overhead and cache re-use (do not assume different loops have different utilization).
- Compare earlier ~7.3% attention-core lead under the old matching configuration when possible, with provenance and distinct run labels.

### 6.3 Mandatory headroom table

For each candidate P/N, report:

`T_full_token`, `T_attention_on_critical_path`, `f_attention`, `KV_bytes`, `M_required`, `M_allocated`, `M_reserved`, `HBM_peak`, `B_max_complete`, `estimated_operator_only_upper_bound`, `confidence`, `next action`.

If `f_attention` stays small but memory capacity saturates, P2/P3 can still pursue **capacity scaling** with explicit separate objectives. If neither capacity nor latency headroom exists, report `NO_GO_HEADROOM_SINGLE_GPU` and limit implementation to P3 operator feasibility.

**Do not conclude GPU KV is memory-bandwidth bound solely from cache size.**

---

## 7. P2 — Exact single-GPU memory layout/placement and bandwidth diagnostics

### 7.1 Baselines and microkernels

- A0 native RLT Paged KV and attention.
- A1 exact depth-major page layout and physical allocator, only if source audit shows a material difference from current layout. Expose page-table lookup/index and actual hardware locality; don't claim a new algorithm from an identical pointer permutation.
- A2 exact size-aware allocation or fragmentation reduction control, equal valid KV payload. Distinguish reserved pool from logically active KV; reductions in unused reserve cannot automatically be used to increase model-supported context.
- A3 exact CPU/HBM or peer-HBM staging, only after measured transfer break-even. Use 1K/2K/8K/16K true page ranges, force pinned memory where supported, verify state after round trip and event order.
- A4 optional loop-next-depth KV prefetch when valid future-needed KV pages are already produced and exist in slower tier. There is no prefetch of uncomputed hidden/KV; R1 must complete before R2 consumer can use new dependencies.

### 7.2 Tests

Run operator workloads with B1/2/4/8 and L2K/8K/16K/32K (where available). Profile separately CPU, H2D/GPU peer, memcopy bytes, page handling, CUDA event wait, actual attention kernel and full-output latency. Use binary page fingerprints and numeric BF16 exactness tests; after moving KV memory, compare valid K/V element values bytewise before attention, then compare attention outputs and decoded token sequences. Different reduction orders may change BF16; document numerical margin and precision diagnostics **without** serving in altered precision.

### 7.3 Early negative result policy

If transferring whole depth caches exceeds saved GPU time, **close that placement path**; do not proceed with aggressive swapping. If HBM layout saves only fragmented reservation but no admitted requests or latency, classify `METADATA_ONLY`. If a 2GPU exact remote attention path needs active rank communication per layer that overshadows local attention, record a hard `COMM_DOMINATED` boundary for that regime.

---

## 8. P3 — Exact two-GPU KV-sharded attention operator

### 8.1 Functional contract

Use two H100 devices chosen after topology audit (do not assume physical 0/1 have best link). One logical model request keeps all original BF16 K/V values, **sharded by context pages** across the two ranks for each recurrent loop and physical layer. Do not assign Loop1 computation to GPU0 and Loop2 to GPU1 — that would restart suspended Loop PP under another name.

For attention to a query `q`, each rank j produces statistics over its own causal KV page subset:

`m_j = max(q · k / sqrt(d))`,  
`l_j = Σ exp(score - m_j)`,  
`o_j = Σ exp(score - m_j) * v`.

Merge with common max `m=max(m_j)`, then `l=Σ exp(m_j-m)*l_j`, `o=(Σ exp(m_j-m)*o_j)/l`. Handle empty shards and causal masks without NaN. This is a **numerically stable exact attention formulation in real arithmetic**; floating-point order can change BF16 outputs and requires tolerance/token-quality analysis. Implement with verified backend primitives rather than naïve Python loops where feasible.

Re-use per-loop recurrence-depth KV metadata, topology-aware page ownership, and legal request ordering. Avoid moving full K/V at each layer if the message-passing partial attention path is viable. Explicitly log query bytes, partial-output bytes, NCCL/P2P collective counts, launch costs and actual GPU service.

### 8.2 Controlled operator matrix

- N_requests `{1,2,4,8}`, context `{2K,8K,16K,32K,64K}` as valid.
- R4 recurrent logical depth `{0,1,2,3}`, physical layers sample `{first,middle,last}` initially, then complete 24 layers for promoted candidates.
- GPUs `{2}`, KV sharding ratios balanced 50:50 plus skew sensitivity `{75:25}`; static per-depth full payload and exact page ownership.
- Compare local baseline (if fits), generic standard exact CP/KVP, depth-agnostic sharding using same kernels, and same distributed operator with loop-depth-aware metadata/layout.
- Run at least three independent process restarts per shortlisted configuration; warm and cold graphs separate. Include P2P/NCCL latency microbenchmark and no-model communication floor.
- Measure reduction of peak KV per GPU and **end-to-end attention operator** duration; no MLLM/other model data. Build provenance for every inserted kernel.

### 8.3 Correctness and unblock criteria

- Every valid page used exactly once in its rank's logical attention reduction. No lost, duplicate or stale page.
- Compare layer attention output to native single-device BF16 reference at known exact q/K/V and path-specific tolerances; check max absolute, relative L2 and max logit drift.
- Verify true 96 namespace KV indexing, valid prefix lengths, batching, EOS, long context and zero/partial page edge cases.
- Keep model output weights/sampling unchanged, and report token-exact parity on short full R4 sequences if whole model integration exists.
- Any numerical issue is categorized rather than hidden by rounding or using CPU FP32 serving; FP32 may only be a diagnostic reference.

`P3_PASS_OPERATOR` means the exact-sharded operator works and matches reference within the registered numeric contract, not that distributed serving is faster. A negative latency result can still qualify capacity-only exploration.

---

## 9. P4 — Four/eight GPU scaling; generic vs loop-aware contrast

### 9.1 Operator and memory benchmark

For supported groups `{2,4,8}` using the best measured interconnect subsets, compare exact KV sharded attention as in P3 and generic depth-agnostic CP. Do not silently change the number of requests, model depth, prompt length, precision, page size or communication backend between arms.

For each group size report:
- live KV bytes per rank and cluster total, reserved vs payload;
- supported maximum actual context/sequences before OOM or capacity rejection;
- attention operator P50/P95/P99; full recurrent-loop partial model only if actual implementation runs it;
- communication aggregate bytes per complete output token (measured), collectives per layer/loop/token, device and CPU critical path, link utilization;
- scalability vs 1GPU when 1GPU fits; otherwise feasibility and fair same-context comparison only across `2/4/8`, not a fabricated 1GPU speedup;
- matched native TP2/TP4/TP8 where legally supported, with head replication disclosed;
- DP2/4/8 separate request replicas as throughput/scale-out baseline, not per-request memory extension.

### 9.2 Attention reduction topology controls

Try native all-gather/ring or tree reductions **only where supported**, with error-controlled numeric softmax merge. Any reduction-order discrepancy is documented. Investigate how collective count is multiplied by 24 physical layers ×4 loops; combine/capture collectives only if engineering cost is defensible after microbenchmark.

### 9.3 Mandatory advisor-aligned multiGPU outcome

Deliver at least a **measured two-GPU exact KV sharding operator** and a reproducible **2/4/8-GPU microbenchmark feasibility plan**; execute 4/8 where legal and available without changing the model semantics. If whole-model integration would require major engine changes, mark it `NOT_RUN_FULL_SERVING` and preserve operator scaling evidence. Do not mislabel operator scaling as E2E Serving. A research direction is eligible for continuation only if a plausible supported path to 2/4/8 devices exists with logged costs and real page ownership — not just a diagram.

---

## 10. P5 — Loop-aware placement/prefetch: only after real headroom

Build no adaptive controller unless A/B establishes **two or more states in which loop-aware placement and depth-agnostic placement yield materially different physical behavior** under identical exact KV requirements.

### 10.1 Potential candidates

- **Loop-depth-aware page-to-rank mapping**: incorporate current ready depth, context-page locality and observed KV ownership in assignment. Do not place full loop model compute exclusively on that rank.
- **Page-request batching / metadata reuse:** amortize per-depth distributed attention page-table work or collective launch metadata. Compare against generic reuse with no recurrence-index signal.
- **Legal next-depth prefetch**: pre-stage pages for the immediately next recurrent depth as soon as they are physically produced, in parallel with measured independent computation; uncomputed pages may not be prefetched.
- **Loop-aware skew correction:** if context-page shard load differs across depths/requests, rebalance exact page residence while charging migration and coherence costs. A static balanced generic sharding baseline gets the same hardware and overhead accounting.

The optimizers are not allowed to use actual future token IDs, KV values not yet computed, future arrival rates, eventual GPU timing labels, or an oracle. Selection must use current queues, valid page maps, generated depth, actual GPU-event readiness, measured historical costs and current topology.

### 10.2 One-action evidence gate

On matched recorded initial q/KV and request/depth states, force a legal alternative mapping/prefetch versus generic mapping with identical model work; observe physical operator latency and data bytes on the real GPU. Only if favorable and reproducible should an online choice be added.

**Promotion gates (prospective screens, not proof by themselves):**
- nonzero legal loop-aware action opportunities (not merely different score outputs);
- measured >5% attention-operator latency or >10% usable capacity improvement with supported confidence, or an explicit new capacity threshold unavailable to generic CP;
- no stronger generic allocator/CP policy matching the same effect;
- expected end-to-end critical path headroom not erased by 96× launch/collective multiplication.

If no crossover survives stronger controls, classify `NO_GO_INCREMENTAL` and stop P5/P6 method implementation. Keep all negative evidence and proper capacity-only plots.

---

## 11. P6 — Online serving, SLO and model quality

### 11.1 Comparing actual serving methods

If a qualified P5 candidate exists, integrate into the pinned RLT **without modifying the original 24-layer BF16 weights or model math**, and compare:

1. Optimized single-GPU native Async/Mixed at all fit conditions.
2. Single-GPU exact memory layout allocator control (Track A).
3. Generic 2/4/8-GPU exact CP/KVP using identical attention backend.
4. Loop-aware 2/4/8-GPU exact KV placement/attention (same group, caps, model configuration).
5. Supported native TP2/4/8; label unsupported rather than inventing an arm.
6. Independent DP2/4/8 replicas (aggregate throughput baseline, not per-request memory extension).
7. CPU/host KV tiering only where actually implemented and feasible, with byte-for-byte transfer accounting.

Never claim a 4-GPU memory capacity win over a 1-GPU model that cannot fit the **same** inputs as a latency speedup. For each comparable group, report memory, tokens/s, requests/s, TTFT, TPOT, all-request E2E, loop-level attention, actual communication and energy if measured.

### 11.2 Serving workload

- Low request emphasis: N1,2,4,8, additionally N16 for memory pressure.
- Context: 2K/8K/16K/32K, as supported; 64K+ only with verified positional/model correctness.
- Natural held-out sources: short chat, 2K/8K long articles, long retrieval/long math where legal; true natural EOS and stop handling, not forced matching output counts.
- Poisson and burst arrivals with matched seeds, evaluate several rates around each policy's empirically measured saturation.
- Allow multi-GPU groups with separate node topology; disable concurrent unrelated measurement workers or calibrate contention. Keep the 1/2/4/8 worker productivity lane separate from quiet headline runs.

### 11.3 Core metrics and SLOs

- **Payload/residency:** original logical BF16 KV bytes, allocated/committed/reserved HBM, per-rank and total, admitted contexts/sequence concurrency, fragmentation, CPU pinned storage, OOM count.
- **Latency/serving:** TTFT, ITL/TBT P50/P95/P99 over observed gaps, request-max ITL distribution, TPOT, E2E P50/P95/P99, output tokens/s, complete responses/s, queue backlog and exact natural response counts.
- **Request-level SLO:** TTFT<=2/5/10 s crossed with all-TBT<=75/100/125/150/200/250/500 ms, plus preregistered calibrated tiers based on decode-only native reference. Actual natural completion required. At least 1,000 offered requests per main arm/rate with three process starts for qualified sustainable capacity. Lower Ns remain exploratory.
- **Context ability:** largest *actual* prompt admitted with full KV semantics and verified output, not theoretical bytes extrapolated.
- **Speedup:** quality-matched and equal-work controls separated from natural-serving operational gains; open-loop goodput is not fixed-cohort drained token throughput.

### 11.4 Quality and correctness

At a minimum, a GSM8K 64 and MATH-500 50 matched pilot per candidate/control, with natural generation and correct/total, completed-correct/total, caps, parse errors, paired token-exact outputs and per-source uncertainty. If positive results persist, expand to full GSM8K and MATH-500 and long-context retrieval. Do not claim population equivalence from a 114-question pilot.

KV semantics: full R4, 96 namespaces, valid causal prefixes, exact BF16 values **before** any floating-point partial-attention reduction; verify dtype/offset/strides, producer events and sample output vs source. No precision degradation or silent change in EOS/gating logic. Reduced model R and compressed representations are forbidden as primary methods.

---

## 12. Experiment operations: eight GPUs, reproducibility and safe ownership

- Use independent workers on physical GPU IDs 0–7 for non-distributed P1/P2. For P3/P4 and promoted P6, create explicit 2-,4-,8-GPU distributed groups. Do not accidentally run eight independent workers and label it 8GPU sharded attention.
- Record `nvidia-smi -L`, P2P/NVLink topology, per-process UUID, `CUDA_VISIBLE_DEVICES` and process-local `cuda:0` mapping. Verify every logical distributed rank maps to a distinct requested physical GPU.
- Build an immutable `experiment_matrix.csv` and restartable dispatcher with one active owner per GPU, job locks, source SHA, attempt IDs, failure classes and run hashes. On completion, copy only report/patch files into a separate feature branch. Preserve all existing staged files and prior PoC reports.
- Rotate comparison arms over physical GPUs. Paired comparisons should share GPU/model start when feasible; for distributed runs hold the same GPU group/topology and rotate order.
- Warm graphs equally, but report valid cold-shape captures that happen during live serving. Profile Nsight/perf counters in separate heavy lanes; don't mix traced timing with clean throughput.
- Check ownership of GPU burners and unrelated processes. Stop only experiment-owned workloads authorized for this study. Never kill foreign jobs or global daemon processes.
- If A/B is NO-GO, keep the full completed diagnostics and avoid forced lengthy capacity sweeps. Only the server-side agent actually performing the work can run GPU jobs; this spec does not promise a timed/background response.
- Commit and push on separate feature branch following repository-approved instructions, validate remote SHA. Do not silently overwrite a previous user-staged patch or old report.

---

## 13. Required figures and reports

### Figures

A. `KV_footprint_vs_context_batch`: logical BF16, committed, allocated, reserved, non-KV HBM and max admitted.

B. `decode_critical_path_vs_context`: attention vs FFN vs rest, per depth and full output token, error bars.

C. `attn_roofline_and_shard_cost`: achieved HBM/NVLink/P2P, small-query attention size, per-layer collective overhead.

D. `single_gpu_layout_and_tiering`: baseline vs exact layout vs allocator vs transfer, TTFT/TPOT and bytes moved.

E. `2_4_8gpu_KV_scaling`: per-rank capacity, request/context ceiling, attention latency, bytes and collective counts.

F. `loop_aware_vs_generic`: same backend, same ranks and KV payload, measured incremental benefit per recurrence depth/context.

G. `memory_capacity_vs_serving_latency_pareto`: separate capacity-only and latency-benefit regimes.

H. `SLO_attainment_vs_arrival_rate`: 90% reference only when qualified by adequate offered count and queue stability.

I. `numerical_accuracy`: BF16 KV exactness before reduction, attention max errors, generated token parity and GSM8K/MATH if executed.

### Required report tree

`poc_flashvep/reports/ouro_loop_aware_kv_residency_distributed_attention_discovery/`

- `analysis.md` — executive conclusion, actual work done, accurate independent verdicts.
- `baseline_audit.md` / `related_work.md` — FlashLoop/HLA/LLA/ResidualQuant/MELT/CP/NVLink overlap and quantitative comparison.
- `environment_lock.md` / `topology.md` — model/kernel/RLT provenance, GPU UUID/NUMA/p2p topology.
- `kv_memory_accounting.md` / `single_gpu_critical_path.md` — exact memory and runtime audit.
- `single_gpu_layout.md` / `tiering_break_even.md` — exact residency vs CPU/GPU memory movement.
- `distributed_attention_correctness.md` / `distributed_scaling.md` — 2/4/8 operator status, BF16 reference, collective counts, page ownership.
- `loop_aware_method.md` — actual new method if implemented, otherwise explicit `NOT_RUN`.
- `serving_summary.md` / `slo_capacity.md` — natural and sustainable rates if reached; no invented data.
- `correctness.md` / `quality.md` — native model invariants, matched outputs and full answer scores.
- `experiment_matrix.csv`, `results_raw.csv`, `memory_events.csv.gz`, `kernel_timing.csv.gz`, `attention_operator_pairs.csv`, `shard_communication.csv`, `capacity_by_gpu_count.csv`, `paired_comparisons.csv`, `phase_gates.md`, `failures.md`, `next_actions.md`, `reproduce.md`, `artifact_hash_manifest.json`, `figures/`, hashed raw artifacts and source snapshots.

Every plot and claim must distinguish `LIVE_MEASURED_OPERATOR`, `LIVE_MEASURED_SERVING`, `MODEL_UPPER_BOUND`, `SIMULATED`, and `NOT_RUN`. Include exact hardware, seeds, same-work status, independent process starts, confidence intervals and correct denominators.

---

## 14. Prespecified independent decision gates

| Gate | Result categories | What counts |
|---|---|---|
| G0 Provenance | PASS / BLOCKED | Source, model, physical GPUs and strong native RLT controls fully pinned |
| G1 Bottleneck | LATENCY_HEADROOM / CAPACITY_ONLY / NO_GO_HEADROOM | Actual attention critical-path or usable memory-capacity limitations, not just theoretical bytes |
| G2 Single-GPU exact layout | PASS_INCREMENTAL / METADATA_ONLY / NO_GO / NOT_RUN | Measured allocator/attention/latency benefit beyond optimized generic page plan |
| G3 2GPU exact distributed operator | PASS_OPERATOR / COMM_DOMINATED / BLOCKED_NUMERICS / BLOCKED_RUNTIME | Correct local shard attention + distributed reduction and measured links |
| G4 4/8 scaling | CAPACITY_SCALES / E2E_SCALES / COMM_DOMINATED / NOT_RUN | Actual per-rank KV and operator, no guessed 8GPU throughput |
| G5 Loop-specific increment | GO_CANDIDATE / STRUCTURAL_ONLY / NO_GO_INCREMENTAL / NOT_RUN | Added loop-depth signal beats identical generic CP/allocator implementation |
| G6 Serving + quality | GO / CONDITIONAL_CAPACITY / CONDITIONAL_QUALITY / NO_GO / NOT_RUN | Qualified natural service, accuracy, SLO capacity and strong baselines |

Prospective practical screen: do not commit to a research method unless one of (a) measurable >=5% full-token or request-level serving gain over strong matched baseline with process-level uncertainty, (b) a measurable new exact-context/concurrency **capacity** tier unavailable on singleGPU and clearly nontrivial relative to generic 2/4/8 CP, (c) a carefully measured novel loop-specific operator benefit which plausibly survives communication costs. **A capacity-only improvement is not automatically a paper-grade novelty claim.** Preserve any negative findings and numerical limitations.

### Immediate final questions

1. Under what B/L can Ouro's exact KV footprint no longer be accommodated by one H100, and is the dominant limitation actual valid KV bytes or allocator/workspace reservation?
2. What fraction of measured full-token wall time is exact KV attention on 1 GPU at 2K,8K,16K,32K contexts?
3. At what context length does 2/4/8 GPU exact KV-sharded attention break even on *operator cost* and on true full-output-token E2E latency, if ever?
4. Does loop depth create a **measured placement/prefetch opportunity** absent in generic CP? Which causal state pair proves it?
5. Does a loop-aware KV planner improve on a depth-agnostic equal-cost planner and native RLT Async/Mixed under matched quality and work?
6. If a new supported context is the only gain, how does 2/4/8 rank scaling compare to generic KV sharding with equal memory budget?
7. Are FlashLoop/HLA/ResidualQuant/LLA/MELT solving the same user problem by altering representation while we preserve exact BF16, and is the remaining contribution independently publishable?
8. Are TP/DP/multiGPU comparisons actually run and interpreted honestly, rather than relying on singleGPU data and a distributed system diagram?

**End condition:** Either provide an experimentally justified loop-aware exact KV method and measured 2/4/8GPU extension, or a defensible no-go identifying precisely which physical costs (attention share, capacity, bytes, collectives, launch overhead) prevented the method. Do not resume native-vLLM Loop PP under a new name.
