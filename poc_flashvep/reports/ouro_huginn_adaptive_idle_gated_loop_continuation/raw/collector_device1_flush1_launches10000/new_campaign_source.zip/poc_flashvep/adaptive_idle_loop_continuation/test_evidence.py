import unittest
from .analyze import latency
from ..native_loop_2d_oracle.dependency import Frontier


class EvidenceTests(unittest.TestCase):
    def test_empty_delivery_population_is_not_zero_latency(self):
        result=latency([],0,0,8)
        self.assertIsNone(result['ITL_p99_ms'])
        self.assertIsNone(result['max_ITL_ms'])
        self.assertEqual(result['ITL_samples'],0)

    def test_window_selects_overlapping_intervals_without_creating_tokens(self):
        row=dict(first_token=1.,finish=3.,tpot_ms=1000.,token_events=[
            dict(first=True,new_tokens=1,previous_time=1.,time=1.),
            dict(first=False,new_tokens=1,previous_time=1.,time=2.),
            dict(first=False,new_tokens=2,previous_time=2.,time=3.)])
        value=latency([row],0,1.5,2.5)
        self.assertEqual(value['ITL_samples'],1)
        self.assertEqual(value['ITL_p99_ms'],1000.)

    def test_one_way_suffix_structural_accounting_does_not_skip_work(self):
        for model,t,r in (('ouro',4096,4),('huginn',2048,32)):
            for c in range(r+1):
                frontier=Frontier(t,r,c,0)
                accounting=frontier.accounting(model)
                self.assertIsInstance(accounting,dict)
                # The constructor validates a legal monotone frontier.
                self.assertEqual(accounting['D_recurrent_token_rows'],(r-c)*t)
                self.assertTrue(accounting['DAG_closed_P_partition'])


if __name__=='__main__':unittest.main()
