"""Reuse scoped alternate-index publication for this campaign only."""
import argparse
from .common import *

FINAL=REPO/'poc_flashvep/reports/ouro_huginn_adaptive_idle_gated_loop_continuation_final_summary.md'
SPEC=FINAL.with_name('ouro_huginn_adaptive_idle_gated_loop_continuation_poc_spec.md')


def main(action,push=False):
    initialize()
    from ..d_local_cross_depth_batching import publish as inherited
    for key in ('ROOT','SOURCE','BASE','BRANCH','FINAL','SPEC','initialize'):
        setattr(inherited,key,globals()[key])
    inherited.main(action,push)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('archive','publish'))
    parser.add_argument('--push',action='store_true');args=parser.parse_args();main(args.action,args.push)
