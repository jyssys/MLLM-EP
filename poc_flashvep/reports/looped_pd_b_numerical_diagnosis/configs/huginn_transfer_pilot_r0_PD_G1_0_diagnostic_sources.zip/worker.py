"""Reuse the frozen PD harness in a new output namespace, including spawn."""
import os
import sys
from .common import redirect
from .patches import install

if os.environ.get('B_NUMERICAL_RUN'):
    redirect()
    install()
    from .transfer_probe import install as transfer_install
    transfer_install()


def main():
    module=redirect()
    install()
    module.main()


if __name__=='__main__': main()
