"""Reuse the frozen PD harness in a new output namespace, including spawn."""
import os
import sys
from .common import redirect
from .patches import install

if os.environ.get('B_NUMERICAL_RUN'):
    redirect()
    install()
    from .transfer_probe import install as transfer_install
    transfer_install()


def main():
    module=redirect()
    install()
    if os.environ.get('B_NUMERICAL_NVTX')=='1':
        import torch
        original=module.serve
        def serve(*args,**kwargs):
            active=not kwargs.get('warmup',False)
            if active:torch.cuda.nvtx.range_push('diagnostic_measured')
            try:return original(*args,**kwargs)
            finally:
                if active:torch.cuda.nvtx.range_pop()
        module.serve=serve
    module.main()


if __name__=='__main__': main()
