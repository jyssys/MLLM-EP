import unittest
from .hidden_transport import Slots


class SlotTests(unittest.TestCase):
    def test_no_overwrite_before_ACK(self):
        s=Slots(1);i=s.take('a')
        with self.assertRaises(RuntimeError):s.take('b')
        with self.assertRaises(AssertionError):s.release(i,'b')
        s.release(i,'a');self.assertEqual(s.take('b'),i)

    def test_stale_ACK_is_rejected(self):
        s=Slots(2);i=s.take('a');s.release(i,'a');s.take('b')
        with self.assertRaises(AssertionError):s.release(i,'a')


if __name__=='__main__':unittest.main()
