"""Reuse Native local calibration without representing it as online PD."""
import argparse,json,os,time
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('config');a=p.parse_args()
    cfg=json.loads(Path(a.config).read_text());os.environ['ARC_CONFIG']=a.config
    os.environ['VLLM_BATCH_INVARIANT']='1'
    from ..looped_pd_atomic_prefill import ar_worker,ar_capacity
    ar_worker.MODEL_PATHS=dict(qwen8=MODEL);ar_worker.ROOT=ROOT
    ar_capacity.ROOT=ROOT
    if cfg.get('runtime_observation') or cfg.get('layer_mode'):
        from .extension import install
        install(cfg,'capacity')
    try:
        ar_capacity.main()
    finally:
        folder=ROOT/'raw'/cfg['name'];state=folder/'status.json'
        passed=state.exists() and json.loads(state.read_text()).get('status')=='COMPLETE'
        write(folder/'worker_exits.json',dict(time=time.time(),passed=passed,
            scope='Local calibration returned after Native engine shutdown. Not two-worker transport qualification.'))


if __name__=='__main__':main()
