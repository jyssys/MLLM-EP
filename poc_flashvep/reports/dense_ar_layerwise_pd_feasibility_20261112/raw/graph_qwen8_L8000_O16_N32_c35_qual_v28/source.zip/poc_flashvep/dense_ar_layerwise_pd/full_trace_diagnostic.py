"""Capture an actual migrated request timeline, with explicit observer limits."""
import json
from .common import *
from .prepare import save
from .run import execute
from .analyze import compare,metrics
from .physical_analysis import activity
from .resume_campaign import restore,record


def main():
    template='eager_qwen8_L8000_O16_N32_c28_event_diagnostic_v23'
    c=json.loads((ROOT/'configs'/(template+'.json')).read_text())
    c.update(name='eager_qwen8_L8000_O16_N32_c28_full_kernel_diagnostic_v27',
        physical_activity=True,activity_roles=['prefill','decode'],activity_host_pool_bytes=1024**3,
        activity_quiet_destination=False,activity_memcpy=True,hidden_source_backpressure=True,
        phase='ACTUAL_MIGRATION_KERNEL_TIMELINE_DIAGNOSTIC',clean_timing=False,
        scope='Full source and destination CUDA activity, events, and Host observations. This diagnostic never supplies clean online speedup. The matched Event-only control and a strict interference screen remain separate.')
    name=save(c)
    try:
        if not execute(name,restore=False):return
        window=json.loads((ROOT/'raw'/name/'window.json').read_text())
        acts=[activity(name,role,window['start'],window['end']) for role in ('prefill','decode')]
        a=metrics(template);b=metrics(name)
        keys=('completed_QPS','TTFT_p95_ms','TPOT_p95_ms','ITL_p99_ms','maximum_ITL_ms')
        ratios={k:b[k]/a[k] for k in keys};within=all(abs(v-1)<=.05 for v in ratios.values())
        result=dict(name=name,control=template,metrics=b,output_gate=compare(template,name),
            actual_kernel_activity=acts,observer_ratios=ratios,single_control_interference_screen_pass=within,
            clean_capacity_qualified=False,evidence='DIAGNOSTIC_ACTUAL_CUDA_ACTIVITY',
            scope='One instrumented/control comparison is not an A/A/A qualification. Full kernel intervals can document the perturbed execution only. Kernel inactivity is not a safe execution budget.')
        write(ROOT/'analysis/migrated_kernel_timeline_diagnostic.json',result)
        record('full_kernel_diagnostic',dict(name=name,trace_integrity_pass=all(r['trace_integrity_pass'] for r in acts),
            observer_ratios=ratios,clean_capacity_qualified=False))
    finally:restore()


if __name__=='__main__':main()
