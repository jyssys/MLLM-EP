"""Reuse the qualified vLLM/NIXL stage with an isolated Dense AR coordinator."""
import argparse,collections,json,os,socket,subprocess,tempfile,time
from multiprocessing.connection import Client,Listener
from .common import *


def append(path,value):
    with Path(path).open('a') as f:f.write(json.dumps(value,ensure_ascii=False)+'\n')


def environment(gpus):
    root=os.environ.get('DENSE_FROZEN_ROOT',str(REPO))
    return dict(os.environ,CUDA_VISIBLE_DEVICES=','.join(map(str,gpus)),PYTHONPATH=root,
        PATH=str(PYTHON.parent)+os.pathsep+os.environ.get('PATH',''),
        PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false',
        VLLM_ENABLE_V1_MULTIPROCESSING='0',VLLM_BATCH_INVARIANT='1',
        HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1')


def stage(cfg,role,address):
    from ..looped_pd_atomic_prefill import ar_worker as qualified
    qualified.ROOT=ROOT;qualified.MODEL_PATHS=dict(qwen8=MODEL)
    qualified.stage(cfg,role,address)


def coordinator(cfg):
    from ..looped_pd_abc.nvml_watch import GPUWatch
    folder=ROOT/'raw'/cfg['name'];folder.mkdir(exist_ok=True)
    write(folder/'status.json',dict(status='RUNNING',pid=os.getpid(),time=time.time()))
    monitor=GPUWatch(folder,cfg['gpus'],cfg['name']);monitor.start()
    roles=('replica0','replica1') if cfg['arm']=='DP2' else ('prefill','decode')
    channels={};children=[];handles=[];directory=Path(tempfile.mkdtemp(prefix='dense_layer_pd_'))
    try:
        for role,gpu in zip(roles,cfg['gpus']):
            address=str(directory/role);listener=Listener(address,family='AF_UNIX')
            env=environment([gpu])
            with socket.socket() as probe:probe.bind(('127.0.0.1',0));env['APD_SIDE_PORT']=str(probe.getsockname()[1])
            handle=(folder/f'{role}.log').open('w');handles.append(handle)
            command=[str(PYTHON),'-m','poc_flashvep.dense_ar_layerwise_pd.native',os.environ['DENSE_CONFIG'],
                '--role',role,'--address',address]
            child=subprocess.Popen(command,cwd=os.environ.get('DENSE_FROZEN_ROOT',str(REPO)),env=env,
                stdout=handle,stderr=subprocess.STDOUT);children.append(child)
            listener._listener._socket.settimeout(cfg.get('startup_timeout',360))
            channel=listener.accept();listener.close();channels[role]=channel
            assert channel.poll(cfg.get('startup_timeout',360)),'Native startup timeout'
            ready=channel.recv();assert ready['kind']=='ready'
            from ..looped_pd_abc.common import UUIDS
            assert ready['uuid'].removeprefix('GPU-')==UUIDS[gpu].removeprefix('GPU-')
            assert ready['effective_VLLM_BATCH_INVARIANT'] is True
            write(folder/f'{role}_ready.json',ready)
        data=json.loads((ROOT/'data'/cfg['dataset']).read_text())[:cfg['count']]
        assert len(data)==cfg['count'] and all(len(r['input_ids']['qwen8'])+cap<=40960 for r,cap in zip(data,cfg['request_caps']))
        def add(role,rid,row,cap,seed,kv=None):
            channels[role].send(dict(kind='add',request_id=rid,input_ids=row['input_ids']['qwen8'],cap=cap,seed=seed,kv_params=kv))
        for i,row in enumerate(data[:cfg.get('warmup_count',2)]):
            rid=f'warm_{i}';seed=cfg['seed']-10000+i;done=False;deadline=time.monotonic()+180
            add(roles[i%2] if cfg['arm']=='DP2' else 'prefill',rid,row,2,seed)
            while not done:
                for role,channel in channels.items():
                    while channel.poll():
                        message=channel.recv()
                        if message['kind']=='accepted' or not message['finished']:continue
                        if role=='prefill':
                            assert message['kv_params'] and message['kv_params'].get('remote_block_ids')
                            add('decode',rid,row,2,seed,message['kv_params'])
                        else:assert message['count']==2;done=True
                assert time.monotonic()<deadline,'Native warm-up timeout'
                assert all(c.poll() is None for c in children),'Native warm-up child failed'
                time.sleep(.0002)
        for channel in channels.values():channel.send(dict(kind='measurement_begin'))
        for channel in channels.values():
            assert channel.poll(30) and channel.recv()['kind']=='measurement_ready'
        first={};events={};completed={};arrivals={};states={};admissions={};i=0
        serial=cfg.get('calibration_serial',False);start=time.monotonic();observation=start
        write(folder/'measurement_begin.json',dict(time=start))
        while i<len(data) or len(completed)<len(data):
            now=time.monotonic()
            while i<len(data) and now>=start+cfg['arrival_offsets'][i]:
                if serial and i>len(completed):break
                rid=f'q{i}';arrival=now if serial else start+cfg['arrival_offsets'][i]
                arrivals[rid]=arrival;states[rid]='prefill' if cfg['arm']!='DP2' else roles[i%2]
                send_start=time.monotonic();add(states[rid],rid,data[i],cfg['request_caps'][i],cfg['seed']+i)
                append(folder/'offered_requests.jsonl',dict(sample_id=i,prompt_id=data[i]['prompt_id'],arrival=arrival,
                    actual_send_start=send_start,actual_send_end=time.monotonic(),cap=cfg['request_caps'][i],seed=cfg['seed']+i));i+=1
            for role,channel in channels.items():
                while channel.poll():
                    message=channel.recv();rid=message['request_id'];index=int(rid[1:])
                    if message['kind']=='accepted':admissions.setdefault(rid,message['time']);continue
                    if role=='prefill':
                        if not message['finished']:continue
                        kv=message['kv_params'];assert kv and kv.get('remote_block_ids')
                        append(folder/'native_handoffs.jsonl',dict(request_id=rid,time=message['time'],params=kv))
                        states[rid]='decode';add('decode',rid,data[index],cfg['request_caps'][index],cfg['seed']+index,kv)
                    else:
                        delivered=time.monotonic();first.setdefault(rid,delivered)
                        events.setdefault(rid,[]).append(dict(time=delivered,count=message['count'],worker_time=message['time']))
                        if not message['finished']:continue
                        count=message['count'];assert count==cfg['request_caps'][index]
                        record=dict(model='qwen8',arm=cfg['arm'],sample_id=index,prompt_id=data[index]['prompt_id'],seed=cfg['seed']+index,
                            input_ids=data[index]['input_ids']['qwen8'],output_ids=message['output_ids'],
                            input_tokens=len(data[index]['input_ids']['qwen8']),output_tokens=count,
                            arrival=arrivals[rid],admission=admissions[rid],first_token=first[rid],finish=delivered,
                            ttft_ms=1000*(first[rid]-arrivals[rid]),tpot_ms=1000*(delivered-first[rid])/max(1,count-1),
                            e2e_ms=1000*(delivered-arrivals[rid]),token_events=events[rid],finish_reason=message['finish_reason'],
                            warmup=False,D_cached_prompt_tokens=message.get('cached_prompt_tokens'),model_revision=MODEL_REVISION,
                            evidence='MEASURED_NATIVE_VLLM_NIXL_PD' if cfg['arm']!='DP2' else 'MEASURED_NATIVE_VLLM_COLOCATED_DP2',
                            generation='CONTROLLED_IGNORE_EOS',timing_scope='Scheduled open-loop arrival to coordinator delivery. No HTTP.',
                            first_sample_scope='Native P sample is discarded. D resamples the original prompt with imported KV.')
                        append(folder/'requests.jsonl',record);completed[rid]=record;states[rid]='finished'
                        print('DONE',cfg['name'],index,count,round(record['e2e_ms'],2),flush=True)
            now=time.monotonic()
            if now-observation>=.5:
                observation=now;append(folder/'queue_observations.jsonl',dict(time=now,delivered=i,completed=len(completed),
                    outstanding=i-len(completed),pending_phases=dict(collections.Counter(states.values()))))
            assert all(c.poll() is None for c in children),'Native child exited during Serving'
            assert now-start<cfg['timeout'],'Native Serving watchdog'
            time.sleep(.0002)
        write(folder/'window.json',dict(start=start,end=time.monotonic(),last_arrival=max(arrivals.values()),
            arrival_pattern='SERIAL_CALIBRATION' if serial else 'OPEN_LOOP_POISSON'))
        write(folder/'status.json',dict(status='COMPLETE',time=time.time()))
    except BaseException as error:
        write(folder/'status.json',dict(status='FAILED',error=repr(error),time=time.time()));raise
    finally:
        for channel in channels.values():
            try:channel.send(dict(kind='stop'))
            except (BrokenPipeError,EOFError):pass
        exit_rows=[]
        for child in children:
            forced=False
            try:child.wait(45)
            except subprocess.TimeoutExpired:
                forced=True;child.terminate()
                try:child.wait(10)
                except subprocess.TimeoutExpired:child.kill();child.wait()
            exit_rows.append(dict(pid=child.pid,returncode=child.returncode,forced_cleanup=forced))
        write(folder/'worker_exits.json',dict(records=exit_rows,passed=bool(exit_rows) and all(r['returncode']==0 and not r['forced_cleanup'] for r in exit_rows)))
        for handle in handles:handle.close()
        monitor.stop()


def main():
    p=argparse.ArgumentParser();p.add_argument('config');p.add_argument('--role');p.add_argument('--address');a=p.parse_args()
    cfg=json.loads(Path(a.config).read_text());os.environ['VLLM_BATCH_INVARIANT']='1'
    for filename,expected in json.loads(os.environ.get('DENSE_SOURCE_HASHES','{}')).items():
        assert digest(filename)==expected,'Source changed before Native startup: '+filename
    if a.role:stage(cfg,a.role,a.address)
    else:coordinator(cfg)


if __name__=='__main__':main()
