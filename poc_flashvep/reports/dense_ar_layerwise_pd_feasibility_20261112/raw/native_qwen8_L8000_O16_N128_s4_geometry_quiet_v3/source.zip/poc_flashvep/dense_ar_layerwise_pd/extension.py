"""Optional native-model layer spans and diagnostic state observations.

The default Native path does not install this extension. State qualification
uses synchronous CPU staging for Hidden/Residual. This is not a fast transport.
NIXL retains its own KV allocation, transfer, notification, and ACK paths.
"""
import atexit,hashlib,json,os,time
from pathlib import Path
from .common import ROOT,write


def tensor_hash(tensor):
    import torch
    value=tensor.detach().contiguous().view(torch.uint8).cpu()
    return hashlib.sha256(value.numpy().tobytes()).hexdigest()


def install(cfg,role):
    import torch,vllm
    from vllm.sequence import IntermediateTensors
    from vllm.model_executor.models.qwen3 import Qwen3Model,Qwen3ForCausalLM
    from vllm.v1.core.sched.scheduler import Scheduler
    from vllm.v1.worker.gpu.model_runner import GPUModelRunner
    from vllm.v1.worker.gpu.model_states.default import DefaultModelState
    folder=ROOT/'raw'/cfg['name'];mode=cfg.get('layer_mode');cut=int(cfg.get('layer_cut',32))
    assert not mode or mode in ('STATE_REFERENCE','LOCAL_SPLIT','MIGRATE')
    assert 0<cut<36
    storage=folder/'state_transport';storage.mkdir(exist_ok=True)
    log=(folder/f'extension_{role}_{os.getpid()}.jsonl').open('a',buffering=1)
    active={'batch':None,'runner':None,'submitted':0,'measuring':False}
    imports={};external_ids={};transport={}
    def event(kind,**kw):log.write(json.dumps(dict(event=kind,time=time.monotonic(),role=role,**kw))+'\n')
    atexit.register(log.close)
    if cfg.get('hidden_transport')=='NIXL_GPU':
        from .hidden_transport import GPUHiddenTransport
        original_llm=vllm.LLM
        def initialized_llm(*args,**kwargs):
            llm=original_llm(*args,**kwargs)
            transport['value']=GPUHiddenTransport(cfg,role,folder,event)
            shutdown=llm.llm_engine.engine_core.shutdown
            def closed(*a,**kw):
                transport['value'].close();return shutdown(*a,**kw)
            llm.llm_engine.engine_core.shutdown=closed
            return llm
        vllm.LLM=initialized_llm
    from vllm.v1.engine.input_processor import InputProcessor
    assign=InputProcessor.assign_request_id
    def assigned(request):
        result=assign(request)
        external_ids[request.request_id]=request.external_req_id
        event('REQUEST_IDENTITY',request_id=request.request_id,external_request_id=request.external_req_id)
        return result
    InputProcessor.assign_request_id=staticmethod(assigned)

    # Preserve the PP state contract. Keep raw Hidden and Residual separate.
    if mode in ('LOCAL_SPLIT','MIGRATE'):
        def forward(self,input_ids,positions,intermediate_tensors=None,inputs_embeds=None):
            if intermediate_tensors is not None:
                hidden=intermediate_tensors['hidden_states'];residual=intermediate_tensors['residual'];start=cut
            else:
                hidden=inputs_embeds if inputs_embeds is not None else self.embed_input_ids(input_ids)
                residual=None;start=0
            end=cut if mode=='MIGRATE' and role=='prefill' else 36
            for index in range(start,end):
                hidden,residual=self.layers[index](positions,hidden,residual)
                if mode=='LOCAL_SPLIT' and index+1==cut:
                    hidden=hidden.clone();residual=residual.clone()
            if mode=='MIGRATE' and role=='prefill':
                return IntermediateTensors({'hidden_states':hidden,'residual':residual})
            hidden,_=self.norm(hidden,residual)
            return hidden
        # The existing decorator compiles this forward. We do not disable BI.
        Qwen3Model.forward=forward

    original_prepare=GPUModelRunner.prepare_inputs
    def prepare(self,*args,**kwargs):
        batch=original_prepare(self,*args,**kwargs);active.update(batch=batch,runner=self)
        if cfg.get('runtime_observation'):
            event('MODEL_INPUT_READY',request_ids=list(batch.req_ids),
                query_lengths=batch.num_scheduled_tokens.tolist(),computed_tokens=batch.num_computed_tokens_np.tolist(),
                prefilling=batch.is_prefilling_np.tolist(),tokens=batch.num_tokens)
        return batch
    GPUModelRunner.prepare_inputs=prepare

    schedule=Scheduler.schedule
    def observed_schedule(self,*args,**kwargs):
        result=schedule(self,*args,**kwargs)
        if cfg.get('runtime_observation'):
            waiting=[r for r in self.waiting]
            event('SCHEDULER_RESULT',scheduled=dict(result.num_scheduled_tokens),
                running=len(self.running),waiting=len(waiting),
                waiting_requests=[dict(request_id=r.request_id,status=str(r.status),computed=r.num_computed_tokens,
                    prompt_tokens=r.num_prompt_tokens) for r in waiting],
                KV_free_blocks=self.kv_cache_manager.block_pool.get_num_free_blocks(),
                KV_usage=self.kv_cache_manager.usage)
        return result
    if cfg.get('runtime_observation'):Scheduler.schedule=observed_schedule

    if cfg.get('cohort_barrier') and role=='decode':
        promote=Scheduler._try_promote_blocked_waiting_request;committed=set()
        def promote_cohort(self,request):
            params=request.kv_transfer_params or {};cohort=params.get('dense_cohort_id')
            if cohort is not None and cohort not in committed:
                expected=int(params['dense_cohort_size'])
                members=[r for r in self.requests.values() if (r.kv_transfer_params or {}).get('dense_cohort_id')==cohort]
                assert len(members)<=expected,'Cohort identity was reused'
                if len(members)<expected or any(r.request_id not in self.finished_recving_kv_req_ids for r in members):
                    return False
                assert not any(r.request_id in self.failed_recving_kv_req_ids for r in members)
                committed.add(cohort)
                event('NATIVE_KV_COHORT_READY',cohort=cohort,requests=[r.request_id for r in members])
            return promote(self,request)
        Scheduler._try_promote_blocked_waiting_request=promote_cohort

    if mode=='MIGRATE' and role=='decode':
        update=Scheduler._update_waiting_for_remote_kv
        def remote_ready(self,request):
            assert request.request_id not in self.failed_recving_kv_req_ids,'Do not consume failed partial KV'
            update(self,request)
            source_id=request.kv_transfer_params['remote_request_id']
            assert source_id!=request.request_id,'Keep independent Native internal identities'
            payload=storage/(source_id+('.gpu.json' if cfg.get('hidden_transport')=='NIXL_GPU' else '.pt'))
            assert payload.exists(),'Hidden state must be complete before partial KV is advertised'
            assert not self.cache_config.enable_prefix_caching
            assert len(request.output_token_ids)==0
            native_computed=request.num_computed_tokens
            request.num_computed_tokens=0
            imports[request.request_id]=source_id
            event('PARTIAL_KV_READY',request_id=request.request_id,native_computed=native_computed,
                source_request_id=source_id,resumed_query_start=0,resumed_layer_start=cut,full_prompt_queries=request.num_prompt_tokens)
        Scheduler._update_waiting_for_remote_kv=remote_ready

        original_inputs=DefaultModelState.prepare_inputs
        def imported_inputs(self,batch,req_states):
            inputs=original_inputs(self,batch,req_states)
            prefilling=[bool(v) for v in batch.is_prefilling_np[:batch.num_reqs]]
            if not any(prefilling):return inputs
            if all(rid.startswith('_warmup_') for rid in batch.req_ids):return inputs
            assert all(prefilling),'Diagnostic partial Prefill cannot share a batch with full Decode'
            hidden=[];residual=[];start=time.monotonic()
            for i,rid in enumerate(batch.req_ids):
                assert batch.num_computed_tokens_np[i]==0
                source_id=imports[rid]
                if cfg.get('hidden_transport')=='NIXL_GPU':
                    h,r=transport['value'].get(source_id,cut)
                    assert h.shape[0]==int(batch.num_scheduled_tokens[i])
                    hidden.append(h);residual.append(r);continue
                value=torch.load(storage/(source_id+'.pt'),map_location='cpu',weights_only=True)
                count=int(batch.num_scheduled_tokens[i])
                assert value['request_id']==source_id and value['cut']==cut and value['version']==1
                assert value['hidden'].shape[0]==count and value['residual'].shape==value['hidden'].shape
                assert tensor_hash(value['hidden'])==value['hidden_SHA256']
                assert tensor_hash(value['residual'])==value['residual_SHA256']
                hidden.append(value['hidden']);residual.append(value['residual'])
            h=torch.cat(hidden).to(batch.input_ids.device);r=torch.cat(residual).to(batch.input_ids.device)
            assert h.shape[0]==batch.num_tokens_after_padding,'Initial qualification requires no token padding'
            if cfg.get('hidden_transport')!='NIXL_GPU':torch.cuda.synchronize()
            inputs['intermediate_tensors']=IntermediateTensors({'hidden_states':h,'residual':r})
            event('HIDDEN_IMPORTED',request_ids=list(batch.req_ids),
                host_staged_bytes=0 if cfg.get('hidden_transport')=='NIXL_GPU' else (h.numel()+r.numel())*h.element_size(),
                elapsed_ms=1000*(time.monotonic()-start),
                evidence='MEASURED_NIXL_GPU_HIDDEN_IMPORT' if cfg.get('hidden_transport')=='NIXL_GPU' else 'CPU_STAGED_HIDDEN_TRANSFER_DIAGNOSTIC')
            return inputs
        DefaultModelState.prepare_inputs=imported_inputs

        if cfg.get('partial_KV_wire',False):
            from vllm.distributed.kv_transfer.kv_connector.v1.nixl.base_worker import NixlBaseConnectorWorker
            original_desc=NixlBaseConnectorWorker._compute_desc_ids
            def prefix_descriptors(self,block_ids,dst_num_blocks,block_size_ratio,physical_blocks_per_logical):
                ids=original_desc(self,block_ids,dst_num_blocks,block_size_ratio,physical_blocks_per_logical)
                assert not self._has_mamba and not self._is_hma_required
                assert self.num_regions%36==0 and self.num_regions>=36,'Require independent uniform layer regions'
                blocks=dst_num_blocks if block_size_ratio is None else int(dst_num_blocks*block_size_ratio)
                regions=ids//blocks
                selected=ids[regions<cut*(self.num_regions//36)]
                assert selected.size*36==ids.size*cut
                event('PARTIAL_KV_DESCRIPTORS',total_descriptors=int(ids.size),selected_descriptors=int(selected.size),
                    regions=self.num_regions,cut=cut)
                return selected
            NixlBaseConnectorWorker._compute_desc_ids=prefix_descriptors

    outer=Qwen3ForCausalLM.forward
    def observed_forward(self,*args,**kwargs):
        batch=active['batch'];runner=active['runner']
        # Dummy model profiling can follow a real batch. Runner execution marks
        # active inputs only for this model invocation and clears them below.
        if batch is None:
            result=outer(self,*args,**kwargs)
            return result['hidden_states'] if isinstance(result,IntermediateTensors) else result
        synthetic=all(rid.startswith('_warmup_') for rid in batch.req_ids)
        if synthetic:
            active['batch']=None;result=outer(self,*args,**kwargs)
            return result['hidden_states'] if isinstance(result,IntermediateTensors) else result
        start=time.monotonic();prefilling=bool(batch.is_prefilling_np[:batch.num_reqs].any())
        if mode=='MIGRATE' and prefilling:
            assert all(bool(v) for v in batch.is_prefilling_np[:batch.num_reqs])
            assert all(int(v)==0 for v in batch.num_computed_tokens_np[:batch.num_reqs])
        out=outer(self,*args,**kwargs)
        if mode=='MIGRATE' and role=='prefill':
            assert isinstance(out,IntermediateTensors)
            h=out['hidden_states'];r=out['residual'];transport_start=time.monotonic()
            for i,rid in enumerate(batch.req_ids):
                a=int(batch.query_start_loc_np[i]);b=int(batch.query_start_loc_np[i+1])
                if cfg.get('hidden_transport')=='NIXL_GPU':
                    transport['value'].put(rid,h[a:b],r[a:b],cut);continue
                hc=h[a:b].detach().cpu();rc=r[a:b].detach().cpu()
                value=dict(version=1,request_id=rid,cut=cut,hidden=hc,residual=rc,
                    hidden_SHA256=tensor_hash(hc),residual_SHA256=tensor_hash(rc))
                path=storage/(rid+'.pt');temporary=path.with_suffix('.tmp')
                torch.save(value,temporary);temporary.replace(path)
                event('HIDDEN_EXPORTED',request_id=rid,cut=cut,tokens=b-a,
                    bytes=(hc.numel()+rc.numel())*hc.element_size(),
                    hidden_SHA256=value['hidden_SHA256'],residual_SHA256=value['residual_SHA256'])
            event('HIDDEN_EXPORT_HOST_ENCLOSURE',elapsed_ms=1000*(time.monotonic()-transport_start),
                transport=cfg.get('hidden_transport','CPU_STAGING'))
            out=h # P sample is discarded by the existing Native PD coordinator.
        if mode and cfg.get('state_capture',True):
            from vllm.forward_context import get_forward_context
            context=get_forward_context();mappings=context.slot_mapping
            limit=cut if mode=='MIGRATE' and role=='prefill' else 36
            for i,rid in enumerate(batch.req_ids):
                if not bool(batch.is_prefilling_np[i]):continue
                a=int(batch.query_start_loc_np[i]);b=int(batch.query_start_loc_np[i+1])
                hashes=[]
                raw_states=[]
                for layer in range(limit):
                    name=f'model.layers.{layer}.self_attn.attn'
                    attn=context.no_compile_layers[name];cache=attn.kv_cache
                    assert cache.ndim==4 and cache.shape[1]==8 and cache.shape[3]==256,tuple(cache.shape)
                    slots=mappings[name][a:b].long();block_size=cache.shape[2]
                    assert bool((slots>=0).all())
                    valid=cache[slots//block_size,:,slots%block_size,:]
                    hashes.append(dict(layer=layer,SHA256=tensor_hash(valid),bytes=valid.numel()*valid.element_size()))
                    if cfg.get('save_state_tensors'):raw_states.append(valid.detach().cpu())
                if cfg.get('save_state_tensors'):
                    state_path=folder/'state_tensors';state_path.mkdir(exist_ok=True)
                    torch.save(dict(request_id=rid,external_request_id=external_ids[rid],
                        KV=raw_states,hidden=out[a:b].detach().cpu()),state_path/(role+'_'+external_ids[rid]+'.pt'))
                event('VALID_QUERY_STATE',request_id=rid,external_request_id=external_ids[rid],query_start=int(batch.num_computed_tokens_np[i]),
                    query_tokens=b-a,final_hidden_SHA256=tensor_hash(out[a:b]),KV=hashes,
                    state_scope='Only queried valid KV cells. Unallocated and unused cache cells are excluded.')
        if cfg.get('runtime_observation') or mode:
            event('MODEL_FORWARD_HOST_ENCLOSURE',request_ids=list(batch.req_ids),prefilling=prefilling,
                start=start,end=time.monotonic(),scope='Host enclosure. Not CUDA kernel union time.')
        if mode=='MIGRATE' and role=='decode' and prefilling and cfg.get('hidden_transport')=='NIXL_GPU':
            transport['value'].retire([imports[rid] for rid in batch.req_ids])
        active['batch']=None
        return out
    if mode or cfg.get('runtime_observation'):Qwen3ForCausalLM.forward=observed_forward
    event('EXTENSION_INSTALLED',mode=mode,cut=cut,partial_KV_wire=cfg.get('partial_KV_wire',False),
        CUDA_graph_mode=cfg['ar_cudagraph_mode'],state_capture=cfg.get('state_capture',True))
