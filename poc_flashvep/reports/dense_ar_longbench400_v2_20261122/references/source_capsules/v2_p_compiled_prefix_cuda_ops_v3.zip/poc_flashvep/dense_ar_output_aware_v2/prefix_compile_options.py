"""Change only the P compiler family when the experimental switch is on."""
from poc_flashvep.dense_ar_longbench400_pd.scoped_compile_options import options as original

def options(cfg,role='single'):
    if role=='prefill' and cfg.get('P_compile_prefix'):
        assert cfg.get('preserve_compiled_full_model')
        cfg=dict(cfg,execution_family='INSTALLED_DEFAULT_COMPILE')
    value=original(cfg,role)
    if role=='prefill' and cfg.get('P_compile_prefix') and cfg.get('P_compiled_custom_ops_all'):
        value['compilation_config']=dict(value.get('compilation_config',{}),custom_ops=['all'])
    return value
