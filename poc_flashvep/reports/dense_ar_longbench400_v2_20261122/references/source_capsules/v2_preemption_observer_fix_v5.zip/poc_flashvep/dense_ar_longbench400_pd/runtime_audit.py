"""Record the installed runtime identity and detect changes from wheel metadata."""
import base64
import hashlib
import importlib.metadata
import json
from pathlib import Path
import time
import zipfile
from .common import ROOT,write,digest,MODEL


def main():
    package=importlib.metadata.distribution('vllm');files=[];modified=[]
    archive=ROOT/'references/installed_vllm_python_sources_v1.zip'
    assert not archive.exists(),'Preserve the installed-runtime snapshot'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as bundle:
        for member in package.files:
            if str(member).startswith('vllm/') and str(member).endswith('.py'):
                path=package.locate_file(member);sha=digest(path)
                expected=member.hash.value if member.hash and member.hash.mode=='sha256' else None
                match=expected==base64.urlsafe_b64encode(bytes.fromhex(sha)).decode().rstrip('=') if expected else None
                row=dict(path=str(member),SHA256=sha,wheel_RECORD_match=match,mtime=path.stat().st_mtime)
                files.append(row)
                if match is False:modified.append(row)
                bundle.write(path,str(member))
    names=('vllm','torch','transformers','nixl','apache-tvm-ffi','nvidia-cutlass-dsl')
    versions={name:importlib.metadata.version(name) for name in names}
    report=dict(time=time.time(),versions=versions,python_files=len(files),modified_from_installed_wheel_RECORD=modified,
        files=files,source_archive_SHA256=digest(archive),model_revision=MODEL.name,
        model_config_SHA256=digest(MODEL/'config.json'),
        scope='Installed-wheel identity and current Python sources. A RECORD match does not prove equivalence to an upstream official wheel. '
            'Custom optional scheduler flags require a separate inactive-default audit. No installed file is modified.')
    write(ROOT/'references/installed_runtime_source_audit_v1.json',report)
    print(json.dumps(dict(versions=versions,python_files=len(files),modified=modified,source_archive_SHA256=digest(archive)),indent=2))


if __name__=='__main__':main()
