"""Judge serving gains and decode protection with paired independent starts."""
import json
import time
import numpy as np
from .common import ROOT,write
from .metrics import summarize
from .confirmation_analysis import ratio
from .final_continuous_selection import policy


FIELDS=('TTFT_p50_ms','TTFT_p95_ms','TTFT_p99_ms','TTFT_mean_ms',
    'mean_TBT_ms','ITL_p99_ms','TPOT_p95_ms','E2E_p95_ms',
    'generated_output_tokens_per_second','completed_requests_per_second',
    'Joint_SLO_attainment','SLO_qualified_output_tokens_per_second','decode_SLO_attainment',
    'actual_arrival_QPS','actual_dispatch_QPS','output_tokens')


def load(name,source):
    folder=ROOT/'raw'/name
    receipt=folder/'dispatcher_result.json'
    if not receipt.exists():
        return None,None,'NOT_RUN'
    result=json.loads(receipt.read_text())
    if not result['complete']:
        return None,None,'FAILED'
    assert result['source_SHA256']==source
    cfg=json.loads((folder/'configuration.json').read_text())
    m=summarize(name)
    gate=ROOT/'analysis'/(name+'_quality_gate.json')
    if not gate.exists():
        return None,cfg,'PENDING_TASK_QUALITY'
    q=json.loads(gate.read_text())
    if not q['passed']:
        return m,cfg,'FAILED_TASK_QUALITY'
    assert m['n']==cfg['count'] and not cfg['ignore_eos'] and not cfg['controlled_pipeline']
    for role in ('prefill','decode'):
        path=folder/f'KV_lifetime_{role}.json'
        if path.exists():
            assert json.loads(path.read_text())['passed']
    return m,cfg,'MEASURED_ONLINE'


def main():
    path=ROOT/'configs/final_continuous_execution_plan_v1.json'
    plan=json.loads(path.read_text())
    groups={}
    for cell in plan['cells']:
        groups.setdefault((cell['workload'],cell['QPS']),[]).append(cell)
    rows=[]
    for (workload,qps),cells in sorted(groups.items()):
        cells=sorted(cells,key=lambda r:r['start'])
        arms=sorted(cells[0]['jobs'])
        assert all(sorted(c['jobs'])==arms for c in cells)
        row=dict(workload=workload,QPS=qps,required_starts=len(cells),starts=[],
            status='NOT_RUN',arm_results={},comparisons={})
        values={a:[] for a in arms}
        configurations={a:[] for a in arms}
        all_valid=True
        for cell in cells:
            block={}
            for arm,name in cell['jobs'].items():
                m,cfg,status=load(name,plan['source_capsule_SHA256'])
                block[arm]=dict(name=name,status=status)
                if status=='MEASURED_ONLINE':
                    values[arm].append(m)
                    configurations[arm].append(cfg)
                else:
                    all_valid=False
            if all(v['status']=='MEASURED_ONLINE' for v in block.values()):
                base=configurations['NativeStrong'][-1]
                for arm in arms:
                    cfg=configurations[arm][-1]
                    assert all(cfg[k]==base[k] for k in ('dataset_SHA256','arrival_offsets','seed','gpus',
                        'output_cap','ignore_eos','token_budget','max_num_seqs'))
            row['starts'].append(dict(seed=cell['seed'],GPU_pair=cell['GPU_pair'],arms=block))
        for arm in arms:
            v=values[arm]
            row['arm_results'][arm]=dict(valid_starts=len(v),means={f:float(np.mean([r[f] for r in v]))
                for f in FIELDS} if v else {},
                actual_geometry=[r['actual_geometry'] for r in v],
                per_start_output_tokens=[r['output_tokens'] for r in v],
                runtime_contract=[dict(execution_family=c['execution_family'],
                    Source_credit=c.get('continuous_source_credit_limit',0),
                    policy=list(policy(c)),axis=c.get('axis_kind','Native'),cut=c.get('axis_cut',0),
                    suffix_fraction=c.get('hybrid_suffix_fraction'),fractional_token_work=c.get('fractional_token_work'),
                    hidden_slots=[c['hidden_source_slots'],c['hidden_destination_slots']],
                    B=c['token_budget'],S=c['max_num_seqs'],block=c['KV_block_tokens'])
                    for c in configurations[arm]])
        if all_valid:
            row['status']='MEASURED_ONLINE_CONFIRMED' if len(cells)>=3 else 'MEASURED_ONLINE_SINGLE_START'
            for arm in arms:
                if not arm.startswith('Best'):
                    continue
                cfg=configurations[arm][0]
                common=[a for a in arms if a.startswith('NativeCommon') and policy(configurations[a][0])==policy(cfg)]
                assert len(common)==1,(arm,common)
                refs=['NativeStrong',common[0]]
                if 'NativeTuned' in arms:
                    refs.append('NativeTuned')
                if arm in ('BestLayer','BestHybrid') and 'BestToken' in arms:
                    refs.append('BestToken')
                if arm=='BestHybrid' and 'BestLayer' in arms:
                    refs.append('BestLayer')
                comparisons={}
                for ref in refs:
                    tests={}
                    for field in FIELDS:
                        a=[r[field] for r in values[arm]]
                        b=[r[field] for r in values[ref]]
                        tests[field]=ratio(a,b) if len(cells)>=3 else dict(
                            estimate=a[0]/b[0] if b[0]>0 else None,CI95=None,starts=1,
                            qualifier='Single start. No confidence-interval claim.')
                    decode=None if len(cells)<3 else all(tests[f] is not None and tests[f]['CI95'][1]<=1.05
                        for f in ('ITL_p99_ms','TPOT_p95_ms'))
                    comparisons[ref]=dict(ratios=tests,decode_5percent_CI_pass=decode,
                        absolute_decode_attainment_95percent=all(r['decode_SLO_attainment']>=.95 for r in values[arm]),
                        TTFT_p95_CI_win=None if len(cells)<3 else tests['TTFT_p95_ms']['CI95'][1]<1,
                        goodput_CI_win=None if len(cells)<3 or tests['SLO_qualified_output_tokens_per_second'] is None
                            else tests['SLO_qualified_output_tokens_per_second']['CI95'][0]>1)
                row['comparisons'][arm]=comparisons
        rows.append(row)
    write(ROOT/'analysis/final_continuous_strong_confirmation_v1.json',dict(time=time.time(),cells=rows,
        source_capsule_SHA256=plan['source_capsule_SHA256'],evidence='MEASURED_ONLINE',
        scope='Frozen discovery choices. Paired independent server-start/seed blocks. '
            'All Heldout200 confirmations use GPUs0/1. Main400 three-start blocks span0/1,2/3,4/5. '
            'Pointwise unadjusted empirical CIs with27 resamples for3 starts. '
            'Actual natural output counts may differ under the declared BI0 task-quality contract. '
            'Report those counts,not the C1 reference lengths as identical generated work. '
            'Both NativeStrong and policy-matched Native protect ITL and TPOT. '
            'Failed,quality-invalid,pending and missing starts do not become qualified points. '
            'Finite-cohort throughput is not sustainable capacity. A static gain is not an active-decode safe-window or dynamic-selector gain.'))
    print([(r['workload'],r['QPS'],r['status']) for r in rows],flush=True)


if __name__=='__main__':
    main()
