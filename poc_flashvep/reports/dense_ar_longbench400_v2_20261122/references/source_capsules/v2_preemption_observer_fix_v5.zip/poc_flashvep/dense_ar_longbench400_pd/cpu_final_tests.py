"""Run CPU regression tests without editing runtime files or GPU owners."""
import ast
from fractions import Fraction
import json
import random
import time
from types import SimpleNamespace
import unittest
import numpy as np
from .common import ROOT,SOURCE,write,preserve
from .geometry import Partition,matched_suffixes,active_spans
from .qualification_gate import KV_equal
from .window_analysis import overlap,duration
from .c0_queue_model import nnls,simulate
from .decode_prefill_throttle import call
from .prefill_completion_guard import capped_call


class CPUChecks(unittest.TestCase):
    def test_python_syntax(self):
        for path in SOURCE.glob('*.py'):
            ast.parse(path.read_text(),filename=str(path))

    def test_two_dimensional_conservation(self):
        for length in (32,257,3987,8192,16384,32768):
            for upper in (0,2,4,8,12):
                for suffix in (0,length//16,length//8,length//3):
                    p=Partition(length,upper,suffix)
                    self.assertEqual(p.P_rows+p.D_rows,36*length)
                    self.assertEqual(p.P_attention_pairs+p.D_attention_pairs,36*length*(length+1)//2)
                    self.assertEqual(p.D_rows,length*upper+(36-upper)*suffix)
                    # Prefix upper layers precede all suffix upper queries.
                    for token in range(min(length,48)):
                        for layer in range(36):
                            if p.owners(token,layer)=='P':
                                self.assertLess(token,p.prefix)
                                self.assertLess(layer,p.lower)

    def test_alignment_optimal_residual(self):
        rng=random.Random(2026112481)
        for _ in range(100):
            lengths=[rng.randint(3000,36000) for _ in range(rng.randint(1,32))]
            for cut in (Fraction(2),Fraction(8),Fraction(25,4),Fraction(39,4),Fraction(27,2)):
                suffix,audit=matched_suffixes(lengths,cut)
                self.assertTrue(all(0<s<L and s%16==0 for s,L in zip(suffix,lengths)))
                self.assertLessEqual(abs(audit['signed_error_rows']),288)
                self.assertEqual(audit['actual_D_rows'],36*sum(suffix))
                self.assertEqual(audit['exact_match'],36*sum(suffix)==cut*sum(lengths))

    def test_mixed_row_span_ownership(self):
        args=([0,8,9],[12,128],[16,0],[32,0])
        self.assertEqual(active_spans(*args,0,'D'),[(0,4,8),(1,8,9)])
        self.assertEqual(active_spans(*args,32,'D'),[(0,0,8),(1,8,9)])

    def test_digest_algorithm_mismatch_is_not_tensor_inequality(self):
        raw=[dict(hash='a')]
        leaf=[dict(hash='a',digest_algorithm='SHA256_OF_SHA256_4096B_LEAVES_V1',chunk_bytes=4096)]
        with self.assertRaises(ValueError):
            KV_equal(raw,leaf)
        self.assertTrue(KV_equal(leaf,leaf))
        self.assertFalse(KV_equal(leaf,[dict(leaf[0],hash='b')]))

    def test_prefill_policy_restores_original_state(self):
        scheduler=SimpleNamespace(prefill_capacity_bound=True)
        def original(value,throttle_prefills=False):
            self.assertTrue(throttle_prefills)
            self.assertFalse(value.prefill_capacity_bound)
            return 7
        self.assertEqual(call(original,scheduler),7)
        self.assertTrue(scheduler.prefill_capacity_bound)
        def failed(value,throttle_prefills=False):
            raise RuntimeError('Expected fixture')
        with self.assertRaises(RuntimeError):
            call(failed,scheduler)
        self.assertTrue(scheduler.prefill_capacity_bound)

    def test_interval_union_against_integer_reference(self):
        rng=random.Random(2026112482)
        for _ in range(1000):
            a=[sorted((rng.randrange(100),rng.randrange(100))) for _ in range(8)]
            b=[sorted((rng.randrange(100),rng.randrange(100))) for _ in range(8)]
            aa={i for left,right in a for i in range(left,right)}
            bb={i for left,right in b for i in range(left,right)}
            self.assertEqual(duration(overlap(a,b)),len(aa&bb))

    def test_completion_cap_restoration(self):
        scheduler=SimpleNamespace(max_num_running_reqs=1024)
        def original(value):
            self.assertEqual(value.max_num_running_reqs,2)
            return 7
        self.assertEqual(capped_call(original,scheduler,2),7)
        self.assertEqual(scheduler.max_num_running_reqs,1024)
        def failed(value):
            raise RuntimeError('Expected fixture')
        with self.assertRaises(RuntimeError):
            capped_call(failed,scheduler,2)
        self.assertEqual(scheduler.max_num_running_reqs,1024)

    def test_nonnegative_fit_and_state_updating_replay(self):
        matrix=np.array([[1,0],[0,1],[1,1],[2,1]],float)
        weights,_=nnls(matrix,matrix@np.array([2.,3.]))
        np.testing.assert_allclose(weights,[2.,3.],atol=1e-10)
        model=dict(P=[100,0,0,0,0,0],D=[50,0,0,0,0,0,0],decode_step=[10,0])
        result=simulate([0]*8,[4096]*8,[Partition(4096)]*8,8,model)
        self.assertEqual(len(result['rows']),8)
        first=result['rows'][0]
        self.assertAlmostEqual(first['first'],.150)
        self.assertAlmostEqual(first['finish'],.220)
        self.assertGreater(result['rows'][7]['P_start'],result['rows'][1]['P_start'])
        self.assertTrue(all(r['P_start']<=r['P_ready']<=r['D_start']<=r['first']<=r['finish']
            for r in result['rows']))


def main():
    preserve()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(CPUChecks)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        from .cpu_regression import main as row_regression
        row_regression()
        from .remote_setup_deferral import test as metadata_test
        metadata_test()
    preserve()
    write(ROOT/'analysis/cpu_final_regression_v1.json',dict(time=time.time(),passed=result.wasSuccessful(),
        tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        evidence='CPU_REGRESSION',scope='CPU ownership,alignment,interval,policy-state and replay tests. '
            'The actual row-aware forward seam uses CPU surrogate operators. '
            'These tests do not replace GPU causal attention,state,lifetime,quality or ITL gates.'))
    assert result.wasSuccessful()


if __name__=='__main__':
    main()
