"""Experimental P-only compiled lower-layer segment with original weights."""
import copy
import time
import torch
from vllm.compilation.decorators import support_torch_compile
from poc_flashvep.dense_ar_longbench400_pd.compiled_full_adapter import CompiledFullAdapter

@support_torch_compile(dynamic_arg_dims={'positions':0,'hidden':0,'residual':0})
class PrefixSegment(torch.nn.Module):
    def __init__(self,layers):
        super().__init__()
        self.layers=torch.nn.ModuleList(layers)

    def forward(self,positions:torch.Tensor,hidden:torch.Tensor,residual:torch.Tensor|None):
        for layer in self.layers:hidden,residual=layer(positions,hidden,residual)
        return hidden,residual

class PrefixCompiledAdapter(CompiledFullAdapter):
    def compiled_prefix_segment(self,module,positions,hidden,residual,begin,end):
        from vllm.config import set_current_vllm_config,CUDAGraphMode
        from vllm.config.kernel import IrOpPriorityConfig
        from vllm.forward_context import get_forward_context,override_forward_context
        assert self.role=='prefill' and self.cfg.get('P_compile_prefix')
        assert begin==0 and end==36-int(self.cfg['axis_cut'])
        runner=self.active['runner'];config=runner.vllm_config
        assert int(config.compilation_config.mode)==3
        cache=getattr(self,'_compiled_prefix_segments',None)
        if cache is None:cache={};self._compiled_prefix_segments=cache
        key=(begin,end)
        if key not in cache:
            with set_current_vllm_config(config,check_compile=False):cache[key]=PrefixSegment(list(module.layers[begin:end]))
            assert not cache[key].do_not_compile
        block=cache[key];context=copy.copy(get_forward_context())
        context.skip_compiled=False;context.cudagraph_runtime_mode=CUDAGraphMode.NONE;context.batch_descriptor=None
        # Preserve the explicitly qualified eager CUDA RMSNorm provider. This
        # changes graph execution,not weights,causal metadata or residual state.
        with override_forward_context(context),IrOpPriorityConfig.with_default(['vllm_c','native']).set_priority():
            result=block(positions,hidden,residual)
        compiled=bool(block.compiled or getattr(block,'aot_compiled_fn',None) is not None)
        assert compiled,'Do not label an eager fallback as a compiled prefix'
        self.rows.append(dict(event='P_COMPILED_PREFIX_SEGMENT',time=time.monotonic(),begin=begin,end=end,
            query_rows=int(hidden.shape[0]),compiled=compiled,CUDA_graph=False,
            scope='Original lower-layer weights and causal metadata. Returns hidden plus residual before final norm.'))
        return result
