"""CPU-only checks for arrival and SLO semantics."""
import json
from pathlib import Path
import pytest

from .worker import arrival_trace


def test_frozen_arrival_trace_is_identical_across_arms():
    first, end = arrival_trace(200, 2., 2026103001)
    other, other_end = arrival_trace(200, 2., 2026103001)
    assert first == other and end == other_end
    assert len(first) == 200 and first[0] > 0 and end > first[-1]
    assert all(x < y for x, y in zip(first, first[1:]))


def test_independent_starts_use_distinct_arrival_traces():
    assert arrival_trace(20, 1., 1) != arrival_trace(20, 1., 2)


def test_burst_arrivals_are_a_distinct_preregistered_trace():
    a, end_a = arrival_trace(200, 1., 9)
    b, end_b = arrival_trace(200, 1., 9, burst=True)
    assert a != b and end_b < end_a
    assert all(x < y for x, y in zip(b, b[1:]))


def test_dataset_calibration_and_heldout_are_disjoint():
    from .common import ROOT
    groups = [json.loads((ROOT / 'data' / (name + '.json')).read_text()) for name in ('calibration', 'correctness', 'W1')]
    hashes = [{row['prompt_sha256'] for row in group} for group in groups]
    assert all(not hashes[i] & hashes[j] for i in range(3) for j in range(i))
    assert len(hashes[2]) == 200
    assert all(max(row['input_lengths'].values()) + 256 <= 4096 for group in groups for row in group)


def test_one_token_TPOT_convention_and_arrival_denominator(monkeypatch, tmp_path):
    from . import analyze, jobs
    monkeypatch.setattr(analyze, 'ROOT', tmp_path)
    monkeypatch.setattr(jobs, 'ROOT', tmp_path)
    folder = tmp_path / 'raw/example'
    folder.mkdir(parents=True)
    (tmp_path / 'configs').mkdir()
    (folder / 'status.json').write_text(json.dumps(dict(status='COMPLETE')))
    records = [dict(sample_id=i, output_tokens=1, input_tokens=100, ttft_ms=10, tpot_ms=0,
                    e2e_ms=10, finish_reason=('eos', 'stop', 'length')[i], finish=.1, token_events=[], warmup=False) for i in range(3)]
    (folder / 'requests.jsonl').write_text('\n'.join(json.dumps(r) for r in records))
    (folder / 'window.json').write_text(json.dumps(dict(start=0, window_seconds=10, evaluation_end=10,
                                                      actual_span_seconds=15, drain_seconds=5, actual_trace_rate=.4)))
    (tmp_path / 'configs/slo_lock.json').write_text(json.dumps(dict(ouro=dict(TTFT_ms=100, TPOT_ms=1, secondary_ITL_ms=5))))
    job = dict(name='example', model='ouro', arm='B', workload='W1', gpus=[0,1], seed=1, rate=.4, count=4, cap=128)
    row, _, _ = analyze.summarize(job)
    assert row['qualified_requests'] == 3 and row['joint_attainment_percent'] == 75
    assert row['qualified_requests_s_window'] == pytest.approx(.3)
    assert row['qualified_requests_s_with_drain'] == pytest.approx(.2)
    assert row['planned_but_incomplete_fraction'] == .25
    assert row['EOS_stops'] == 2 and row['cap_stops'] == 1


def test_output_failure_cannot_become_accepted_capacity(monkeypatch, tmp_path):
    from . import finish, analyze
    monkeypatch.setattr(finish, 'ROOT', tmp_path)
    monkeypatch.setattr(analyze, 'ROOT', tmp_path)
    (tmp_path / 'state').mkdir()
    (tmp_path / 'state/ouro_B_serving_parity_failure.json').write_text('{}')
    rows = [dict(model='ouro', GPU_count='2', arm='B', offered_rate='1', seed='1',
                 status='COMPLETE', joint_attainment_percent='95', weak_queue_check='True',
                 completed_throughput_with_drain='1', actual_trace_rate='1')]
    result = next(row for row in finish.capacity_bounds(rows)
                  if row['model'] == 'ouro' and row['GPU_count'] == 2 and row['arm'] == 'B')
    assert result['lower_tested_rate'] == 1
    assert result['accepted_lossless_capacity'] == 'REJECTED_CORRECTNESS_GATE'


def test_profile_launcher_import_does_not_start_workers():
    import importlib
    from ..looped_pd_abc import worker as reused
    before = reused.main
    launcher = importlib.import_module('poc_flashvep.looped_pd_b_slo_serving.profile_python')
    assert callable(launcher.main)
    assert reused.main is before
