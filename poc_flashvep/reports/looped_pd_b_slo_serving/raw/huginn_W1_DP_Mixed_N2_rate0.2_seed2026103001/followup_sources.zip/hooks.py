"""Diagnostic-only event observations. Never enabled in clean serving jobs."""
import os
from pathlib import Path
import time


def install():
    if os.environ.get('B_EVENT_TRACE') != '1':
        return
    from vllm_rlt.pd.connector import PDStageConnector
    from vllm_rlt.pd.transport import NixlConnector
    from ..looped_pd_abc.telemetry import append
    if getattr(NixlConnector, '_B_event_trace', False):
        return
    NixlConnector._B_event_trace = True

    def record(kind, **value):
        path = Path(os.environ['ABC_RUN_DIR']) / f'transfer_events_{os.getpid()}.jsonl'
        append(path, dict(kind=kind, time=time.monotonic(), pid=os.getpid(), **value,
                          evidence='MEASURED_DIAGNOSTIC_HOST_OBSERVATION_NOT_GPU_DMA_TIME'))

    progress = PDStageConnector.progress
    def traced_progress(self):
        if not hasattr(self, '_B_seen_ready'):
            self._B_seen_ready = set()
        for transfer in list(self.transfers.values()):
            for event, sequence, local, remote, size in list(transfer.chunks):
                key = transfer.tid, sequence
                if key not in self._B_seen_ready and (event is None or event.query()):
                    self._B_seen_ready.add(key)
                    record('ready_first_observed', tid=transfer.tid, sequence=sequence, bytes=size,
                           scope='First diagnostic poll that observes the producer CUDA event complete. Not exact kernel completion time.')
        return progress(self)
    PDStageConnector.progress = traced_progress

    submit = NixlConnector.submit
    def traced_submit(self, tid, sequence, peer, local, remote, size):
        begin = time.monotonic()
        result = submit(self, tid, sequence, peer, local, remote, size)
        if result:
            record('submitted', tid=tid, sequence=sequence, bytes=size,
                   descriptor_count=len(local), metadata_and_issue_us=1e6 * (time.monotonic() - begin))
        return result
    NixlConnector.submit = traced_submit

    poll = NixlConnector.poll
    def traced_poll(self):
        finished, notifications = poll(self)
        for transfer in finished:
            record('completion_observed', tid=transfer.transfer_id, sequence=transfer.sequence,
                   bytes=transfer.size, actual_submit=transfer.submitted)
        return finished, notifications
    NixlConnector.poll = traced_poll
