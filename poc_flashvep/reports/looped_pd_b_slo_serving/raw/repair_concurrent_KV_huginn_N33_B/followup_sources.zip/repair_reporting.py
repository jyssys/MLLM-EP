"""Report repair qualifications separately from the rejected original epoch."""
import csv
import json

from .common import ROOT


def report():
    from .finish import table
    from .repair_review import main as review
    review()
    def load(name, default):
        path = ROOT / name
        return json.loads(path.read_text()) if path.exists() else default
    qualifications = load('configs/repair_epoch_qualification.json', {})
    expansion = load('configs/b_repair_expansion.json', [])
    serving = load('configs/repair_epoch_serving_results.json', [])
    summary_path = ROOT / 'repair_epoch_w1_capacity.csv'
    measured = list(csv.DictReader(summary_path.open())) if summary_path.exists() else []
    text = '# B repair and separate execution epoch\n\n'
    text += 'The original output failures remain unchanged. They are not accepted serving speedups.\n'
    text += 'This report separates later diagnostic changes and their qualification.\n'
    text += 'The original15-hour deadline and frozen SLOs still apply.\n'
    text += 'Checkpoint weights, BF16 tensor precision, and fixed recurrence remain unchanged.\n\n'
    text += '## Completed expansion stages\n\n'
    rows = []
    for item in expansion:
        stage, result = item['stage'], item['result']
        comparisons = result.get('comparisons', [])
        counts = [f"{value['exact']}/{value['N']}" for value in comparisons]
        rows.append([stage['model'], stage['count'], stage['cap'],
                     counts[0] if counts else 'NOT_MEASURED', counts[1] if len(counts) > 1 else 'NOT_MEASURED',
                     result['passed']])
    text += table(['Model', 'Requests', 'Output cap', 'Control/B exact', 'Control repeat exact', 'Stage pass'], rows)
    text += '\nA small passing stage is not a full repair acceptance. Counts measure generated sequences, not answer accuracy.\n\n'
    text += '## Model-level qualification\n\n'
    rows = []
    for model in ('ouro', 'huginn'):
        value = qualifications.get('models', {}).get(model, {})
        rows.append([model, qualifications.get('epoch', 'NOT_AVAILABLE'), value.get('passed', 'PENDING'),
                     f"{value.get('KV_exact', 'NOT_MEASURED')}/{value.get('KV_N', 'NOT_MEASURED')}",
                     value.get('full_depth_work_checks', 'NOT_MEASURED'), value.get('reason', '')])
    text += table(['Model', 'Epoch', 'Qualified', 'KV exact/N', 'Full-depth counter checks', 'Failure reason'], rows)
    text += '\nQualification requires200 original W1 requests, an identical-control repeat, stop parity, and fixed-depth work counters.\n'
    text += 'It also requires reversed-fragment prompt-KV and final-hidden byte checks with the same repair.\n'
    text += 'The source hash must match all full qualification runs.\n'
    text += 'A failed model does not disable the other model.\n\n'
    text += '## Actual separate-epoch serving\n\n'
    text += table(['Model', 'Arm', 'Offered req/s', 'Seed', 'Completed/planned', 'Joint SLO %', 'Window goodput req/s', 'Queue scope'],
                  [[row['model'], row['arm'], row['offered_rate'], row['seed'],
                    f"{row['completed']}/{row['planned_arrivals']}", row.get('joint_attainment_percent', 'NOT_MEASURED'),
                    row.get('qualified_requests_s_window', 'NOT_MEASURED'), row.get('queue_stability', 'NOT_MEASURED')]
                   for row in measured])
    if not measured:
        text += '\nNo separate-epoch serving measurement is available yet.\n'
    text += '\nThese rows never enter the original-epoch capacity table.\n'
    text += 'Latency and transfer CSVs identify the execution epoch for each run.\n'
    text += 'All three serving arms use the same canonical execution changes and physical GPU pair at each point.\n'
    text += 'The second independent seed uses a different GPU pair and a rotated arm order.\n'
    text += 'Rates and budgets are declared before the new epoch sees serving outcomes.\n'
    text += 'No SLO threshold changes. No pre-repair and post-repair samples are pooled.\n\n'
    text += '## Serving output gate\n\n'
    text += table(['Model', 'Offered req/s', 'Seed', 'Control/B exact', 'All outputs exact'],
                  [[item['model'], item['rate'], item['seed'],
                    f"{item['B_control_output']['exact']}/{item['B_control_output']['N']}", item['outputs_exact']]
                   for item in serving if 'B_control_output' in item])
    text += '\nA new mismatch closes that model\'s new performance gate. It does not erase its recorded failure.\n'
    text += 'Finite rate grids do not establish an unrestricted sustainable maximum.\n'
    text += 'Between-start uncertainty needs multiple completed starts. A single point has no such confidence interval.\n'
    text += 'No original-model-lossless GO is established. Official-HF fidelity remains unresolved.\n'
    text += 'Generic immutable-layer streaming is not independently measured. Loop-exclusive novelty remains unresolved.\n'
    text += 'Read `b_repair_diagnosis.md`, `b_repair_ablation_summary.csv`, and the per-run source snapshots.\n'
    (ROOT / 'repair_epoch_report.md').write_text(text)


if __name__ == '__main__':
    report()
