"""Time-limited longer W1 windows. Reuse 200 distinct texts without prefix caching."""
import csv
import json
import math
import time

from .common import ROOT, START, GPU_STOP, write, remaining
from .jobs import configuration, run, parity
from .analyze import summarize, main as analyze
from . import resources


def main():
    # Prioritize a longer primary window over more scale discovery.
    if remaining() < 2.0 * 3600:
        write(ROOT / 'state/extended_windows.json', dict(status='NOT_MEASURED_TIME_BUDGET', time=time.time()))
        return
    source = json.loads((ROOT / 'data/W1.json').read_text())
    expanded = []
    for occurrence in range(24):
        for row in source:
            expanded.append(dict(row, source_prompt_id=row['prompt_id'], occurrence=occurrence,
                                 prompt_id=f"{row['prompt_id']}::occurrence{occurrence}"))
    write(ROOT / 'data/W1_long.json', expanded)
    rows = list(csv.DictReader((ROOT / '03_primary_w1_capacity.csv').open()))
    plan = []
    for model in ('ouro', 'huginn'):
        eligible = [row for row in rows if row['model'] == model and row['GPU_count'] == '2'
                    and row['status'] == 'COMPLETE' and float(row.get('joint_attainment_percent') or 0) >= 90
                    and row.get('weak_queue_check') == 'True']
        by_arm = {arm: sorted({float(row['offered_rate']) for row in eligible if row['arm'] == arm})
                  for arm in ('DP_Mixed', 'PD_G1', 'B')}
        enabled = not (ROOT / 'state' / (model + '_B_serving_parity_failure.json')).exists()
        base = by_arm['PD_G1'][-1] if by_arm['PD_G1'] else (.2 if model == 'huginn' else 1.)
        rates = {base}
        # One independently defined refinement point. Never select on a favorable E2E metric.
        all_rates = sorted({float(row['offered_rate']) for row in rows if row['model'] == model and row['GPU_count'] == '2' and row['arm'] == 'PD_G1'})
        greater = [rate for rate in all_rates if rate > base]
        rates.add((base + min(greater)) / 2 if greater else 1.5 * base)
        for rate in sorted(rates):
            count = min(4800, max(200, math.ceil(rate * 360)))
            for repeat in (0, 1):
                plan.append(dict(model=model, rate=rate, count=count, seed=2026104001 + repeat * 1000, enabled=enabled))
    write(ROOT / 'configs/long_window_plan.json', dict(
        created=time.time(), plan=plan, target_seconds=360, unique_texts=200,
        repeated_arrival_rule='Cycle the frozen 200 distinct W1 prompts. Use unique occurrence IDs and independent request seeds. No cross-request prefix reuse.',
        time_rule='Skip this optional extension if fewer than two GPU hours remain. Stop planning new jobs with fewer than 45 GPU minutes.'))
    resources.stop()
    try:
        for item in plan:
            if remaining() < 2700:
                break
            model, rate, seed = item['model'], item['rate'], item['seed']
            enabled = item['enabled'] and not (ROOT / 'state' / (model + '_B_serving_parity_failure.json')).exists()
            arms = ['DP_Mixed', 'PD_G1'] + (['B'] if enabled else [])
            jobs = {}
            for arm in arms:
                if remaining() < 1800:
                    break
                job = configuration(model, arm, 'W1', item['count'], rate, seed,
                                    gpus=(6, 7), dataset='W1_long',
                                    name=f'{model}_W1_long_{arm}_rate{rate:g}_seed{seed}',
                                    timeout=min(2400, max(1200, item['count'] / rate * 2.5)))
                run(job)
                analyze()
                jobs[arm] = job
            if 'PD_G1' in jobs and 'B' in jobs:
                result = parity(jobs['PD_G1']['name'], jobs['B']['name'])
                write(ROOT / 'state' / ('parity_' + jobs['B']['name'] + '.json'), result)
                if result['N'] != item['count'] or result['exact'] != item['count']:
                    write(ROOT / 'state' / (model + '_B_serving_parity_failure.json'), result)
        write(ROOT / 'state/extended_windows.json', dict(status='COMPLETE_WITH_BUDGET_LIMITS', time=time.time()))
    finally:
        resources.restore()


if __name__ == '__main__':
    main()
