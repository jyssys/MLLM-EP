"""Arrival-based SLO accounting. Unknown values never become measured zeros."""
import csv
import json
from collections import defaultdict
import numpy as np

from .common import ROOT, write
from .jobs import output_rows


def save(name, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with (ROOT / name).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=keys, lineterminator='\n')
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value) if isinstance(value, (list, dict)) else value for key, value in row.items()})


def wilson(correct, total):
    if not total:
        return [None, None]
    p = correct / total
    z = 1.959963984540054
    den = 1 + z * z / total
    center = (p + z * z / (2 * total)) / den
    half = z * np.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / den
    return [100 * (center - half), 100 * (center + half)]


def summarize(job):
    folder = ROOT / 'raw' / job['name']
    status_file = folder / 'status.json'
    state = json.loads(status_file.read_text()) if status_file.exists() else {'status': 'NOT_RUN'}
    rows = output_rows(job['name'])
    base = dict(run=job['name'], model=job['model'], arm=job['arm'], workload=job['workload'],
                GPU_count=len(job['gpus']), physical_GPUs=job['gpus'], P=len(job['gpus']) // 2 if job['arm'] not in ('DP', 'DP_Mixed', 'Native', 'HF') else 0,
                seed=job['seed'], offered_rate=job['rate'], planned_arrivals=job['count'], completed=len(rows),
                status=state['status'], error=state.get('error', ''), output_cap=job['cap'],
                diagnostic=job.get('diagnostic', False), fixed_depth=4 if job['model'] == 'ouro' else 32,
                source='ACTUAL_RLT_GPU_EXECUTION' if rows else 'NOT_MEASURED',
                accepted_lossless_speedup=False)
    percentiles = dict(base)
    for key in ('ttft_ms', 'tpot_ms', 'e2e_ms', 'input_tokens', 'output_tokens', 'delivery_delay_ms'):
        values = [row[key] for row in rows if key in row]
        percentiles[key + '_mean'] = float(np.mean(values)) if values else 'NOT_MEASURED'
        for q in (50, 95, 99):
            percentiles[key + f'_p{q}'] = float(np.percentile(values, q)) if values else 'NOT_MEASURED'
    gaps = [1000 * (event['time'] - event['previous_time']) for row in rows for event in row.get('token_events', []) if not event['first']]
    for q in (50, 95, 99):
        percentiles[f'observed_ITL_ms_p{q}'] = float(np.percentile(gaps, q)) if gaps else 'NOT_MEASURED'
    percentiles['observed_ITL_ms_max'] = max(gaps) if gaps else 'NOT_MEASURED'
    percentiles['coalesced_callbacks'] = sum(event['new_tokens'] > 1 for row in rows for event in row.get('token_events', []))
    percentiles['ITL_definition'] = 'Observed emission gaps. No invented timestamps inside multi-token callbacks.'
    percentiles['p99_scope'] = 'EXPLORATORY_N_LT_100' if len(rows) < 100 else 'One run, not independent-run uncertainty'
    base.update(EOS_stops=sum(row.get('finish_reason') == 'eos' for row in rows),
                cap_stops=sum(row.get('finish_reason') == 'length' for row in rows))
    window_file = folder / 'window.json'
    if window_file.exists():
        window = json.loads(window_file.read_text())
        duration = window['window_seconds']
        span = max(duration, window['actual_span_seconds'])
        base.update(window_seconds=duration, drain_seconds=window['drain_seconds'],
                    cohort_seconds=span, actual_trace_rate=window.get('actual_trace_rate'),
                    completed_throughput_with_drain=len(rows) / span if span > 0 else 'NOT_MEASURED',
                    output_tokens_s_with_drain=sum(row.get('output_tokens', 0) for row in rows) / span if span > 0 else 'NOT_MEASURED')
        base['completed_inside_window_requests_s'] = sum(row['finish'] <= window['evaluation_end'] for row in rows) / duration if duration > 0 else 'NOT_APPLICABLE'
        lock = ROOT / 'configs/slo_lock.json'
        if lock.exists() and duration > 0:
            slo = json.loads(lock.read_text())[job['model']]
            success = []
            for row in rows:
                normal = row['finish_reason'] in ('eos', 'length', 'stop') and row['output_tokens'] > 0
                success.append(normal and row['ttft_ms'] <= slo['TTFT_ms'] and row['tpot_ms'] <= slo['TPOT_ms'])
            n = job['count']
            base.update(TTFT_limit_ms=slo['TTFT_ms'], TPOT_limit_ms=slo['TPOT_ms'],
                        qualified_requests=sum(success), joint_attainment_percent=100 * sum(success) / n,
                        joint_Wilson_95_percent=wilson(sum(success), n),
                        TTFT_attainment_percent=100 * sum(row['ttft_ms'] <= slo['TTFT_ms'] for row in rows) / n,
                        TPOT_attainment_percent=100 * sum(row['tpot_ms'] <= slo['TPOT_ms'] for row in rows) / n,
                        qualified_requests_s_window=sum(success) / duration,
                        qualified_requests_s_with_drain=sum(success) / span,
                        planned_but_incomplete_fraction=max(0, n - len(rows)) / n)
        queue = folder / 'queue.jsonl'
        samples = [json.loads(line) for line in queue.read_text().splitlines()] if queue.exists() else []
        samples = [row for row in samples if not row['warmup'] and duration * .25 <= row['elapsed'] <= duration]
        if len(samples) >= 8 and duration > 0:
            x = np.asarray([row['elapsed'] for row in samples])
            y = np.asarray([row['outstanding'] for row in samples])
            slope = float(np.polyfit(x, y, 1)[0])
            early = float(y[x <= duration * .5].mean()) if any(x <= duration * .5) else float(y[0])
            late = float(y[x >= duration * .75].mean()) if any(x >= duration * .75) else float(y[-1])
            check = slope <= .05 * job['rate'] and late - early <= max(3., .1 * job['rate'] * duration / 4)
            base.update(backlog_slope_requests_s=slope, backlog_early_mean=early, backlog_late_mean=late,
                        weak_queue_check=check,
                        queue_stability='NO_PERSISTENT_GROWTH_OBSERVED' if check and duration >= 300 else 'INSUFFICIENT_DURATION' if check else 'PERSISTENT_GROWTH_SUSPECTED',
                        queue_scope='Outstanding requests include execution. Heuristic is preregistered, not a proof of stationarity.')
    transfer = dict(base)
    after = folder / 'after_measured.json'
    before = folder / 'before_measured.json'
    if after.exists() and before.exists():
        a, b = json.loads(before.read_text()), json.loads(after.read_text())
        for field in ('transport_bytes_sent', 'transport_completed_count', 'transport_completion_observation_seconds', 'issued_loop_rows'):
            if all(isinstance(value, dict) for value in b.values()):
                transfer[field] = sum(value.get(field, 0) - a.get(key, {}).get(field, 0) for key, value in b.items())
    peaks = list(folder.glob('NVML-summary-*.json'))
    if peaks:
        nvml = json.loads(peaks[-1].read_text())
        transfer['sampled_peak_HBM_bytes_by_GPU'] = nvml.get('measured_cohort_peak_sampled_HBM_bytes', {})
    closed = folder / 'closed_stats.json'
    if closed.exists():
        metrics = json.loads(closed.read_text()).get('metrics', [])
        exposed = []
        for row in metrics:
            t = row.get('timings', {})
            if not row['request_id'].startswith('r-1_') and 'd_received' in t and 'prefill_compute_completed' in t:
                exposed.append(1000 * (t['d_received'] - t['prefill_compute_completed']))
        transfer['exposed_handoff_ms_mean'] = float(np.mean(exposed)) if exposed else 'NOT_MEASURED'
        transfer['exposed_handoff_ms_p95'] = float(np.percentile(exposed, 95)) if exposed else 'NOT_MEASURED'
    transfer['transfer_time_scope'] = 'Host-observed cumulative transfer durations can overlap. They are not additive E2E or DMA time.'
    transfer['pure_GPU_attention_FFN_E2E_percent'] = 'NOT_MEASURED'
    return base, percentiles, transfer


def main():
    capacity, latency, transfers = [], [], []
    for path in sorted((ROOT / 'configs/jobs').glob('*.json')):
        job = json.loads(path.read_text())
        if not (ROOT / 'raw' / job['name'] / 'status.json').exists():
            continue
        a, b, c = summarize(job)
        capacity.append(a)
        latency.append(b)
        transfers.append(c)
    save('03_primary_w1_capacity.csv', [row for row in capacity if row['workload'] == 'W1'])
    save('04_latency_percentiles.csv', latency)
    save('05_workload_w2_w3_w4.csv', [row for row in capacity if row['workload'] in ('W2', 'W3', 'W4')])
    save('06_transfer_and_critical_path.csv', transfers)
    save('07_scale_2_4_8gpu.csv', [row for row in capacity if row['workload'] == 'W1'])
    write(ROOT / 'state/current_summary.json', dict(runs=len(capacity), statuses=dict(__import__('collections').Counter(row['status'] for row in capacity))))


if __name__ == '__main__':
    main()
