"""One-variable diagnostic execution variants. The default runtime is untouched."""
import hashlib
import os
from pathlib import Path


def install():
    variant = os.environ.get('B_REPAIR_VARIANT')
    if not variant:
        return
    import torch
    from dataclasses import replace
    from ..looped_pd_abc import worker
    from .common import write
    if getattr(worker, '_B_repair_installed', False):
        return
    worker._B_repair_installed = True
    accepted = ('graph_off', 'async_off', 'streams_off', 'bf16_reduction_off', 'fixed_graph_bucket')
    if variant not in accepted:
        raise ValueError('Unregistered diagnostic repair variant: ' + variant)
    original = worker.configuration

    def configuration(model, width, chunk, graphs=False, asynchronous=False):
        if variant == 'graph_off':
            graphs = False
        if variant == 'async_off':
            asynchronous = False
        value = original(model, width, chunk, graphs, asynchronous)
        if variant == 'streams_off':
            value['execution_config'] = replace(value['execution_config'], multi_stream=False)
        return value

    worker.configuration = configuration
    if variant == 'bf16_reduction_off':
        torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
    if variant == 'fixed_graph_bucket':
        from vllm_rlt.worker import cuda_graph
        from vllm_rlt.config import cuda_graph_rows
        def fixed_capture_sizes(execution, preferred=()):
            return (cuda_graph_rows(execution),)
        cuda_graph.graph_capture_sizes = fixed_capture_sizes
    folder = os.environ.get('B_REPAIR_RUN_DIR')
    if folder:
        write(Path(folder) / f'repair_override_{os.getpid()}.json', dict(
            variant=variant, source_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            BF16_reduced_precision_reduction=torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
            weights_and_tensor_dtype='unchanged BF16', fixed_depth='unchanged',
            scope='Diagnostic variant applied to both control and B. No performance or quality acceptance.'))
