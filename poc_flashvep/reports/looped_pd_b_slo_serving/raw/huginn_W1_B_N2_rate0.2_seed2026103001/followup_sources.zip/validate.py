"""Audit saved evidence without changing inference, raw data, or source pins."""
import hashlib
import json
from pathlib import Path
import zipfile

from .common import ROOT, REPO, MODEL_PINS, write
from .jobs import output_rows
from .analyze import save


def main():
    frozen = json.loads((ROOT / 'configs/heldout_runtime_freeze.json').read_text())['files']
    records = []
    for path in sorted((ROOT / 'configs/jobs').glob('*.json')):
        job = json.loads(path.read_text())
        folder = ROOT / 'raw' / job['name']
        status_path = folder / 'status.json'
        if not status_path.exists():
            continue
        status = json.loads(status_path.read_text())['status']
        rows = output_rows(job['name'])
        record = dict(run=job['name'], status=status, completed_rows=len(rows), planned=job['count'])
        if job.get('reference'):
            record['scope'] = 'Official HF diagnostic. No RLT depth trace is required.'
        else:
            record['unique_sample_ids'] = len({row['sample_id'] for row in rows}) == len(rows)
            record['completed_count_matches_plan'] = len(rows) == job['count'] if status == 'COMPLETE' else 'PARTIAL_OR_FAILED'
            record['full_fixed_output_depth'] = all(len(row['exit_depths']) == row['output_tokens']
                                                   and all(value == MODEL_PINS[job['model']][2] for value in row['exit_depths'])
                                                   for row in rows)
            record['correct_model_revision'] = all(row['model_revision'] == MODEL_PINS[job['model']][1] for row in rows)
            record['TPOT_matches_observed_first_last_tokens'] = all(
                abs(row['tpot_ms'] - (1000 * (row['token_events'][-1]['time'] - row['token_events'][0]['time'])
                                     / (row['output_tokens'] - 1) if row['output_tokens'] >= 2 else 0.)) < 1e-6
                for row in rows if row.get('token_events'))
            expected_gpus = ','.join(map(str, job['gpus']))
            record['GPU_mapping_matches_contract'] = all(row['gpus'] == expected_gpus for row in rows)
            snapshot = folder / 'followup_sources.zip'
            if snapshot.exists():
                with zipfile.ZipFile(snapshot) as archive:
                    for name in ('worker.py', 'common.py'):
                        expected = frozen['poc_flashvep/looped_pd_b_slo_serving/' + name]
                        record[name + '_matches_heldout_freeze'] = hashlib.sha256(archive.read(name)).hexdigest() == expected
                # Qualification predates the last metadata-only freeze.
                record['freeze_test_applies'] = job.get('rate', 0) > 0 and job.get('workload') != 'calibration'
        telemetry = [json.loads(p.read_text()) for p in folder.glob('async_evidence_summary_*.json')]
        record['telemetry_processes_with_summary'] = len(telemetry)
        record['telemetry_error_free'] = all(value.get('error') is None for value in telemetry)
        record['telemetry_all_queued_records_written'] = all(value['enqueued_records'] == value['background_written_records'] for value in telemetry)
        records.append(record)
    save('evidence_validation.csv', records)
    issues = []
    for row in records:
        mandatory = ['unique_sample_ids', 'full_fixed_output_depth', 'correct_model_revision', 'GPU_mapping_matches_contract',
                     'TPOT_matches_observed_first_last_tokens',
                     'telemetry_error_free', 'telemetry_all_queued_records_written']
        if row['status'] == 'COMPLETE':
            mandatory.append('completed_count_matches_plan')
        if row.get('freeze_test_applies'):
            mandatory += ['worker.py_matches_heldout_freeze', 'common.py_matches_heldout_freeze']
        issues += [dict(run=row['run'], invariant=key) for key in mandatory if row.get(key) is False]
    current_source = {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() == expected for name, expected in frozen.items()}
    write(ROOT / 'configs/final_evidence_validation.json', dict(
        run_count=len(records), issues=issues, inference_source_matches_freeze=current_source,
        scope='Saved-evidence integrity and recorded fixed-depth checks. This does not prove original-model fidelity or answer accuracy.'))
    return issues


if __name__ == '__main__':
    main()
