"""Extract real operand and kernel evidence. Structural comparisons stay labeled."""
import csv
import json
from collections import Counter
from .common import ROOT, write


def table(path, rows):
    if not rows:
        return
    with path.open('w') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    evidence = []
    kernels = []
    for folder in sorted((ROOT/'raw').glob('diag256*')):
        for path in folder.glob('fusion_probe_*.json'):
            value = json.loads(path.read_text())
            by_id = {b['id']:b for b in value['batches']}
            for call in value['calls']:
                batch = by_id.get(call['batch_id'])
                if batch is None or not {s['phase'] for s in batch['spans']} >= {'decode', 'prefill'}:
                    continue
                example = dict(run=folder.name, worker_file=path.name, batch_id=batch['id'],
                               logical_rows=batch['rows'], spans=batch['spans'],
                               physical_linear_shapes=call['mm_shapes'],
                               cuda_event_envelope_ms=call['cuda_event_envelope_ms'],
                               evidence='MEASURED_DIAGNOSTIC',
                               scope='Real shared operands, not a replay or an E2E speedup')
                evidence.append(example)
        for path in folder.glob('mixed_core_trace_*.json'):
            events = json.loads(path.read_text())['traceEvents']
            gpu = [e for e in events if e.get('cat') == 'kernel']
            names = Counter(e['name'] for e in gpu)
            linear = [e for e in events if e.get('name') == 'aten::linear' and e.get('ph') == 'X']
            kernels.append(dict(run=folder.name, trace=path.name,
                                kernel_events=len(gpu), linear_operator_events=len(linear),
                                cuda_kernel_duration_sum_ms=sum(e.get('dur',0) for e in gpu)/1000,
                                kernel_names=dict(names),
                                evidence='MEASURED_HEAVY_PROFILE',
                                limitation='One selected mixed core. Kernel durations are not an exclusive E2E partition.'))
    write(ROOT/'operator_fusion_evidence.json', dict(mixed_core_calls=evidence, selected_kernel_traces=kernels))
    print([(v['run'], v['batch_id'], v['logical_rows']) for v in evidence[:10]])
    print([(v['run'], v['kernel_events'], v['linear_operator_events']) for v in kernels])


if __name__ == '__main__':
    main()
