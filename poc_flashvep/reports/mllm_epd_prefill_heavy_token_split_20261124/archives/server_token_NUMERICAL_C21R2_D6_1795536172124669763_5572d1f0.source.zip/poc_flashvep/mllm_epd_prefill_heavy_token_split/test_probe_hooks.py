"""Attention must retain its callable after separate GEMM hooks are installed."""
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch


class ProbeHookTest(unittest.TestCase):
    def test_attention_and_gemm_hooks_keep_independent_originals(self):
        from torch._inductor.select_algorithm import extern_kernels
        from vllm.v1.attention.backends.flash_attn import FlashAttentionImpl
        from . import forward_probe as module
        called=[]
        def attention(*args,**kwargs):called.append('attention');return 'ORIGINAL_ATTENTION'
        def gemm(a,b,c=None,*,out=None):called.append('gemm');return 'ORIGINAL_GEMM'
        class Model:
            def compute_logits(self,*args,**kwargs):return None
        class Runner:
            def __init__(self):self.model=Model();self.kv_caches=[None]*28
            def execute_model(self,*args,**kwargs):return None
            def _model_forward(self,*args,**kwargs):return None
        with TemporaryDirectory() as folder,patch.object(module,'ROOT',Path(folder)), \
                patch.dict(os.environ,MLLM_EPD_ROLE='prefill'), \
                patch.object(FlashAttentionImpl,'forward',attention), \
                patch.object(extern_kernels,'mm',gemm),patch.object(extern_kernels,'addmm',gemm):
            probe=module.ForwardProbe(SimpleNamespace(model_runner=Runner()),'coexisting_hooks',4,
                include_attention=True,include_gemm=True)
            probe.begin()
            try:
                result=FlashAttentionImpl.forward(SimpleNamespace(),SimpleNamespace(layer_name='not-a-selected-layer'),
                    None,None,None,None,None,None)
                self.assertEqual(result,'ORIGINAL_ATTENTION')
                self.assertEqual(called,['attention'])
            finally:
                probe.close()


if __name__=='__main__':unittest.main()
