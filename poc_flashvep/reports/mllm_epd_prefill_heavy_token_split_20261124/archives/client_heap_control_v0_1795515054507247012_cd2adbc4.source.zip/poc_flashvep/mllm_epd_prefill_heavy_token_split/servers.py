"""Run official vLLM servers under a finite, owned GPU lease."""
import argparse
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import time
import urllib.request

from .common import ROOT,REPO,PYTHON,MODEL_ID,resources,write,append,digest,initialize,preserve,experiment_deadline


def command(role,port,ec_path,side_port,observe=False,encoder_native_ops=False,eager_reference=False,compiled_encoder=False,encoder_token_budget=114688,encoder_whole_request=False,encoder_sync_scheduling=False):
    model=json.loads((ROOT/'state/model_download_complete.json').read_text())
    args=[str(PYTHON),'-m','vllm.entrypoints.openai.api_server','--model',model['directory'],
        '--served-model-name',MODEL_ID,'--dtype','bfloat16','--port',str(port),'--host','127.0.0.1',
        '--max-model-len','32768','--max-num-batched-tokens','8192','--max-num-seqs','1024',
        '--kv-cache-memory-bytes',str(42*1024**3),'--block-size','128','--no-enable-prefix-caching',
        '--enable-chunked-prefill','--mm-processor-cache-gb','1','--skip-mm-profiling',
        '--limit-mm-per-prompt',json.dumps(dict(image=256,video=0)),
        '--allowed-local-media-path',str(ROOT/'media'),'--enable-request-id-headers',
        '--generation-config','vllm','--seed','2026112401']
    if role=='encoder':
        assert encoder_token_budget>0
        index=args.index('--max-num-batched-tokens')+1;args[index]=str(encoder_token_budget)
        args+=['--mm-encoder-only']
        if encoder_whole_request:
            args[args.index('--enable-chunked-prefill')]='--no-enable-chunked-prefill'
        if encoder_sync_scheduling:args+=['--no-async-scheduling']
        if not compiled_encoder:args+=['--enforce-eager']
        if encoder_native_ops:args+=['--compilation-config',json.dumps(dict(custom_ops=['none']))]
    if eager_reference:
        assert role=='reference','The eager teacher is a correctness diagnostic, not a weakened serving baseline'
        args+=['--enforce-eager','--compilation-config',json.dumps(dict(custom_ops=['none']))]
    if role in ('encoder','prefill','pd','decode','reference_export'):
        # Use the installed official debug connector. Its CPU staging is not a NIXL EC transfer.
        cfg=dict(ec_connector='ECExampleConnector',ec_role='ec_producer' if role in ('encoder','reference_export') else 'ec_consumer',
            ec_connector_extra_config=dict(shared_storage_path=str(ec_path)))
        if cfg['ec_role']=='ec_consumer':
            cfg.update(ec_connector='StrictExampleConnector',
                ec_connector_module_path='poc_flashvep.mllm_epd_prefill_heavy_token_split.strict_ec')
        args+=['--ec-transfer-config',json.dumps(cfg)]
    if role in ('prefill','decode','reference_prefill','reference_decode'):
        cfg=dict(kv_connector='NixlConnector',kv_role='kv_producer' if role in ('prefill','reference_prefill') else 'kv_consumer')
        args+=['--kv-transfer-config',json.dumps(cfg)]
    if observe:
        args[2]='poc_flashvep.mllm_epd_prefill_heavy_token_split.server_entry'
        args+=['--worker-extension-cls',
            'poc_flashvep.mllm_epd_prefill_heavy_token_split.worker_observer.CampaignWorkerExtension',
            '--middleware','poc_flashvep.mllm_epd_prefill_heavy_token_split.host_timeline.APITimelineMiddleware']
    return args


def serve(name,gpu,role,port,ec_path,side_port,observe=False,encoder_native_ops=False,legacy_runner=False,eager_reference=False,compiled_encoder=False,encoder_token_budget=114688,encoder_whole_request=False,encoder_sync_scheduling=False):
    initialize();owner=resources()
    stop=ROOT/'state'/('stop_server_'+name)
    record=ROOT/'state'/('server_'+name+'.json')
    assert not stop.exists(),'Use a new run name after a prior stop'
    if record.exists():
        old=json.loads(record.read_text());assert old.get('finished'),('Existing lease',name)
    ec_path.mkdir(parents=True,exist_ok=True)
    owner.stop([gpu])
    child=None;request_stop=False;started=time.time();last_sample=0
    def on_signal(*_):
        nonlocal request_stop
        request_stop=True
    signal.signal(signal.SIGTERM,on_signal);signal.signal(signal.SIGINT,on_signal)
    cmd=command(role,port,ec_path,side_port,observe=observe,encoder_native_ops=encoder_native_ops,eager_reference=eager_reference,compiled_encoder=compiled_encoder,encoder_token_budget=encoder_token_budget,encoder_whole_request=encoder_whole_request,encoder_sync_scheduling=encoder_sync_scheduling)
    if observe:
        from .worker_observer import prepare_artifact
        prepare_artifact()
    from .source_snapshot import snapshot
    archived_source=snapshot('server_'+name)
    env=dict(os.environ,PATH=str(PYTHON.parent)+os.pathsep+os.environ.get('PATH',''),
        CUDA_VISIBLE_DEVICES=str(gpu),VLLM_NIXL_SIDE_CHANNEL_PORT=str(side_port),
        OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TOKENIZERS_PARALLELISM='false',VLLM_BATCH_INVARIANT='0',
        VLLM_CACHE_ROOT=str(ROOT/'runtime_cache'/role),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        UCX_NET_DEVICES='all',VLLM_ALLOW_LONG_MAX_MODEL_LEN='1',MLLM_EPD_ROLE=role)
    if legacy_runner:env['VLLM_USE_V2_MODEL_RUNNER']='0'
    else:env.pop('VLLM_USE_V2_MODEL_RUNNER',None)
    ninja=shutil.which('ninja',path=env['PATH'])
    assert ninja,'The actual server PATH must expose the installed ninja binary'
    assert subprocess.run(['ninja','--version'],env=env,capture_output=True).returncode==0
    data=dict(name=name,gpu=gpu,role=role,port=port,EC_path=str(ec_path),command=cmd,
        guardian=os.getpid(),guardian_sid=os.getsid(0),started=started,ready=False,finished=False,legacy_runner=legacy_runner,
        source_SHA256={p.name:digest(p) for p in Path(__file__).parent.glob('*.py')},
        source_archive=archived_source['archive'],source_archive_SHA256=archived_source['archive_SHA256'],
        GPU_info=subprocess.check_output(['nvidia-smi','-i',str(gpu),
            '--query-gpu=index,uuid,name,memory.total','--format=csv,noheader'],text=True),
        compiler_preflight=dict(ninja=ninja,passed=True),
        environment={k:env[k] for k in ('PATH','CUDA_VISIBLE_DEVICES','VLLM_NIXL_SIDE_CHANNEL_PORT','OMP_NUM_THREADS',
            'MKL_NUM_THREADS','VLLM_BATCH_INVARIANT','VLLM_CACHE_ROOT')},
        observer='Inactive fixed RPC endpoints plus NVML. CUPTI/state hooks require an explicit begin/end and CPC gate.'
            if observe else 'NVML only. Not a kernel-busy or GPU-exclusive measurement.')
    try:
        with (ROOT/'logs'/('server_'+name+'.log')).open('ab') as log:
            child=subprocess.Popen(cmd,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        data['pid']=child.pid;data['sid']=os.getsid(child.pid);write(record,data)
        append(ROOT/'resource_ledger.jsonl',dict(action='START_OWNED_SERVER',time=time.time(),**data))
        while child.poll() is None and not request_stop and not stop.exists() and time.time()<experiment_deadline():
            if not data['ready']:
                try:
                    with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=1) as reply:
                        if reply.status==200:
                            data['ready']=True;data['ready_time']=time.time();write(record,data)
                except Exception:pass
                if time.time()-started>1500:raise TimeoutError('Server initialization exceeded 25 minutes')
            if time.time()-last_sample>=2:
                last_sample=time.time()
                sample=subprocess.run(['nvidia-smi','-i',str(gpu),
                    '--query-gpu=timestamp,uuid,utilization.gpu,utilization.memory,memory.used,power.draw,temperature.gpu',
                    '--format=csv,noheader,nounits'],capture_output=True,text=True)
                append(ROOT/'raw'/('NVML_'+name+'.jsonl'),dict(time=time.time(),value=sample.stdout.strip()))
            time.sleep(.5)
        data['returncode']=child.poll();data['stop_requested']=request_stop or stop.exists()
    except BaseException as error:
        data['error']=type(error).__name__+': '+str(error)
        raise
    finally:
        if child is not None and child.poll() is None:
            proc=Path('/proc')/str(child.pid)
            assert proc.stat().st_uid==os.getuid() and os.getsid(child.pid)==data['sid']==child.pid
            assert cmd[2].encode() in (proc/'cmdline').read_bytes()
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=35)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=15)
        data['finished']=True;data['finished_time']=time.time();write(record,data)
        until=time.time()+45
        while any(r['gpu']==gpu for r in owner.processes()) and time.time()<until:time.sleep(.5)
        if not any(r['gpu']==gpu for r in owner.processes()):owner.restore([gpu])
        else:append(ROOT/'resource_ledger.jsonl',dict(action='RESTORE_DEFERRED_GPU_OCCUPIED',gpu=gpu,time=time.time()))
        preserve()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['start','serve','stop','status'])
    parser.add_argument('--name',required=True);parser.add_argument('--gpu',type=int,default=3)
    parser.add_argument('--role',choices=['reference','reference_export','reference_prefill','reference_decode','agg','encoder','prefill','decode','pd'],default='reference')
    parser.add_argument('--port',type=int,default=18303);parser.add_argument('--side-port',type=int,default=19303)
    parser.add_argument('--ec-path',type=Path,default=Path('/dev/shm/mllm_epd_20261124_calibration'))
    parser.add_argument('--observe',action='store_true')
    parser.add_argument('--encoder-native-ops',action='store_true')
    parser.add_argument('--legacy-runner',action='store_true')
    parser.add_argument('--eager-reference',action='store_true')
    parser.add_argument('--compiled-encoder',action='store_true')
    parser.add_argument('--encoder-token-budget',type=int,default=114688)
    parser.add_argument('--encoder-whole-request',action='store_true')
    parser.add_argument('--encoder-sync-scheduling',action='store_true')
    args=parser.parse_args()
    if args.action=='start':
        with (ROOT/'logs'/('guardian_'+args.name+'.log')).open('ab') as log:
            command=[str(PYTHON),'-m','poc_flashvep.mllm_epd_prefill_heavy_token_split.servers','serve',
                '--name',args.name,'--gpu',str(args.gpu),'--role',args.role,'--port',str(args.port),
                '--side-port',str(args.side_port),'--ec-path',str(args.ec_path)]
            if args.observe:command+=['--observe']
            if args.encoder_native_ops:command+=['--encoder-native-ops']
            if args.legacy_runner:command+=['--legacy-runner']
            if args.eager_reference:command+=['--eager-reference']
            if args.compiled_encoder:command+=['--compiled-encoder']
            if args.encoder_whole_request:command+=['--encoder-whole-request']
            if args.encoder_sync_scheduling:command+=['--encoder-sync-scheduling']
            command+=['--encoder-token-budget',str(args.encoder_token_budget)]
            child=subprocess.Popen(command,cwd=REPO,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps(dict(guardian=child.pid,name=args.name)))
    elif args.action=='serve':serve(args.name,args.gpu,args.role,args.port,args.ec_path,args.side_port,args.observe,args.encoder_native_ops,args.legacy_runner,args.eager_reference,args.compiled_encoder,args.encoder_token_budget,args.encoder_whole_request,args.encoder_sync_scheduling)
    elif args.action=='stop':
        write(ROOT/'state'/('stop_server_'+args.name),dict(time=time.time()))
    else:print((ROOT/'state'/('server_'+args.name+'.json')).read_text())


if __name__=='__main__':main()
