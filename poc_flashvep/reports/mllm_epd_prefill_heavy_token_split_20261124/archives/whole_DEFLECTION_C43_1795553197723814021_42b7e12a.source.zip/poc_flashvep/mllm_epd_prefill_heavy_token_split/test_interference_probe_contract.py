"""The optional decode probe must retain the original Native command and NIXL connector."""
import json
from pathlib import Path
import unittest


class ProbeRuntimeContractTest(unittest.TestCase):
    def test_probe_flag_keeps_original_model_compiler_and_connector_command(self):
        from .servers import command
        kwargs=dict(observe=True,ec_transport='cuda_ipc',fixed_reduction=True,deterministic_reductions=True)
        native=command('decode',18842,Path('/dev/shm/probe-contract-unused'),19842,**kwargs)
        probe=command('decode',18842,Path('/dev/shm/probe-contract-unused'),19842,prefix_probe=True,**kwargs)
        self.assertEqual(native,probe)
        connector=json.loads(probe[probe.index('--kv-transfer-config')+1])
        self.assertEqual(connector['kv_connector'],'NixlConnector')
        self.assertEqual(connector['kv_role'],'kv_consumer')
        self.assertNotIn('--enforce-eager',probe)
        self.assertEqual(probe[probe.index('--dtype')+1],'bfloat16')
        with self.assertRaises(AssertionError):
            command('prefill',18841,Path('/dev/shm/probe-contract-unused'),19841,prefix_probe=True,**kwargs)


if __name__=='__main__':unittest.main()
