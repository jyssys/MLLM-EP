"""One clean/event/clean Native control with no candidate insertion."""
import asyncio
import json
import os
from pathlib import Path
import time
from types import SimpleNamespace

from .client import resolve_manifest
from .common import ROOT,digest,preserve,write,experiment_deadline
from .frontend_supply_control import retire
from .ipc_ec_control import launch,stop_proxy,correctness,ownership_empty
from .llm_probe_control import rpc
from .native_inline_confirmation import measure,REFERENCE,URL
from .profile_control import run as profile_run
from .source_snapshot import snapshot

TAG='ec_GPU_ENCLOSURES_C19'


def main():
    preserve()
    path=ROOT/'configs'/f'{TAG}.json';assert not path.exists()
    source=snapshot(TAG)
    write(path,dict(time=time.time(),status='FROZEN_BEFORE_OBSERVER_RESULTS',
        source_archive_SHA256=source['archive_SHA256'],QPS=2,requests=100,
        one_factor='Replace full CUPTI activity recording with two CUDA events per original model-runner execute.',
        unchanged=['Original stock compiled Native model','Main100','Natural-derived fixed replay counts',
                   'Arrival/order seeds','EC transport and ACK','B8192/S1024','KV42GiB','Frozen SLO'],
        evidence='DIAGNOSTIC until clean/profile/clean qualification',observer_gate_max=.05,
        limitation='GPU stream enclosures are not kernel-exclusive busy. Extra-stream transfers may be uncovered.',
        no_candidate_offloading=True,no_safe_headroom_claim=True))
    while True:
        leases=[json.loads((ROOT/'state'/f'server_token_CORRECTNESS_C15R2_{role}{gpu}.json').read_text())
                for role,gpu in [('E',4),('P',5),('D',6)]]
        if all(r['finished'] and not Path('/proc',str(r['guardian'])).exists() for r in leases):break
        for r in leases:
            proc=Path('/proc',str(r['guardian']))
            if proc.exists():
                assert proc.stat().st_uid==os.getuid()
                assert b'mllm_epd_prefill_heavy_token_split.servers' in (proc/'cmdline').read_bytes()
        assert time.time()<experiment_deadline()
        time.sleep(1)
    expected=[f'{TAG}_{role}{gpu}' for role,gpu in [('E',4),('P',5),('D',6)]]
    proxy=None
    try:
        names,proxy=launch(TAG,'cuda_ipc');assert names==expected
        for port in [18841,18842]:rpc(port,'ec_ipc/ack_policy',dict(mode='file'))
        rpc(18840,'ec_ipc/inline_policy',dict(enabled=True))
        asyncio.run(correctness(TAG,'cuda_ipc'))
        asyncio.run(measure(TAG,'warmup_replay100',2))
        args=SimpleNamespace(manifest=resolve_manifest(None),replay_from=REFERENCE,
            server_names=','.join(names),order_seed=2026112404,qps=2,seed=2026112402,
            name=TAG+'_CPC_q2_v0',url=URL,
            worker_urls='http://127.0.0.1:18840,http://127.0.0.1:18841,http://127.0.0.1:18842',
            observer_kind='gpu_enclosures',state_interval_ms=50,
            observe_client_host=False,freeze_client_static_heap=False)
        asyncio.run(profile_run(args));ownership_empty(TAG,'cuda_ipc')
        write(ROOT/'state'/f'{TAG}_complete.json',dict(time=time.time(),status='COMPLETE',
            qualification_SHA256=digest(ROOT/'analysis'/f'{args.name}_qualification.json')))
    except BaseException as error:
        write(ROOT/'state'/f'{TAG}_failure.json',dict(time=time.time(),status='FAILED_EXECUTION',
            error=type(error).__name__+': '+str(error)))
        raise
    finally:
        if proxy is not None:stop_proxy(proxy)
        owned=[n for n in expected if (ROOT/'state'/f'server_{n}.json').exists()]
        if owned:
            retire([n for n in owned if '_E4' not in n]);retire([n for n in owned if '_E4' in n])
    preserve()


if __name__=='__main__':main()
