"""Paired starts, not request or token observations, set uncertainty."""
import unittest


class PairedIntervalTest(unittest.TestCase):
    def test_constant_paired_effect_is_exact_under_varying_start_costs(self):
        from .token_confirmation_analysis import paired_interval
        result=paired_interval([9.,18.,90.],[10.,20.,100.])
        self.assertAlmostEqual(result['ratio_of_start_means'],.9)
        self.assertTrue(all(abs(v-.9)<1e-12 for v in result['paired_start_bootstrap95_CI']))
        self.assertEqual(result['independent_start_pairs'],3)
        self.assertEqual(result['empirical_resamples'],27)

    def test_reject_request_count_as_independent_start_count(self):
        from .token_confirmation_analysis import paired_interval
        with self.assertRaises(AssertionError):paired_interval([1.]*100,[1.]*100)


if __name__=='__main__':unittest.main()
