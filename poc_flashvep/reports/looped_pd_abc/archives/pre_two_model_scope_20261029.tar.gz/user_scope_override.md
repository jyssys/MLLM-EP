# User scope override: Ouro and Huginn

The user changed the active model scope on 2026-10-29.
This instruction supersedes the original specification's three-model requirement for future work.
The original specification remains unchanged.

## Active work

| Model | Engine | Fixed depth | Status |
|---|---|---:|---|
| Dense Ouro-1.4B Base | Private pinned vLLM-RLT | R4 | Active |
| Dense Huginn-0125 | Private pinned vLLM-RLT | R32 | Active |
| Dense Dory BF16 | Existing RLT adapter | R2 | Deferred by user |

Both active models retain BF16 and their original checkpoint revisions.
The A, B, and C experiments remain independent.
The GPU budgets remain 2, 4, and 8 on physical GPUs 0–7.
The engine-matched performance baseline remains vLLM-RLT.
No new Native vLLM performance campaign starts for this scope change.
Existing original-reference comparisons remain evidence and limitations.

## Preservation and scheduling

`configs/model_scope.json` controls new scheduling.
The dispatcher checks this scope before it starts a job.
It also checks the scope between completed jobs.
Completed valid cases remain skipped on resume.

The previous scheduler loaded its pending list before the user instruction.
Changing its manifest alone could not remove jobs from that in-memory list.
The experiment therefore replaced the scheduling controllers.
No inference worker received a termination or pause signal.
The already-started Dory job could finish normally.

All Dory code, checkpoints, source archives, outputs, and failure logs remain available.
Deferral is not a quality failure or a NO-GO decision.
Historical Dory measurements can remain in the raw inventory.
They do not enter the active two-model decision board.

`archives/pre_two_model_scope_20261029.tar.gz` preserves the earlier derived reports and manifests.
The new primary decision matrix contains two models, three tracks, and three GPU budgets.
It therefore has 18 model/track/budget rows, not the original 27.

## Resume

`resume_campaign.py --from-phase C` resumes the current controller checkpoint.
It first waits for any existing inference worker to finish.
It then runs the remaining C prerequisites, the C comparison, scaling, and short profiles.
It does not repeat completed model qualification or valid timing cases.

The new CPU scope tests cover model filtering, preserved raw results, and all three GPU budgets.
They also check that an empty resume does not change GPU or burner state.
Model execution and the locked evidence recorder remain unchanged.
The final GO thresholds and correctness requirements do not change.
