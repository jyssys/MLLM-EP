"""Host critical-path partitions and explicitly frozen-timeline transfer oracles."""
import csv
from collections import defaultdict
import numpy as np
from .common import ROOT
from .analyze import save_csv

PHASES=('coordinator_queue','reservation_control','P_assigned_prefill_including_backpressure',
 'uncovered_handoff','D_resume_coda_first_token','remaining_decode_phase','harness_delivery_poll_residual')

def partition_statistics(records):
 """The denominator is summed request wall time, not GPU execution time."""
 valid=[]
 for row in records:
  if str(row.get('phase_order_valid')).lower()!='true':continue
  if not all(row.get(name+'_ms') not in (None,'') for name in PHASES):continue
  elapsed=float(row['harness_E2E_ms'])
  values=[float(row[name+'_ms']) for name in PHASES]
  if elapsed<=0 or any(x<0 for x in values):continue
  if not np.isclose(sum(values),elapsed,rtol=1e-10,atol=1e-6):
   raise ValueError('Host partition does not equal harness E2E')
  valid.append((elapsed,values))
 if not valid:return []
 elapsed=np.asarray([x for x,y in valid]);values=np.asarray([y for x,y in valid])
 return [dict(phase=name,N=len(valid),phase_mean_ms=float(values[:,i].mean()),
  phase_p95_ms=float(np.percentile(values[:,i],95)),
  share_of_summed_request_E2E_percent=float(100*values[:,i].sum()/elapsed.sum()),
  mean_request_share_percent=float(np.mean(100*values[:,i]/elapsed)),
  evidence='MEASURED_HOST_CRITICAL_PATH_PARTITION',
  denominator='Sum of harness arrival-to-final-output request times in this run',
  limitation='Concurrent requests overlap. These shares are not GPU utilization, DMA shares, or additive cohort makespan components.')
  for i,name in enumerate(PHASES)]

def fixed_timeline_oracle(records):
 """Remove only the observed post-P handoff interval. No schedule is replayed."""
 before=[];after=[];tails=[]
 for row in records:
  if str(row.get('phase_order_valid')).lower()!='true':continue
  if not row.get('harness_E2E_ms'):continue
  elapsed=float(row['harness_E2E_ms']);tail=float(row['uncovered_handoff_ms'])
  if not 0<=tail<elapsed:continue
  before.append(elapsed);after.append(elapsed-tail);tails.append(tail)
 if not before:return None
 original=float(np.percentile(before,95));counterfactual=float(np.percentile(after,95))
 return dict(N=len(before),observed_p95_E2E_ms=original,
  removed_handoff_mean_ms=float(np.mean(tails)),removed_handoff_p95_ms=float(np.percentile(tails,95)),
  frozen_timeline_p95_E2E_ms=counterfactual,frozen_timeline_p95_ratio=original/counterfactual,
  evidence='ORACLE_FROZEN_TIMELINE_NOT_MEASURED_SPEEDUP',
  assumptions='Erase the entire observed post-P handoff interval. Retain every other request interval unchanged.',
  limitation='This is not a global serving bound. It omits queue feedback, CPU backpressure, contention, new metadata, and transfer scheduling changes.')

def main():
 source=ROOT/'e2e_phase_breakdown.csv'
 if not source.exists():return
 groups=defaultdict(list)
 with source.open() as stream:
  for row in csv.DictReader(stream):groups[row['name']].append(row)
 shares=[];oracles=[]
 for name,records in sorted(groups.items()):
  for row in partition_statistics(records):shares.append(dict(run=name,**row))
  row=fixed_timeline_oracle(records)
  if row:oracles.append(dict(run=name,**row))
 save_csv(ROOT/'e2e_phase_percent_summary.csv',shares)
 save_csv(ROOT/'handoff_frozen_timeline_oracle.csv',oracles)

if __name__=='__main__':main()
