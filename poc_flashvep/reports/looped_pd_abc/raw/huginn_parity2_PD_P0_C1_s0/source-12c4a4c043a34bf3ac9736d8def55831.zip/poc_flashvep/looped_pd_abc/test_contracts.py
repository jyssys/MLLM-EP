"""CPU contract tests. These tests are not model or GPU performance evidence."""
from .boundary import valid_segments
from .common import MODEL_PINS
from .worker import prompts

def info():
 return dict(num_layers=4,block_size=16,key_ptr=0,value_ptr=1000000,
  block_bytes=4*16*8,layer_bytes=16*8,token_bytes=8,device=0)

def test_boundary_does_not_ship_unused_depth_planes():
 tables=((0,1),(2,3),(4,5))
 rows=list(valid_segments(info(),tables,0,19,(1,2),(3,),19))
 assert sum(size for ptr,size,device in rows)==(19*(1+2*3)+18)*8*2

def test_unaligned_range_has_no_missing_tokens():
 rows=list(valid_segments(info(),((0,1),),3,21,(1,2),(3,),22))
 assert sum(size for ptr,size,device in rows)==18*4*8*2

def test_coalescing_preserves_exact_address_coverage():
 from .segments import coalesce
 a,b=coalesce([(8,8,0),(0,8,0),(32,8,0)],[(108,8,1),(100,8,1),(132,8,1)])
 assert a==[(0,16,0),(32,8,0)] and b==[(100,16,1),(132,8,1)]

def test_dory_prompt_contains_integer_token_ids():
 rows=prompts('dory',2,0)
 assert len(rows)==2 and all(type(x) is int and 0<=x<131072 for row in rows for x in row)

def test_declared_fixed_depths_preserve_checkpoint_defaults():
 assert [MODEL_PINS[x][2] for x in ('ouro','huginn','dory')]==[4,32,2]

def test_split_frontier_is_a_real_prefix():
 from vllm_rlt.request import Request
 for R,cut in ((4,2),(32,16),(2,1)):
  ranges=Request.prefill_boundaries(128,R)
  for depth in range(cut):
   ranges[depth][0]=128;ranges[depth+1][1]=128
  assert all(left==128 for left,right in ranges[:cut])
  assert ranges[cut]==[0,128]
