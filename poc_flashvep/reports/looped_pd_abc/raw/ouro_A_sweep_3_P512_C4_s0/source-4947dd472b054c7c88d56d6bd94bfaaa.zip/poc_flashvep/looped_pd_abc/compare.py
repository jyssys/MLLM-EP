"""Analyze completed GPU runs. Bootstrap intervals do not replace fidelity gates."""
import argparse
import json
import numpy as np
from .common import ROOT,write
from .analyze import load_rows,requests,save_csv,summarize

def complete(folder):
 path=folder/'status.json'
 return path.exists() and json.loads(path.read_text()).get('status')=='COMPLETE'

def wilson(correct,total):
 if not total:return [None,None]
 z=1.959963984540054;p=correct/total;d=1+z*z/total
 center=(p+z*z/(2*total))/d
 half=z*np.sqrt(p*(1-p)/total+z*z/(4*total*total))/d
 return [100*(center-half),100*(center+half)]

def agreement(left,right):
 a={r['sample_id']:r for r in left};b={r['sample_id']:r for r in right}
 ids=sorted(a.keys()&b.keys());exact=lengths=inputs=depths=0;divergences=[]
 for i in ids:
  x=a[i];y=b[i];u=x['output_ids'];v=y['output_ids']
  exact+=u==v;lengths+=len(u)==len(v);inputs+=x['input_ids']==y['input_ids']
  if 'exit_depths' in x and 'exit_depths' in y:depths+=x['exit_depths']==y['exit_depths']
  if u!=v:
   first=next((j for j,(p,q) in enumerate(zip(u,v)) if p!=q),min(len(u),len(v)))
   divergences.append(dict(sample_id=i,first_mismatch=first,left_length=len(u),right_length=len(v)))
 return dict(N=len(ids),exact=exact,length_equal=lengths,input_equal=inputs,depth_equal=depths,
  agreement_percent=100*exact/len(ids) if ids else None,wilson_95_percent=wilson(exact,len(ids)),
  first_divergences=divergences)

def reference_checks():
 result=[]
 for model,version,refname in [('ouro','parity','ouro_HF_4576_natural100'),
   ('huginn','parity2','huginn_HF_4576_natural100'),('dory','parity3','dory_official_B1_100')]:
  # The recorded Dory reference name is discovered, not assumed.
  if model=='dory':
   candidates=[p for p in (ROOT/'raw').iterdir() if 'dory' in p.name and 'official' in p.name and complete(p)]
   candidates=[p for p in candidates if len(load_rows(p/'requests.jsonl'))==100]
   if not candidates:continue
   refname=sorted(candidates,key=lambda p:p.name)[0].name
  native=ROOT/'raw'/f'{model}_{version}_native_P0_C1_s0';reference=ROOT/'raw'/refname
  if not complete(native) or not complete(reference):continue
  a=requests(native);b=load_rows(reference/'requests.jsonl')
  row=agreement(a,b);detail=row.pop('first_divergences')
  row.update(model=model,native=native.name,reference=refname,evidence='MEASURED_BOUNDED_REFERENCE_GENERATION',
   output_cap=32,downstream_accuracy='NOT_MEASURED',reference_equal=row['exact']==row['N'])
  result.append(row);write(ROOT/'state'/f'{model}_reference_divergences.json',detail)
 save_csv(ROOT/'reference_agreement.csv',result)
 transfer=[]
 for folder in sorted((ROOT/'raw').glob('*KV_identity*')):
  rows=[r for f in folder.glob('KV_checks*.jsonl') for r in load_rows(f)]
  for i,r in enumerate(rows):
   transfer.append(dict(run=folder.name,check=i,passed=r['passed'],
    KV_valid_bytes=r['actual']['KV_valid_bytes'],hidden_bytes=r['actual']['hidden_bytes'],
    evidence=r['evidence'],includes_warmup=True))
 save_csv(ROOT/'transfer_identity.csv',transfer)
 return result

def bootstrap(blocks,metric='e2e_ms',quantile=95,samples=3000,seed=20261029):
 """Resample independent starts, then paired request IDs inside each start."""
 rng=np.random.default_rng(seed);values=[]
 arrays=[(np.asarray([a[metric] for a,b in block]),np.asarray([b[metric] for a,b in block])) for block in blocks]
 if not arrays:return dict(speedup=None,ci95=None)
 left=np.concatenate([a for a,b in arrays]);right=np.concatenate([b for a,b in arrays])
 ratio=float(np.percentile(left,quantile)/np.percentile(right,quantile))
 for _ in range(samples):
  p=[];q=[]
  for j in rng.integers(0,len(arrays),len(arrays)):
   a,b=arrays[j];ids=rng.integers(0,len(a),len(a));p.extend(a[ids]);q.extend(b[ids])
  values.append(np.percentile(p,quantile)/np.percentile(q,quantile))
 return dict(speedup=ratio,ci95=np.percentile(values,[2.5,97.5]).tolist())

def paired_runs(model,base,method,length,concurrency,kind='serving'):
 blocks=[];exact=total=length_equal=0;raw_pairs=[]
 for repeat in range(3):
  names=[f'{model}_{label}_P{length}_C{concurrency}_s{repeat}' for label in (base,method)]
  folders=[ROOT/'raw'/name for name in names]
  if not all(complete(p) for p in folders):continue
  a,b=[{r['sample_id']:r for r in requests(p)} for p in folders]
  ids=sorted(a.keys()&b.keys())
  if not ids or len(ids)!=len(a) or len(ids)!=len(b):continue
  if not all(a[i]['input_ids']==b[i]['input_ids'] for i in ids):continue
  blocks.append([(a[i],b[i]) for i in ids]);total+=len(ids)
  exact+=sum(a[i]['output_ids']==b[i]['output_ids'] for i in ids)
  length_equal+=sum(a[i]['output_tokens']==b[i]['output_tokens'] for i in ids)
  raw_pairs.append(names)
 if not blocks:return None
 E=bootstrap(blocks);T=bootstrap(blocks,'ttft_ms')
 return dict(model=model,kind=kind,baseline=base,candidate=method,input_tokens=length,concurrency=concurrency,
  starts=len(blocks),N=total,exact_outputs=exact,length_equal=length_equal,
  output_agreement_percent=100*exact/total,p95_E2E_speedup=E['speedup'],p95_E2E_speedup_ci95=E['ci95'],
  p95_TTFT_speedup=T['speedup'],p95_TTFT_speedup_ci95=T['ci95'],
  strict_same_output=exact==total,accepted_independent_starts=len(blocks)>=3,
  evidence='MEASURED_WITH_PAIRED_HIERARCHICAL_BOOTSTRAP',raw_pairs=raw_pairs,
  limitation='Closed-loop bounded natural generation. This is not sustainable open-loop capacity.')

def comparisons():
 output=[]
 for model in ('ouro','huginn','dory'):
  for length,width in ((128,1),(512,4),(2048,8)):
   for method in ('A','B'):
    for base in ('DP','DP_Mixed','PD','PD_G1'):
     row=paired_runs(model,base,method,length,width)
     if row:output.append(row)
  for base in ('C_upstream','C_queue','C_token','C_service','C_DP4','C_DP4_Mixed','C_PD1','C_PD3'):
   row=paired_runs(model,base,'C_loop',0,8,kind='C')
   if row:output.append(row)
 save_csv(ROOT/'paired_comparisons.csv',output)
 return output

def slo_results():
 path=ROOT/'configs/frozen_slo.json'
 if not path.exists():return []
 grid=json.loads(path.read_text());rows=[]
 for folder in sorted((ROOT/'raw').iterdir()):
  if not folder.is_dir() or not complete(folder):continue
  raw=requests(folder)
  if not raw or 'token_events' not in raw[0]:continue
  model=raw[0]['model']
  if model not in grid:continue
  span=max(x['finish'] for x in raw)-min(x['arrival'] for x in raw)
  for level,limit in grid[model]['ITL_thresholds_ms'].items():
   for ttft in grid[model]['TTFT_grid_ms']:
    passed=[]
    for x in raw:
     intervals=[1000*(e['time']-e['previous_time']) for e in x['token_events'] if not e['first'] and e['new_tokens']==1]
     normal=x['finish_reason'] in ('eos','length','stop') and x['output_tokens']>0
     passed.append(normal and x['ttft_ms']<=ttft and max(intervals,default=0)<=limit and x['e2e_ms']<=grid[model]['E2E_limit_ms'])
    count=sum(passed)
    rows.append(dict(run=folder.name,model=model,level=level,ITL_limit_ms=limit,TTFT_limit_ms=ttft,
     E2E_limit_ms=grid[model]['E2E_limit_ms'],correct_completions=count,N=len(raw),
     attainment_percent=100*count/len(raw),wilson_95_percent=wilson(count,len(raw)),
     SLO_goodput_requests_s=count/span,evidence='MEASURED_BOUNDED_REQUEST_SLO',
     sustainable_capacity='NOT_MEASURED' if not raw[0].get('arrival_rate') else 'REQUIRES_QUEUE_STABILITY_AND_RATE_SWEEP',
     length_terminations=sum(x['finish_reason']=='length' for x in raw),
     completion_scope='A length termination is valid only for this bounded workload. It does not establish answer completeness.'))
 save_csv(ROOT/'slo_results.csv',rows);return rows

def contention_results():
 data=[]
 for folder in sorted((ROOT/'raw').glob('ouro_contention*')):
  if not complete(folder):continue
  raw=requests(folder)
  if raw:data.append(dict(run=folder.name,gpus=raw[0]['gpus'],requests=len(raw),
   E2E_mean_ms=float(np.mean([r['e2e_ms'] for r in raw])),
   TPOT_mean_ms=float(np.mean([r['tpot_ms'] for r in raw])),
   evidence='MEASURED_CONTENDING_LANES' if 'parallel' in folder.name else 'MEASURED_ISOLATED_LANE'))
 save_csv(ROOT/'contention.csv',data);return data

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--comparisons',action='store_true');args=parser.parse_args()
 summarize();reference_checks();slo_results();contention_results()
 if args.comparisons:comparisons()

if __name__=='__main__':main()
