"""One bounded official-reference probe on an otherwise unused GPU."""
import argparse
import os
import subprocess
from .common import ROOT,REPO,environment,record_command
from . import resources

def main():
 p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--gpu',type=int,required=True);a=p.parse_args()
 name=a.model+'_HF_4576_reference';g=[a.gpu]
 resources.base.stop(g)
 try:
  command=['/home/esjung/.venvs/looped-pd-abc-hf457/bin/python','-m','poc_flashvep.looped_pd_abc.reference_probe',
   '--model',a.model,'--name',name,'--requests','4','--length','128','--cap','8']
  with (ROOT/'logs'/(name+'.log')).open('a') as f:
   child=subprocess.Popen(command,cwd=REPO,env=environment(g),stdout=f,stderr=subprocess.STDOUT)
   record_command(name,command,g,child.pid);result=child.wait()
  print(name,result,flush=True)
 finally:resources.base.restore(g)

if __name__=='__main__':main()
