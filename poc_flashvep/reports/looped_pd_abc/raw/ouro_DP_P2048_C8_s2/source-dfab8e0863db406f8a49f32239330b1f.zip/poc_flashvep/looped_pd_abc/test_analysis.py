"""CPU checks for report accounting. No GPU inference occurs here."""
import pytest
from .critical_path_analysis import PHASES,partition_statistics,fixed_timeline_oracle

def record(elapsed,values):
 return dict(phase_order_valid=True,harness_E2E_ms=elapsed,
  **{name+'_ms':value for name,value in zip(PHASES,values)})

def test_host_partition_has_one_explicit_denominator():
 rows=[record(100,[10,10,10,10,10,40,10]),record(200,[0,0,0,0,0,200,0])]
 result=partition_statistics(rows)
 assert sum(r['share_of_summed_request_E2E_percent'] for r in result)==pytest.approx(100)
 assert result[0]['share_of_summed_request_E2E_percent']==pytest.approx(100/30)
 assert result[0]['mean_request_share_percent']==pytest.approx(5)

def test_host_partition_rejects_a_missing_interval():
 with pytest.raises(ValueError,match='does not equal'):
  partition_statistics([record(100,[1,1,1,1,1,1,1])])

def test_fixed_timeline_oracle_does_not_remove_prefill_or_decode():
 rows=[record(100,[10,10,10,20,10,30,10])]
 result=fixed_timeline_oracle(rows)
 assert result['frozen_timeline_p95_E2E_ms']==80
 assert result['frozen_timeline_p95_ratio']==1.25
 assert result['evidence']=='ORACLE_FROZEN_TIMELINE_NOT_MEASURED_SPEEDUP'

def test_invalid_order_is_not_silently_clamped():
 row=record(100,[0,0,0,-10,0,110,0]);row['phase_order_valid']=False
 assert partition_statistics([row])==[]
 assert fixed_timeline_oracle([row]) is None

def test_q1_bf16_posthoc_selection_is_not_guaranteed_to_choose_R4():
 import torch
 from .ouro_gate_audit import q1_posthoc_selection
 # These are synthetic inputs, not a measured checkpoint gate distribution.
 inputs=[torch.full((1,1,1),2.2) for _ in range(4)]
 fp32,cdf32=q1_posthoc_selection(inputs)
 bf16,cdf16=q1_posthoc_selection([x.to(torch.bfloat16) for x in inputs])
 assert fp32.item()==3 and bf16.item()==2
 assert cdf32[0,0,2]<1 and cdf16[0,0,2]==1

def test_shadow_routing_preserves_the_actual_state_dictionary(monkeypatch,tmp_path):
 import json,time
 from types import SimpleNamespace as NS
 from . import placement,shadow_worker,workload_worker
 monkeypatch.setattr(placement,'install',placement.install)
 monkeypatch.setattr(shadow_worker,'ROOT',tmp_path)
 monkeypatch.setenv('ABC_MANIFEST_RUN','shadow_test')
 request=NS(request_id='old',prompt_token_ids=list(range(128)),generated_token_ids=[],sampling_params=NS(max_tokens=32))
 active=NS(request=request,p='P',d='D',p_released=False,d_released=False,created=time.monotonic(),
  timings={'prefill_started':0.},loop_frontiers=[[64,128],[0,64],[0,0],[0,0]])
 engine=NS(model_config=NS(model_type='ouro',total_ut_steps=4),transfers={'old':active})
 peer=NS(name='P',role='prefill',client=NS(info={'max_active_requests':8,'num_blocks':4096}),reserved_blocks=10,slots=1)
 original=engine.transfers
 def fake_workload():
  placement.install(engine,'loop',tmp_path/'raw/shadow_test/placements.jsonl')
  score=engine.placement_key(peer,NS(request=NS(request_id='new')))
  assert score[0]>=0 and engine.transfers is original and engine.transfers['old'] is active
 monkeypatch.setattr(workload_worker,'main',fake_workload)
 shadow_worker.main()
 row=json.loads((tmp_path/'raw/shadow_test/shadow_states.jsonl').read_text())
 assert set(row['scores'])=={'queue','token','service','loop'}
 assert row['states'][0]['completed_prefill_frontiers']==active.loop_frontiers

def test_generic_transport_wrapper_returns_the_actual_PDConfig(monkeypatch,tmp_path):
 import vllm_rlt.pd as pd
 from . import transport_worker,worker
 original=pd.PDConfig
 monkeypatch.setattr(transport_worker,'ROOT',tmp_path)
 monkeypatch.setenv('ABC_TRANSPORT_RUN','transport_test')
 monkeypatch.setenv('ABC_TRANSPORT_CHUNK_MIB','16')
 monkeypatch.setenv('ABC_TRANSPORT_INFLIGHT_MIB','32')
 def fake_worker():
  config=pd.PDConfig(prefill_devices=(0,),decode_devices=(1,))
  assert type(config) is original and config.transfer_chunk_bytes==16*1024**2
  assert config.max_inflight_bytes==32*1024**2
 monkeypatch.setattr(worker,'main',fake_worker)
 transport_worker.main()
 assert pd.PDConfig is original

def test_request_SLO_keeps_a_gap_before_a_coalesced_emission():
 from .slo_compare import qualifies
 row=dict(finish_reason='length',output_tokens=3,ttft_ms=20,e2e_ms=500,
  token_events=[dict(time=.3,previous_time=.1,new_tokens=2,first=False)])
 assert not qualifies(row,150,1000,1000)
 assert qualifies(row,250,1000,1000)

def test_shadow_scoring_rounds_do_not_merge_repeated_worker_evaluations():
 from .shadow_analysis import groups
 rows=[dict(request_id='Q',role=role,worker=worker) for role,worker in
  [('prefill','P0'),('prefill','P1'),('prefill','P0'),('prefill','P1'),('decode','D0')]]
 assert [len(batch) for batch in groups(rows)]==[2,2,1]

def test_an_empty_decision_file_cannot_approve_the_reports(monkeypatch,tmp_path):
 from . import render
 monkeypatch.setattr(render,'ROOT',tmp_path)
 assert render.reviewed_decisions()=={}
 (tmp_path/'configs').mkdir();(tmp_path/'configs/reviewed_decisions.json').write_text('{}')
 with pytest.raises(ValueError,match='explicit completed scientific review'):render.reviewed_decisions()
