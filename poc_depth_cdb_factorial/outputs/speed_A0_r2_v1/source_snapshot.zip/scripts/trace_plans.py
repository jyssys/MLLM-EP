"""Extend trace coverage to every primary C. Do not change clean plans."""
from poc_depth_cdb_factorial.contract import *

def main():
    cases=read(ROOT/'artifacts/speed_plan.json')['cases']
    for dp in [False,True]:
        selected=[dict(c,name='trace_'+c['name']) for c in cases if c['repeat']==0 and (c['arm']!='A0')==dp]
        destination=ROOT/f'artifacts/trace_{"DP4" if dp else "A0"}_full_plan.json'
        assert not destination.exists()
        write(destination,dict(cases=selected,local_batch_cap=16,
            note='All primary C values. Trace-only extension before trace measurements. Original trace plan remains preserved.'))

if __name__=='__main__':main()
