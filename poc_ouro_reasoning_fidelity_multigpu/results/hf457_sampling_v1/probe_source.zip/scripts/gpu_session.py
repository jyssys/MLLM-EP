"""Reuse the validated scoped burner guard without changing previous files."""
from poc_ouro_reasoning_fidelity_multigpu.contract import ROOT, PROJECT, ASSETS
from poc_looped_multigpu_kv_placement.scripts import gpu_session as shared
import zipfile
shared.ROOT, shared.PROJECT, shared.ASSETS = ROOT, PROJECT, ASSETS
original_write=shared.write
def write_with_snapshot(path,value):
    original_write(path,value)
    if path.name=='run_contract.json':
        archive=path.parent/'probe_source.zip'
        assert not archive.exists()
        with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
            for source in sorted(ROOT.rglob('*.py')):
                bundle.write(source,arcname=str(source.relative_to(ROOT)))
shared.write=write_with_snapshot
if __name__ == '__main__':
    shared.main()
