"""Do not classify another process session as an owned GPU job."""
import os
import signal
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
from poc_ouro_reasoning_fidelity_multigpu import guard_cleanup
from poc_ouro_reasoning_fidelity_multigpu.guard_cleanup import belongs,registered_launch


class GuardScopeTests(unittest.TestCase):
    def test_exact_registered_command_and_environment(self):
        groups=[]
        original=Mock(return_value=SimpleNamespace(pid=12345))
        launch=registered_launch(original,['model-probe'],Path('/scoped-output'),groups)
        launch(['other-probe'],env={'LOOPED_KV_OUTPUT':'/scoped-output'},start_new_session=True)
        launch(['model-probe'],env={'LOOPED_KV_OUTPUT':'/other-output'},start_new_session=True)
        self.assertEqual(groups,[])
        launch(['model-probe'],env={'LOOPED_KV_OUTPUT':'/scoped-output'},start_new_session=True)
        self.assertEqual(groups,[12345])

    def test_only_the_created_session_matches(self):
        process=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'],start_new_session=True)
        try:
            self.assertTrue(belongs(process.pid,process.pid))
            self.assertFalse(belongs(os.getpid(),process.pid))
            self.assertEqual(os.getsid(process.pid),process.pid)
            self.assertEqual(os.getpgid(process.pid),process.pid)
        finally:
            os.killpg(process.pid,signal.SIGTERM)
            process.wait(timeout=5)

    def test_idle_launcher_receives_only_the_requested_mask(self):
        with tempfile.TemporaryDirectory() as temporary:
            with patch.object(guard_cleanup,'ASSETS',Path(temporary)), \
                 patch.object(guard_cleanup.subprocess,'Popen',return_value=SimpleNamespace(pid=12345)) as launch, \
                 patch.object(guard_cleanup,'write') as write:
                guard_cleanup.finish([], [4,5],Path(temporary)/'probe',lambda gpus:[])
            self.assertEqual(launch.call_args.kwargs['env']['CUDA_VISIBLE_DEVICES'],'4,5')
            self.assertEqual(launch.call_args.kwargs['env']['VLLM_UTILIZE_GPUS'],'4,5')
            self.assertEqual(write.call_args.args[1]['scoped_idle_burner_restore'],[4,5])

    def test_unrelated_context_is_not_signalled(self):
        with patch.object(guard_cleanup,'belongs',return_value=False), \
             patch.object(guard_cleanup.time,'monotonic',side_effect=[0.,31.]), \
             patch.object(guard_cleanup.os,'killpg') as signal_group, \
             patch.object(guard_cleanup.subprocess,'Popen') as launch, \
             patch.object(guard_cleanup,'write'):
            guard_cleanup.finish([12345],[4],Path('/unused-test-output'),lambda gpus:[987654321])
        signal_group.assert_not_called()
        launch.assert_not_called()


if __name__=='__main__':
    unittest.main()
