"""CPU tests for information access, immutable data, and ownership constraints."""
import unittest
from poc_decode_first_depth_aware_dp_v3.contract import *

class Contract(unittest.TestCase):
    def test_selection(self):
        r=read(ROOT/'artifacts/dynamic_baseline_selection.json')
        self.assertEqual(r['decision'],'INCUMBENT_CONTINUE')
        self.assertEqual((r['q'],r['min_depth'],r['max_depth']),(.5,2,4))
        self.assertFalse(r['synthetic_replay'])

    def test_frozen_prior(self):
        r=read(ROOT/'artifacts/continuity.json')
        self.assertEqual(r['base_commit'],BASE_COMMIT)
        self.assertEqual(r['prior_quality_verdict'],'QUALITY_FAIL')
        for source,digest in r['sources'].items():self.assertEqual(sha(OLD_ROOT/source),digest)

    def test_cohort(self):
        r=read(ROOT/'artifacts/discovery_frozen.json')['rows']
        self.assertEqual(len(r),128)
        self.assertEqual(len({x['id'] for x in r}),128)
        for domain in ['gsm8k','math500','alpaca','sharegpt']:
            values=[v for v in r if v['dataset']==domain]
            self.assertEqual(len(values),32)
            self.assertEqual(sum(v['split']=='calibration' for v in values),8)

    def test_destination_replicas(self):
        self.assertEqual(GPUS,[4,5,6,7])
        self.assertEqual(MASK,'4,5,6,7')

if __name__=='__main__':unittest.main()
