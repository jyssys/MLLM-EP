"""Test pointer metadata with CPU stand-ins. Do not import Torch."""

from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

from poc_ouro_parallelism_deep_discovery.operand_binding import (
    LiftedOperandBindingCapture, ROLES, expected_weight_bindings,
    parameter_snapshot, tensor_metadata,
)


class MetadataTensor:
    def __init__(self, pointer=1040, storage=1024, offset=8, shape=(2, 4),
                 stride=(4, 1), dtype="torch.bfloat16", real=True):
        self.pointer, self.storage, self.offset = pointer, storage, offset
        self.shape, self.steps, self.dtype, self.real = shape, stride, dtype, real

    def data_ptr(self):
        return self.pointer

    def untyped_storage(self):
        return SimpleNamespace(data_ptr=lambda: self.storage)

    def storage_offset(self):
        return self.offset

    def stride(self):
        return self.steps

    def __getattr__(self, name):
        raise AssertionError(f"Unexpected tensor operation: {name}")


def names(layers, mode):
    result = ["L_self_modules_embed_tokens_parameters_weight_",
              "L_self_modules_norm_parameters_weight_"]
    for depth in ([0] if mode == "alias" else range(4)):
        for layer in range(layers):
            result.extend(f"L_self_modules_campaign_execution_modules_{depth}_modules_"
                          f"{layer}_modules_{role}_parameters_weight_" for role in ROLES)
    return result


def capture_fixture(weight=None, runtime=None, original=None):
    weight = weight or MetadataTensor()
    runtime = runtime or weight
    calls = []
    sentinel = object()
    def ordinary(*args, **kwargs):
        calls.append((args, kwargs))
        return sentinel
    owner = SimpleNamespace(optimized_call=original or ordinary)
    original_call = owner.optimized_call
    parameters = parameter_snapshot([("model.weight", weight), ("model.alias", weight)])
    capture = LiftedOperandBindingCapture(
        owner, ["position", "weight"], parameters, {"weight": "model.weight"},
        is_real_tensor=lambda value: isinstance(value, MetadataTensor) and value.real,
        context_provider=lambda: {"lane": "CPU_TEST"},
    )
    return owner, capture, runtime, calls, sentinel, original_call


class BindingTests(unittest.TestCase):
    def test_metadata_only_and_alias_names(self):
        owner, capture, weight, calls, sentinel, original = capture_fixture()
        self.assertIs(owner.optimized_call(7, weight), sentinel)
        record = capture.finish()
        self.assertEqual(record["status"], "CAPTURED_MATCH")
        self.assertEqual(record["operands"][1]["parameter_names_on_storage"],
                         ["model.weight", "model.alias"])
        self.assertEqual(record["operands"][1]["storage_offset"], 8)
        self.assertIs(calls[0][0][1], weight)
        self.assertIs(owner.optimized_call, original)
        self.assertNotIn("torch", sys.modules)

    def test_only_one_call_is_observed(self):
        owner, capture, weight, calls, sentinel, original = capture_fixture()
        owner.optimized_call(7, weight)
        owner.optimized_call(8, weight)
        self.assertEqual(len(calls), 2)
        self.assertEqual(capture.finish()["calls_seen"], 1)

    def test_each_metadata_difference_fails(self):
        for field, value in [("pointer", 9000), ("storage", 8000), ("offset", 9),
                             ("shape", (4, 2)), ("steps", (1, 2)), ("dtype", "torch.float32")]:
            with self.subTest(field=field):
                other = MetadataTensor()
                setattr(other, field, value)
                owner, capture, weight, calls, sentinel, original = capture_fixture(runtime=other)
                owner.optimized_call(7, weight)
                self.assertEqual(capture.finish()["status"], "CAPTURED_MISMATCH")

    def test_fake_call_is_forwarded_then_real_call_is_observed(self):
        owner, capture, weight, calls, sentinel, original = capture_fixture()
        owner.optimized_call(7, MetadataTensor(real=False))
        self.assertIsNot(owner.optimized_call, original)
        owner.optimized_call(7, weight)
        self.assertEqual(capture.finish()["status"], "CAPTURED_MATCH")
        self.assertEqual(len(calls), 2)

    def test_finish_without_call_restores(self):
        owner, capture, weight, calls, sentinel, original = capture_fixture()
        self.assertEqual(capture.finish()["status"], "NOT_CAPTURED")
        self.assertIs(owner.optimized_call, original)
        self.assertEqual(calls, [])

    def test_original_exception_propagates(self):
        failure = RuntimeError("original failure")
        def ordinary(*args):
            raise failure
        owner, capture, weight, calls, sentinel, original = capture_fixture(original=ordinary)
        with self.assertRaises(RuntimeError) as result:
            owner.optimized_call(7, weight)
        self.assertIs(result.exception, failure)
        self.assertIs(owner.optimized_call, original)
        self.assertEqual(capture.finish()["original_call_outcome"], "RAISED")

    def test_metadata_error_does_not_replace_original_execution(self):
        class BrokenMetadata(MetadataTensor):
            def stride(self):
                raise ValueError("metadata failure")
        owner, capture, weight, calls, sentinel, original = capture_fixture(runtime=BrokenMetadata())
        self.assertIs(owner.optimized_call(7, weight), sentinel)
        self.assertEqual(capture.finish()["status"], "CAPTURE_ERROR")
        self.assertEqual(len(calls), 1)

    def test_keyword_and_arity_calls_remain_unobserved(self):
        owner, capture, weight, calls, sentinel, original = capture_fixture()
        owner.optimized_call(weight)
        owner.optimized_call(position=7, weight=weight)
        record = capture.finish()
        self.assertEqual(record["status"], "NOT_CAPTURED")
        self.assertEqual(len(record["skipped_calls"]), 2)
        self.assertEqual(len(calls), 2)

    def test_arm_does_not_call_original(self):
        owner, capture, weight, calls, sentinel, original = capture_fixture()
        self.assertEqual(calls, [])
        with self.assertRaises(ValueError):
            LiftedOperandBindingCapture(owner, ["weight"], {}, {"weight": "missing"}, lambda x: True)
        capture.finish()

    def test_all_model_arm_placeholder_maps(self):
        for layers, alias, copies in [(24, 194, 770), (48, 386, 1538)]:
            for mode, count in [("alias", alias), ("copies", copies)]:
                with self.subTest(layers=layers, mode=mode):
                    result = expected_weight_bindings(names(layers, mode), mode, layers)
                    self.assertEqual(len(result), count)
                    self.assertTrue(result[names(layers, mode)[-1]].startswith("model._campaign_execution."))

    def test_incorrect_depth_and_role_maps_fail(self):
        with self.assertRaises(ValueError):
            expected_weight_bindings(names(24, "alias"), "copies", 24)
        bad = [name.replace("modules_3_modules_", "modules_4_modules_", 1)
               if "execution_modules_3_" in name else name for name in names(24, "copies")]
        with self.assertRaises(ValueError):
            expected_weight_bindings(bad, "copies", 24)


if __name__ == "__main__":
    unittest.main()
