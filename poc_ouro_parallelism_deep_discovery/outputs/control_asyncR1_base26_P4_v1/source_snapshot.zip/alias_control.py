"""Process-local weight-storage counterfactual. No checkpoint file changes."""
import copy
import linecache
import os

def install(mode):
    assert mode in ['alias','copies']
    import torch
    from torch import nn
    from vllm.model_executor.models import ouro
    assert not getattr(ouro.OuroForCausalLM,'_campaign_storage_installed',False)
    ordinary_load=ouro.OuroForCausalLM.load_weights

    def clone_module(module,shared_attention_ids):
        if id(module) in shared_attention_ids:return module
        result=copy.copy(module)
        result._parameters={name:None if value is None else nn.Parameter(value.detach().clone(),requires_grad=False)
                            for name,value in module._parameters.items()}
        # Buffers such as the immutable RoPE lookup retain the original values.
        # Depth-indexed mutable attention objects are shared explicitly above.
        result._buffers=dict(module._buffers)
        result._modules={name:None if value is None else clone_module(value,shared_attention_ids)
                         for name,value in module._modules.items()}
        return result

    def load_weights(self,weights):
        loaded=ordinary_load(self,weights)
        core=self.model;layers=core.layers;R=core.total_ut_steps
        assert R==4 and len(layers) in [24,48]
        copies=[layers]
        for _ in range(3):
            copies.append(nn.ModuleList([clone_module(layer,{id(a) for a in layer.self_attn.attn}) for layer in layers]))
        comparisons=[]
        for depth in range(1,4):
            count=0;amount=0
            for index,(original,replica) in enumerate(zip(layers,copies[depth])):
                assert all(a is b for a,b in zip(original.self_attn.attn,replica.self_attn.attn))
                source=dict(original.named_parameters());target=dict(replica.named_parameters())
                assert source.keys()==target.keys()
                for name,value in source.items():
                    other=target[name]
                    assert value.dtype==other.dtype==torch.bfloat16,(index,name,value.dtype,other.dtype)
                    assert value.untyped_storage().data_ptr()!=other.untyped_storage().data_ptr()
                    assert torch.equal(value,other),(depth,index,name)
                    count+=1;amount+=value.numel()*value.element_size()
            comparisons.append(dict(depth=depth,parameter_tensors=count,parameter_bytes=amount,
                all_values_bitwise_equal=True,all_parameter_storages_distinct=True,
                attention_objects_shared=True))
        core._campaign_physical_copies=nn.ModuleList(copies)
        # Every arm keeps all copies allocated. Only the execution aliases differ.
        core._campaign_execution=nn.ModuleList([layers for _ in range(4)] if mode=='alias' else copies)
        core._campaign_storage_evidence=dict(mode=mode,comparisons=comparisons,
            physical_layers=len(layers),logical_depth=4*len(layers),
            copies_allocated=4,execution_storage='one shared core' if mode=='alias' else 'four distinct value-identical cores',
            precision='BF16',attention_contract='Original R4 attention objects and static forward-context entries.',
            allocated_bytes_after_setup=torch.cuda.memory_allocated(),reserved_bytes_after_setup=torch.cuda.memory_reserved(),
            quality='Four-position numerical check and controlled output only. Natural quality NOT_RUN.')
        return loaded

    source='''def forward(self, input_ids, positions, intermediate_tensors=None, inputs_embeds=None):
    hidden_states = inputs_embeds if inputs_embeds is not None else self.embed_input_ids(input_ids)
    for current_ut in range(self.total_ut_steps):
        residual = None
        for layer in self._campaign_execution[current_ut]:
            hidden_states, residual = layer(positions, hidden_states, current_ut, residual)
        hidden_states, _ = self.norm(hidden_states, residual)
    return hidden_states
'''
    filename='<ouro_campaign_weight_storage_control>'
    linecache.cache[filename]=(len(source),None,source.splitlines(keepends=True),filename)
    scope={'__name__':__name__};exec(compile(source,filename,'exec'),scope)
    ouro.OuroModel.forward=scope['forward']
    ouro.OuroForCausalLM.load_weights=load_weights
    ouro.OuroForCausalLM._campaign_storage_installed=True
    return source
