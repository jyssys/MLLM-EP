
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i32', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=1, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_add_bitwise_and_bitwise_not_bitwise_or_embedding_ge_lt_masked_fill_mul_sub_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F07057393B9FDD51E26E2DC993D7935AF47BCDD5F44D2D0F5E2B10FF4C2A4ABD', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'x': 268435456}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_bitwise_and_bitwise_not_bitwise_or_embedding_ge_lt_masked_fill_mul_sub_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 2048
    x0 = (xindex % 2048)
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), xmask, eviction_policy='evict_last')
    tmp1 = tl.full([1], 12288, tl.int32)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 24576, tl.int32)
    tmp4 = tmp0 < tmp3
    tmp5 = tmp2 & tmp4
    tmp6 = tl.full([1], 49152, tl.int32)
    tmp7 = tmp0 >= tmp6
    tmp8 = tmp0 < tmp6
    tmp9 = tmp7 & tmp8
    tmp10 = tmp5 | tmp9
    tmp11 = tmp10 == 0
    tmp12 = tmp10.to(tl.int64)
    tmp13 = tmp0.to(tl.int64)
    tmp14 = tmp5.to(tl.int64)
    tmp15 = tl.full([1], 12288, tl.int64)
    tmp16 = tmp14 * tmp15
    tmp17 = tmp9.to(tl.int64)
    tmp18 = tl.full([1], 36864, tl.int64)
    tmp19 = tmp17 * tmp18
    tmp20 = tmp16 + tmp19
    tmp21 = tmp13 - tmp20
    tmp22 = tmp12 * tmp21
    tmp23 = tl.full([XBLOCK], 12288, tl.int32)
    tmp24 = tmp22 + tmp23
    tmp25 = tmp22 < 0
    tmp26 = tl.where(tmp25, tmp24, tmp22)
    tl.device_assert(((0 <= tmp26) & (tmp26 < 12288)) | ~(xmask), "index out of bounds: 0 <= tmp26 < 12288")
    tmp28 = tl.load(in_ptr1 + (x0 + 2048*tmp26), xmask).to(tl.float32)
    tmp29 = tl.full([1], 0.0, tl.float32)
    tmp30 = tl.where(tmp11, tmp29, tmp28)
    tl.store(out_ptr0 + (x2), tmp30, xmask)
