# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/esjung/MLLM-EP-ouro-deep-discovery/poc_ouro_parallelism_deep_discovery/outputs/event_nodes_fixture_v1/inductor_cache/wb/cwb3wnlohq4svdwrakqshsoioxhtvbyixiodqsnwijt3dqvyguxx.py
# Topologically Sorted Source Nodes: [silu, mul], Original ATen: [aten.silu, aten.mul]
# Source node to ATen node mapping:
#   mul => mul
#   silu => add, convert_element_type_2, convert_element_type_3, div, exp, neg
# Graph fragment:
#   %mm : Tensor "bf16[1, 5632][5632, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_1 : Tensor "bf16[1, 5632][5632, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %convert_element_type_2 : Tensor "f32[1, 5632][5632, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %neg : Tensor "f32[1, 5632][5632, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_2,), kwargs = {})
#   %exp : Tensor "f32[1, 5632][5632, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add : Tensor "f32[1, 5632][5632, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 5632][5632, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_2, %add), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 5632][5632, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %mul : Tensor "bf16[1, 5632][5632, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_3, %mm_1), kwargs = {})
#   return %mul
triton_poi_fused_mul_silu_0 = async_compile.triton('triton_poi_fused_mul_silu_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_mul_silu_0', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F07057393B9FDD51E26E2DC993D7935AF47BCDD5F44D2D0F5E2B10FF4C2A4ABD', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'x': 45056}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mul_silu_0(in_out_ptr0, in_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 5632
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_out_ptr0 + (x0), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(in_out_ptr0 + (x0), tmp9, xmask)
''', device_str='cuda')


# kernel path: /home/esjung/MLLM-EP-ouro-deep-discovery/poc_ouro_parallelism_deep_discovery/outputs/event_nodes_fixture_v1/inductor_cache/dl/cdlvbp7xzlzc375aff5qrna5fx3aptotk3odb6xwkea7qeh7m2yb.py
# Topologically Sorted Source Nodes: [value_1], Original ATen: [aten._fused_rms_norm]
# Source node to ATen node mapping:
#   value_1 => add_1, convert_element_type_8, convert_element_type_9, mean, mul_1, mul_2, pow_1, rsqrt
# Graph fragment:
#   %mm_2 : Tensor "bf16[1, 2048][2048, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %buf12 : Tensor "f32[1, 1][1, 1]cuda:0" = PlaceHolder[target=buf12]
#   %arg4_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %convert_element_type_8 : Tensor "f32[1, 2048][2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm_2, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_8, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [1], True), kwargs = {})
#   %add_1 : Tensor "f32[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_1,), kwargs = {})
#   %mul_1 : Tensor "f32[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_8, %rsqrt), kwargs = {})
#   %mul_2 : Tensor "f32[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %arg4_1), kwargs = {})
#   %convert_element_type_9 : Tensor "bf16[1, 2048][2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_2, torch.bfloat16), kwargs = {})
#   return %buf12,%convert_element_type_9
triton_red_fused__fused_rms_norm_1 = async_compile.triton('triton_red_fused__fused_rms_norm_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_red_fused__fused_rms_norm_1', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F07057393B9FDD51E26E2DC993D7935AF47BCDD5F44D2D0F5E2B10FF4C2A4ABD', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'tiling_scores': {'r0_': 16384}}
)
@triton.jit
def triton_red_fused__fused_rms_norm_1(in_out_ptr0, in_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp4 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = tl.sum(_tmp4, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp6 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tl.full([1, 1], 2048.0, tl.float32)
        tmp9 = (tmp4 / tmp8)
        tmp10 = tl.full([1, 1], 1e-06, tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = libdevice.rsqrt(tmp11)
        tmp13 = tmp7 * tmp12
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tmp13 * tmp15
        tmp17 = tmp16.to(tl.float32)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp17, r0_mask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1 = args
        args.clear()
        assert_size_stride(arg0_1, (1, 2048), (2048, 1))
        assert_size_stride(arg1_1, (5632, 2048), (2048, 1))
        assert_size_stride(arg2_1, (5632, 2048), (2048, 1))
        assert_size_stride(arg3_1, (2048, 5632), (5632, 1))
        assert_size_stride(arg4_1, (2048, ), (1, ))
        # Topologically Sorted Source Nodes: [record_event], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(0, 1)
        # Topologically Sorted Source Nodes: [record_event_1], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(2, 1)
        # Topologically Sorted Source Nodes: [record_event_2], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(3, 1)
        # Topologically Sorted Source Nodes: [record_event_3], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(4, 1)
        # Topologically Sorted Source Nodes: [record_event_4], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(5, 1)
        # Topologically Sorted Source Nodes: [record_event_5], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(6, 1)
        # Topologically Sorted Source Nodes: [record_event_6], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(7, 1)
        # Topologically Sorted Source Nodes: [record_event_7], Original ATen: [streams.record_event]
        torch.ops.streams.record_event.default(8, 1)
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            buf8 = empty_strided_cuda((1, 5632), (5632, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [linear], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(arg0_1, reinterpret_tensor(arg1_1, (2048, 5632), (1, 2048), 0), out=buf8)
            buf9 = empty_strided_cuda((1, 5632), (5632, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(arg0_1, reinterpret_tensor(arg2_1, (2048, 5632), (1, 2048), 0), out=buf9)
            del arg0_1
            buf10 = buf8; del buf8  # reuse
            # Topologically Sorted Source Nodes: [silu, mul], Original ATen: [aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            triton_poi_fused_mul_silu_0.run(buf10, buf9, 5632, stream=stream0)
            buf11 = empty_strided_cuda((1, 2048), (2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [silu, mul, value], Original ATen: [aten.silu, aten.mul, aten.t, aten.mm]
            extern_kernels.mm(buf10, reinterpret_tensor(arg3_1, (5632, 2048), (1, 5632), 0), out=buf11)
            buf13 = buf11; del buf11  # reuse
            # Topologically Sorted Source Nodes: [value_1], Original ATen: [aten._fused_rms_norm]
            stream0 = get_raw_stream(0)
            triton_red_fused__fused_rms_norm_1.run(buf13, arg4_1, 1, 2048, stream=stream0)
            buf14 = buf10; del buf10  # reuse
            # Topologically Sorted Source Nodes: [linear_3], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(buf13, reinterpret_tensor(arg1_1, (2048, 5632), (1, 2048), 0), out=buf14)
            buf15 = buf9; del buf9  # reuse
            # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(buf13, reinterpret_tensor(arg2_1, (2048, 5632), (1, 2048), 0), out=buf15)
            del buf13
            buf16 = buf14; del buf14  # reuse
            # Topologically Sorted Source Nodes: [silu_1, mul_1], Original ATen: [aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            triton_poi_fused_mul_silu_0.run(buf16, buf15, 5632, stream=stream0)
            buf17 = empty_strided_cuda((1, 2048), (2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [silu_1, mul_1, value_2], Original ATen: [aten.silu, aten.mul, aten.t, aten.mm]
            extern_kernels.mm(buf16, reinterpret_tensor(arg3_1, (5632, 2048), (1, 5632), 0), out=buf17)
            buf19 = buf17; del buf17  # reuse
            # Topologically Sorted Source Nodes: [value_3], Original ATen: [aten._fused_rms_norm]
            stream0 = get_raw_stream(0)
            triton_red_fused__fused_rms_norm_1.run(buf19, arg4_1, 1, 2048, stream=stream0)
            buf20 = buf16; del buf16  # reuse
            # Topologically Sorted Source Nodes: [linear_6], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(buf19, reinterpret_tensor(arg1_1, (2048, 5632), (1, 2048), 0), out=buf20)
            buf21 = buf15; del buf15  # reuse
            # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(buf19, reinterpret_tensor(arg2_1, (2048, 5632), (1, 2048), 0), out=buf21)
            del buf19
            buf22 = buf20; del buf20  # reuse
            # Topologically Sorted Source Nodes: [silu_2, mul_2], Original ATen: [aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            triton_poi_fused_mul_silu_0.run(buf22, buf21, 5632, stream=stream0)
            buf23 = empty_strided_cuda((1, 2048), (2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [silu_2, mul_2, value_4], Original ATen: [aten.silu, aten.mul, aten.t, aten.mm]
            extern_kernels.mm(buf22, reinterpret_tensor(arg3_1, (5632, 2048), (1, 5632), 0), out=buf23)
            buf25 = buf23; del buf23  # reuse
            # Topologically Sorted Source Nodes: [value_5], Original ATen: [aten._fused_rms_norm]
            stream0 = get_raw_stream(0)
            triton_red_fused__fused_rms_norm_1.run(buf25, arg4_1, 1, 2048, stream=stream0)
            buf26 = buf22; del buf22  # reuse
            # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(buf25, reinterpret_tensor(arg1_1, (2048, 5632), (1, 2048), 0), out=buf26)
            del arg1_1
            buf27 = buf21; del buf21  # reuse
            # Topologically Sorted Source Nodes: [linear_10], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(buf25, reinterpret_tensor(arg2_1, (2048, 5632), (1, 2048), 0), out=buf27)
            del arg2_1
            del buf25
            buf28 = buf26; del buf26  # reuse
            # Topologically Sorted Source Nodes: [silu_3, mul_3], Original ATen: [aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            triton_poi_fused_mul_silu_0.run(buf28, buf27, 5632, stream=stream0)
            del buf27
            buf29 = empty_strided_cuda((1, 2048), (2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [silu_3, mul_3, value_6], Original ATen: [aten.silu, aten.mul, aten.t, aten.mm]
            extern_kernels.mm(buf28, reinterpret_tensor(arg3_1, (5632, 2048), (1, 5632), 0), out=buf29)
            del arg3_1
            del buf28
            buf31 = buf29; del buf29  # reuse
            # Topologically Sorted Source Nodes: [value_7], Original ATen: [aten._fused_rms_norm]
            stream0 = get_raw_stream(0)
            triton_red_fused__fused_rms_norm_1.run(buf31, arg4_1, 1, 2048, stream=stream0)
            del arg4_1
        return (buf31, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((5632, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg2_1 = rand_strided((5632, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((2048, 5632), (5632, 1), device='cuda:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
