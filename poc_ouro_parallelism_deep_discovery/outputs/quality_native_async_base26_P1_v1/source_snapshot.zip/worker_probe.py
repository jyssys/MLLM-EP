"""Campaign-only diagnostic extension. No model operator is replaced."""
from pathlib import Path
import os
from poc_looped_recurrence_tp_4models.worker_probe import FourModelProbe

class CampaignProbe(FourModelProbe):
    def profiler_api_start(self):
        import torch
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStart()
        return {'pid':os.getpid(),'method':'cudaProfilerStart','scope':'Diagnostic process-tree capture only'}

    def profiler_api_stop(self):
        import torch
        import torch.distributed as dist
        from vllm.distributed import get_tp_group
        torch.cuda.synchronize()
        dist.barrier(group=get_tp_group().device_group)
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStop()
        return {'pid':os.getpid(),'method':'cudaProfilerStop','scope':'After-request synchronization, not a serving dependency'}

    def finish_kernel_profile(self):
        result=super().finish_kernel_profile()
        path=Path(os.environ['LOOPED_KV_OUTPUT'])/f'chrome.rank{result["rank"]}.json.gz'
        self.kernel_profile.export_chrome_trace(str(path))
        result['chrome_trace']=str(path)
        result['stream_identity']='Native Chrome CUDA trace fields. Inspect schema before interval attribution.'
        return result
