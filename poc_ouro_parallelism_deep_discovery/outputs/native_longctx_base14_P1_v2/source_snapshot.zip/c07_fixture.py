"""CPU-testable contracts for one eager, physical Ouro pass."""
from dataclasses import fields, is_dataclass, replace


def selectors(tp, row=0, depth=0):
    if tp not in (1, 4) or row not in range(4) or depth not in range(4):
        raise ValueError('The fixture requires TP1 or TP4 and row/depth values from zero through three.')
    return [(row, depth)] if tp == 1 else [(index, index) for index in range(4)]


def lease_pages(num_blocks, protected, rows, position, block_size=16):
    """Lease disjoint non-null pages. The serving engine must remain quiescent."""
    if min(num_blocks, rows, position, block_size) <= 0:
        raise ValueError('The page counts, position, and block size must be positive.')
    protected = set(protected)
    if any(not isinstance(page, int) or page < 0 or page >= num_blocks for page in protected):
        raise ValueError('A protected page is outside the native pool.')
    count = (position + 1 + block_size - 1) // block_size
    available = [page for page in range(num_blocks - 1, 0, -1) if page not in protected]
    if len(available) < rows * count:
        raise RuntimeError('The existing native pool lacks disjoint quiescent fixture pages.')
    return [available[index * count:(index + 1) * count] for index in range(rows)]


def token_addresses(pages, length, block_size=16):
    if length <= 0 or len(pages) * block_size < length:
        raise ValueError('The page table cannot address the requested token range.')
    return [(pages[position // block_size], position % block_size) for position in range(length)]


def clone_metadata(value, is_tensor, memo=None):
    """Clone metadata tensors. Preserve opaque native objects and shared structure."""
    memo = {} if memo is None else memo
    if id(value) in memo:
        return memo[id(value)]
    if is_tensor(value):
        result = value.detach().clone()
    elif is_dataclass(value) and not isinstance(value, type):
        result = replace(value, **{field.name: clone_metadata(getattr(value, field.name), is_tensor, memo)
                                   for field in fields(value) if field.init})
    elif isinstance(value, dict):
        result = {key: clone_metadata(item, is_tensor, memo) for key, item in value.items()}
    elif isinstance(value, list):
        result = [clone_metadata(item, is_tensor, memo) for item in value]
    elif isinstance(value, tuple):
        result = tuple(clone_metadata(item, is_tensor, memo) for item in value)
    else:
        result = value
    memo[id(value)] = result
    return result


def payload_bytes(layers, local_heads, position, selected_rows, element_size=2):
    if min(layers, local_heads, position, selected_rows, element_size) <= 0:
        raise ValueError('The payload dimensions must be positive.')
    per_token = layers * local_heads * 256 * element_size
    return dict(history_snapshot=selected_rows * position * per_token,
                history_destination_write=selected_rows * position * per_token,
                current_reference=selected_rows * per_token,
                current_destination_write=selected_rows * per_token)


def require_bitwise(reports):
    return 'BITWISE_PASS' if reports and all(row['equal'] for row in reports) else 'UNRESOLVED'
