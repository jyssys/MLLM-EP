"""Load the existing official CDB engine. No serving engine is implemented here."""
import os
import subprocess
import sys
from poc_decode_first_depth_aware_dp.contract import *


def load_engine(q=.5,*,graphs=False,batch=1,blocks=640,refill=True):
    assert set(map(int,os.environ['CUDA_VISIBLE_DEVICES'].split(',')))<={4,5,6,7}
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=CDB,text=True).strip()==CDB_REVISION
    sys.path.insert(0,str(CDB/'src'))
    sys.path.insert(0,str(ASSETS/'python_cuda129'))
    sys.path.insert(0,str(ASSETS/'cdb_dependencies'))
    import torch
    from looped_cdb.eval.model_loading import load_ouro_model,load_ouro_tokenizer
    from looped_cdb.continuous_depth_batching import ContinuousDepthBatchingConfig,ContinuousDepthBatchingEngine
    model=load_ouro_model(str(MODEL),recur_steps=4,dtype=torch.bfloat16,
        attn_impl='paged|flash_attention_3',kv_policy='last_exited')
    tokenizer=load_ouro_tokenizer(str(MODEL))
    cfg=ContinuousDepthBatchingConfig(max_recurrent_steps=4,min_recurrent_steps=2,
        exit_threshold=q,synthetic_exit_replay=False,delay_gate_consumption=False,
        use_async_batching=False,use_cuda_graph=graphs,use_cuda_graph_prefill=False,
        max_num_seqs=batch,max_num_batched_tokens=4096,max_model_len=8192,
        num_blocks=blocks,kv_policy='last_exited',kv_pressure_mode='reserve',refill=refill)
    engine=ContinuousDepthBatchingEngine.from_model(model,cfg)
    assert len(engine.cache.key_cache)==96 and len(engine.cache.value_cache)==96
    physical=list(map(int,os.environ['CUDA_VISIBLE_DEVICES'].split(',')))[0]
    uuid=str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-')
    assert uuid==UUIDS[GPUS.index(physical)]
    return model,tokenizer,engine
